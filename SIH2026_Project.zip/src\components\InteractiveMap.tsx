import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { 
  WatchZone, 
  POIMarker, 
  SOSRequest 
} from '../types';
import { 
  Layers, 
  MapPin, 
  Crosshair, 
  Eye, 
  Plus, 
  Check, 
  X, 
  Compass, 
  Sliders, 
  ShieldAlert, 
  Activity,
  Maximize2,
  WifiOff,
  LifeBuoy
} from 'lucide-react';

interface InteractiveMapProps {
  watchZones: WatchZone[];
  selectedZone: WatchZone | null;
  onSelectZone: (zone: WatchZone) => void;
  poiMarkers: Record<string, POIMarker[]>;
  sosRequests?: SOSRequest[];
  isOffline: boolean;
  onStartDrawingZone: () => void;
  isDrawingMode: boolean;
  onFinishDrawingZone: (coords: [number, number][]) => void;
  onCancelDrawingZone: () => void;
  drawnCoords: [number, number][];
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  watchZones,
  selectedZone,
  onSelectZone,
  poiMarkers,
  sosRequests = [],
  isOffline,
  onStartDrawingZone,
  isDrawingMode,
  onFinishDrawingZone,
  onCancelDrawingZone,
  drawnCoords
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const polygonLayerGroupRef = useRef<L.LayerGroup | null>(null);
  const poiLayerGroupRef = useRef<L.LayerGroup | null>(null);
  const sosLayerGroupRef = useRef<L.LayerGroup | null>(null);
  const drawLayerGroupRef = useRef<L.LayerGroup | null>(null);
  const imageOverlayRef = useRef<L.ImageOverlay | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  const [activeLayer, setActiveLayer] = useState<'optical' | 'nir' | 'sar' | 'ndwi' | 'hazard'>('optical');
  const [useOfflineImageOverlay, setUseOfflineImageOverlay] = useState(true);
  const [cursorCoords, setCursorCoords] = useState<{ lat: number; lng: number }>({ lat: 9.4981, lng: 76.3388 });
  const [showPOIs, setShowPOIs] = useState(true);
  const [showPolygons, setShowPolygons] = useState(true);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    const initialLat = selectedZone?.lat || 9.4981;
    const initialLng = selectedZone?.lng || 76.3388;
    const initialZoom = selectedZone?.zoom || 12;

    const map = L.map(mapContainerRef.current, {
      center: [initialLat, initialLng],
      zoom: initialZoom,
      zoomControl: false,
      attributionControl: false
    });

    // Basemap: Esri World Imagery when online, Tactical Canvas Grid when offline
    if (isOffline) {
      const TacticalOfflineGridLayer = (L.GridLayer as any).extend({
        createTile: function (coords: L.Coords) {
          const tile = document.createElement('canvas');
          const tileSize = this.getTileSize();
          tile.width = tileSize.x;
          tile.height = tileSize.y;
          const ctx = tile.getContext('2d');
          if (!ctx) return tile;

          ctx.fillStyle = '#050811';
          ctx.fillRect(0, 0, tileSize.x, tileSize.y);

          ctx.strokeStyle = '#0f1b2d';
          ctx.lineWidth = 1;
          ctx.strokeRect(0, 0, tileSize.x, tileSize.y);

          ctx.strokeStyle = '#1e3355';
          ctx.beginPath();
          ctx.moveTo(tileSize.x / 2 - 8, tileSize.y / 2);
          ctx.lineTo(tileSize.x / 2 + 8, tileSize.y / 2);
          ctx.moveTo(tileSize.x / 2, tileSize.y / 2 - 8);
          ctx.lineTo(tileSize.x / 2, tileSize.y / 2 + 8);
          ctx.stroke();

          ctx.fillStyle = '#1e3a5f';
          ctx.font = '9px monospace';
          ctx.fillText(`EDGE TACTICAL z${coords.z} [${coords.x},${coords.y}]`, 8, tileSize.y - 8);

          return tile;
        }
      });

      const offlineLayer = new TacticalOfflineGridLayer({ maxZoom: 18 });
      offlineLayer.addTo(map);
      tileLayerRef.current = offlineLayer as any;
    } else {
      const tileUrl = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
      const tileLayer = L.tileLayer(tileUrl, {
        maxZoom: 18,
        attribution: 'Esri / Sentinel-2 Copernicus'
      }).addTo(map);
      tileLayerRef.current = tileLayer;
    }

    // Zoom control at bottom right
    L.control.zoom({ position: 'bottomright' }).addTo(map);

    // Layer groups
    polygonLayerGroupRef.current = L.layerGroup().addTo(map);
    poiLayerGroupRef.current = L.layerGroup().addTo(map);
    sosLayerGroupRef.current = L.layerGroup().addTo(map);
    drawLayerGroupRef.current = L.layerGroup().addTo(map);

    // Track mouse coordinates
    map.on('mousemove', (e: L.LeafletMouseEvent) => {
      setCursorCoords({
        lat: Number(e.latlng.lat.toFixed(4)),
        lng: Number(e.latlng.lng.toFixed(4))
      });
    });

    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update Tile Layer if offline status changes
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    if (tileLayerRef.current) {
      map.removeLayer(tileLayerRef.current);
    }

    if (isOffline) {
      const TacticalOfflineGridLayer = (L.GridLayer as any).extend({
        createTile: function (coords: L.Coords) {
          const tile = document.createElement('canvas');
          const tileSize = this.getTileSize();
          tile.width = tileSize.x;
          tile.height = tileSize.y;
          const ctx = tile.getContext('2d');
          if (!ctx) return tile;

          ctx.fillStyle = '#050811';
          ctx.fillRect(0, 0, tileSize.x, tileSize.y);

          ctx.strokeStyle = '#0f1b2d';
          ctx.lineWidth = 1;
          ctx.strokeRect(0, 0, tileSize.x, tileSize.y);

          ctx.strokeStyle = '#1e3355';
          ctx.beginPath();
          ctx.moveTo(tileSize.x / 2 - 8, tileSize.y / 2);
          ctx.lineTo(tileSize.x / 2 + 8, tileSize.y / 2);
          ctx.moveTo(tileSize.x / 2, tileSize.y / 2 - 8);
          ctx.lineTo(tileSize.x / 2, tileSize.y / 2 + 8);
          ctx.stroke();

          ctx.fillStyle = '#1e3a5f';
          ctx.font = '9px monospace';
          ctx.fillText(`EDGE TACTICAL z${coords.z} [${coords.x},${coords.y}]`, 8, tileSize.y - 8);

          return tile;
        }
      });

      const offlineLayer = new TacticalOfflineGridLayer({ maxZoom: 18 });
      offlineLayer.addTo(map);
      tileLayerRef.current = offlineLayer as any;
    } else {
      const tileUrl = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
      const tileLayer = L.tileLayer(tileUrl, {
        maxZoom: 18,
        attribution: 'Esri / Sentinel-2 Copernicus'
      }).addTo(map);
      tileLayerRef.current = tileLayer;
    }
  }, [isOffline]);

  // Offline Georeferenced Satellite Image Overlay
  // Ensures that even with 0 internet, the user sees high-resolution satellite imagery anchored to the coordinates!
  useEffect(() => {
    if (!mapInstanceRef.current || !selectedZone) return;

    if (imageOverlayRef.current) {
      mapInstanceRef.current.removeLayer(imageOverlayRef.current);
      imageOverlayRef.current = null;
    }

    if (!useOfflineImageOverlay) return;

    // Choose image based on active spectral layer
    const imageSrc = 
      activeLayer === 'sar' ? '/imagery/sar_radar.jpg' :
      activeLayer === 'nir' ? '/imagery/false_color.jpg' :
      '/imagery/flood_optical.jpg';

    // Bounding box around selected zone
    const bounds: L.LatLngBoundsExpression = [
      [selectedZone.lat - 0.055, selectedZone.lng - 0.065],
      [selectedZone.lat + 0.055, selectedZone.lng + 0.065]
    ];

    const overlay = L.imageOverlay(imageSrc, bounds, {
      opacity: activeLayer === 'hazard' ? 0.65 : 0.88,
      interactive: false,
      zIndex: 10
    }).addTo(mapInstanceRef.current);

    imageOverlayRef.current = overlay;

    return () => {
      if (imageOverlayRef.current && mapInstanceRef.current) {
        mapInstanceRef.current.removeLayer(imageOverlayRef.current);
      }
    };
  }, [selectedZone, activeLayer, useOfflineImageOverlay]);

  // Handle Layer filter visual simulation (CSS filter on tiles)
  useEffect(() => {
    if (!mapContainerRef.current) return;
    const container = mapContainerRef.current;
    const tilePanes = container.querySelectorAll('.leaflet-tile-pane');

    tilePanes.forEach(pane => {
      const el = pane as HTMLElement;
      if (activeLayer === 'optical') {
        el.style.filter = 'brightness(0.85) contrast(1.15) saturate(1.2)';
      } else if (activeLayer === 'nir') {
        el.style.filter = 'brightness(0.9) contrast(1.4) sepia(0.6) hue-rotate(-50deg) saturate(2.4)';
      } else if (activeLayer === 'sar') {
        el.style.filter = 'grayscale(1) contrast(2.2) brightness(0.75)';
      } else if (activeLayer === 'ndwi') {
        el.style.filter = 'hue-rotate(170deg) saturate(2.8) contrast(1.5) brightness(0.8)';
      } else if (activeLayer === 'hazard') {
        el.style.filter = 'invert(0.15) hue-rotate(-20deg) saturate(2.0) contrast(1.3)';
      }
    });
  }, [activeLayer]);

  // Fly to selected zone
  useEffect(() => {
    if (!mapInstanceRef.current || !selectedZone) return;
    mapInstanceRef.current.flyTo([selectedZone.lat, selectedZone.lng], selectedZone.zoom, {
      duration: 1.4,
      easeLinearity: 0.25
    });
  }, [selectedZone]);

  // Render Watch Zone Polygons
  useEffect(() => {
    if (!polygonLayerGroupRef.current) return;
    polygonLayerGroupRef.current.clearLayers();

    if (!showPolygons) return;

    watchZones.forEach(zone => {
      const isSelected = selectedZone?.id === zone.id;
      const isAlert = zone.status === 'alert';

      const color = isAlert ? '#ef4444' : isSelected ? '#06b6d4' : '#10b981';
      const fillColor = isAlert ? '#ef4444' : isSelected ? '#06b6d4' : '#10b981';

      const polygon = L.polygon(zone.polygonCoords, {
        color: color,
        weight: isSelected ? 3 : 2,
        dashArray: isAlert ? '6, 6' : undefined,
        fillColor: fillColor,
        fillOpacity: isSelected ? 0.35 : 0.18
      });

      polygon.bindTooltip(
        `<div class="font-sans text-xs">
          <div class="font-bold text-white flex items-center gap-1">
            ${zone.name}
            ${isAlert ? '<span class="bg-red-500 text-white text-[9px] px-1 rounded font-mono">ALERT</span>' : ''}
          </div>
          <div class="text-slate-300 text-[10px] mt-0.5">Area: ${zone.areaKm2} km² • Inundation: ${zone.latestMetrics.inundatedAreaKm2} km² • ~${zone.latestMetrics.estimatedAffectedCitizens} Citizens</div>
        </div>`,
        { sticky: true, className: 'leaflet-popup-content' }
      );

      const popupContent = document.createElement('div');
      popupContent.className = 'p-2 space-y-2';
      popupContent.innerHTML = `
        <div class="border-b border-slate-800 pb-1.5">
          <div class="text-[10px] font-mono text-emerald-400 uppercase tracking-wide">Watch Zone Telemetry</div>
          <h3 class="text-sm font-bold text-white">${zone.name}</h3>
          <p class="text-[10px] text-slate-400">${zone.region}</p>
        </div>
        <div class="grid grid-cols-2 gap-1.5 text-xs font-mono">
          <div class="bg-slate-900 p-1.5 rounded border border-slate-800">
            <div class="text-slate-500 text-[9px]">INUNDATED AREA</div>
            <div class="font-bold text-white">${zone.latestMetrics.inundatedAreaKm2} km²</div>
          </div>
          <div class="bg-slate-900 p-1.5 rounded border border-slate-800">
            <div class="text-slate-500 text-[9px]">AT-RISK CITIZENS</div>
            <div class="font-bold text-rose-400">~${zone.latestMetrics.estimatedAffectedCitizens}</div>
          </div>
        </div>
        <div class="text-[11px] text-slate-300 leading-tight">${zone.description}</div>
      `;

      polygon.bindPopup(popupContent);

      polygon.on('click', () => {
        onSelectZone(zone);
      });

      polygonLayerGroupRef.current?.addLayer(polygon);
    });
  }, [watchZones, selectedZone, showPolygons]);

  // Render POI Markers
  useEffect(() => {
    if (!poiLayerGroupRef.current) return;
    poiLayerGroupRef.current.clearLayers();

    if (!showPOIs || !selectedZone) return;

    const markers = poiMarkers[selectedZone.id] || [];

    markers.forEach(poi => {
      const bgColor = 
        poi.status === 'Critical' || poi.status === 'Urgent' ? 'bg-red-500 text-white ring-red-400' :
        poi.status === 'Submerged' ? 'bg-amber-500 text-slate-950 ring-amber-400' :
        'bg-emerald-500 text-slate-950 ring-emerald-400';

      const iconHtml = `
        <div class="relative flex items-center justify-center">
          <span class="absolute -top-1 -right-1 flex h-3 w-3">
            <span class="animate-ping absolute inline-flex h-full w-full rounded-full ${poi.status === 'Critical' || poi.status === 'Urgent' ? 'bg-red-400' : 'bg-emerald-400'} opacity-75"></span>
            <span class="relative inline-flex rounded-full h-3 w-3 ${poi.status === 'Critical' || poi.status === 'Urgent' ? 'bg-red-500' : 'bg-emerald-500'}"></span>
          </span>
          <div class="h-6 w-6 rounded-full ${bgColor} ring-2 flex items-center justify-center text-[10px] font-bold shadow-lg">
            ${poi.type === 'shelter' ? '🏠' : poi.type === 'bridge' ? '🌉' : poi.type === 'station' ? '⚡' : poi.type === 'sos' ? '🛟' : '⚠️'}
          </div>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'custom-poi-marker',
        html: iconHtml,
        iconSize: [24, 24],
        iconAnchor: [12, 12]
      });

      const marker = L.marker([poi.lat, poi.lng], { icon: customIcon });

      marker.bindPopup(`
        <div class="p-1 space-y-1 font-sans text-xs">
          <div class="flex items-center justify-between border-b border-slate-800 pb-1">
            <span class="font-bold text-white">${poi.title}</span>
            <span class="text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${bgColor}">${poi.status}</span>
          </div>
          <p class="text-[11px] text-slate-300 leading-snug">${poi.details}</p>
        </div>
      `);

      poiLayerGroupRef.current?.addLayer(marker);
    });
  }, [poiMarkers, selectedZone, showPOIs]);

  // Render Citizen SOS Markers
  useEffect(() => {
    if (!sosLayerGroupRef.current) return;
    sosLayerGroupRef.current.clearLayers();

    if (!selectedZone) return;

    const zoneSOS = sosRequests.filter(s => s.zoneId === selectedZone.id && s.status !== 'RESCUED');

    zoneSOS.forEach(sos => {
      const isCrit = sos.urgency === 'CRITICAL';
      const iconHtml = `
        <div class="relative flex items-center justify-center cursor-pointer animate-bounce">
          <span class="absolute -top-1 -right-1 flex h-3.5 w-3.5">
            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-90"></span>
            <span class="relative inline-flex rounded-full h-3.5 w-3.5 bg-rose-600"></span>
          </span>
          <div class="h-7 w-7 rounded-full bg-rose-600 border-2 border-white text-white flex items-center justify-center text-xs font-bold shadow-2xl">
            🛟
          </div>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'custom-sos-marker',
        html: iconHtml,
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      });

      const marker = L.marker([sos.lat, sos.lng], { icon: customIcon });

      marker.bindPopup(`
        <div class="p-2 space-y-1.5 font-sans text-xs">
          <div class="flex items-center justify-between border-b border-slate-800 pb-1">
            <span class="font-bold text-rose-400 uppercase text-[10px]">SOS EMERGENCY BEACON</span>
            <span class="text-[9px] px-1.5 py-0.2 rounded bg-rose-950 border border-rose-800 text-rose-300 font-bold uppercase">${sos.urgency}</span>
          </div>
          <div class="font-bold text-white">${sos.citizenName}</div>
          <p class="text-[11px] text-slate-300">${sos.locationDescription}</p>
          <div class="text-[10px] text-slate-400 font-mono">Persons: ${sos.peopleCount} • Tel: ${sos.contactNumber}</div>
          <div class="text-[10px] text-cyan-300 font-mono">Needs: ${sos.needs.join(', ')}</div>
        </div>
      `);

      sosLayerGroupRef.current?.addLayer(marker);
    });
  }, [sosRequests, selectedZone]);

  // Handle Drawing Mode
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (!drawLayerGroupRef.current) return;
    drawLayerGroupRef.current.clearLayers();

    if (!isDrawingMode) {
      map.getContainer().style.cursor = '';
      map.off('click');
      return;
    }

    map.getContainer().style.cursor = 'crosshair';

    if (drawnCoords.length > 0) {
      drawnCoords.forEach(coord => {
        const pointMarker = L.circleMarker(coord, {
          radius: 5,
          color: '#38bdf8',
          fillColor: '#0284c7',
          fillOpacity: 0.9
        });
        drawLayerGroupRef.current?.addLayer(pointMarker);
      });

      if (drawnCoords.length > 2) {
        const poly = L.polygon(drawnCoords, {
          color: '#38bdf8',
          dashArray: '5, 5',
          fillColor: '#0284c7',
          fillOpacity: 0.25
        });
        drawLayerGroupRef.current?.addLayer(poly);
      } else {
        const line = L.polyline(drawnCoords, {
          color: '#38bdf8',
          dashArray: '5, 5',
          weight: 2
        });
        drawLayerGroupRef.current?.addLayer(line);
      }
    }

    const handleMapClick = (e: L.LeafletMouseEvent) => {
      const newCoord: [number, number] = [
        Number(e.latlng.lat.toFixed(5)),
        Number(e.latlng.lng.toFixed(5))
      ];
      (window as any).__onAddVertex?.(newCoord);
    };

    map.on('click', handleMapClick);

    return () => {
      map.off('click', handleMapClick);
    };
  }, [isDrawingMode, drawnCoords]);

  return (
    <div className="relative w-full h-full min-h-[380px] bg-slate-950 overflow-hidden flex flex-col">
      {/* Map Container */}
      <div ref={mapContainerRef} className="w-full flex-1 z-0 relative" />

      {/* Offline Grid Texture fallback behind tiles */}
      <div className="absolute inset-0 pointer-events-none opacity-10 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px]"></div>

      {/* Crosshair Center HUD Overlay */}
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-20">
        <div className="relative w-16 h-16">
          <div className="absolute inset-x-0 top-1/2 border-t border-emerald-400"></div>
          <div className="absolute inset-y-0 left-1/2 border-l border-emerald-400"></div>
          <div className="absolute inset-2 border border-emerald-400 rounded-full"></div>
        </div>
      </div>

      {/* Top Left: Region Presets & Fly-to */}
      <div className="absolute top-4 left-4 z-10 flex flex-wrap gap-1.5 max-w-[calc(100%-80px)]">
        {watchZones.map(zone => (
          <button
            key={zone.id}
            onClick={() => onSelectZone(zone)}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold backdrop-blur-md border transition-all flex items-center gap-1.5 shadow-lg ${
              selectedZone?.id === zone.id
                ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300 ring-1 ring-emerald-500/50'
                : 'bg-slate-900/80 border-slate-700/70 text-slate-300 hover:bg-slate-850 hover:text-white'
            }`}
          >
            <span className={`h-2 w-2 rounded-full ${
              zone.status === 'alert' ? 'bg-red-500 animate-ping' : 'bg-emerald-400'
            }`}></span>
            <span className="truncate max-w-[110px]">{zone.name.split(' ')[0]}</span>
          </button>
        ))}

        {!isDrawingMode ? (
          <button
            onClick={onStartDrawingZone}
            className="px-2.5 py-1 rounded-lg text-xs font-semibold backdrop-blur-md border border-cyan-500/50 bg-cyan-950/70 hover:bg-cyan-900/80 text-cyan-300 flex items-center gap-1 shadow-lg transition-all"
            title="Click to draw a custom polygon Watch Zone on the map"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Draw Zone</span>
          </button>
        ) : (
          <div className="flex items-center gap-1 bg-slate-900/90 border border-cyan-500 px-2 py-1 rounded-lg backdrop-blur-md shadow-2xl">
            <span className="text-[11px] text-cyan-300 font-mono">
              Drawing ({drawnCoords.length} pts)
            </span>
            <button
              onClick={() => onFinishDrawingZone(drawnCoords)}
              disabled={drawnCoords.length < 3}
              className={`p-1 rounded text-white ${
                drawnCoords.length >= 3 ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-slate-700 text-slate-400 cursor-not-allowed'
              }`}
            >
              <Check className="h-3 w-3" />
            </button>
            <button
              onClick={onCancelDrawingZone}
              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        )}
      </div>

      {/* Top Right: Multi-Spectral & Offline Controls */}
      <div className="absolute top-4 right-4 z-10 flex flex-col items-end space-y-2">
        <div className="bg-slate-900/90 border border-slate-700/80 rounded-xl p-1.5 backdrop-blur-md shadow-2xl flex flex-col space-y-1">
          <div className="text-[9px] font-mono text-slate-400 uppercase tracking-wider px-2 py-0.5 flex items-center justify-between">
            <span>Sensor Mode</span>
            <Layers className="h-3 w-3 text-cyan-400" />
          </div>

          <div className="grid grid-cols-1 gap-1">
            <button
              onClick={() => setActiveLayer('optical')}
              className={`px-2.5 py-1 text-left rounded-lg text-xs font-mono transition-all flex items-center justify-between ${
                activeLayer === 'optical'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span>Sentinel-2 True Color</span>
              <span className="text-[9px] text-emerald-400 ml-2">RGB</span>
            </button>

            <button
              onClick={() => setActiveLayer('nir')}
              className={`px-2.5 py-1 text-left rounded-lg text-xs font-mono transition-all flex items-center justify-between ${
                activeLayer === 'nir'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span>False Color Infrared</span>
              <span className="text-[9px] text-rose-400 ml-2">NIR</span>
            </button>

            <button
              onClick={() => setActiveLayer('sar')}
              className={`px-2.5 py-1 text-left rounded-lg text-xs font-mono transition-all flex items-center justify-between ${
                activeLayer === 'sar'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span>Sentinel-1 SAR Radar</span>
              <span className="text-[9px] text-amber-400 ml-2">C-Band</span>
            </button>

            <button
              onClick={() => setActiveLayer('ndwi')}
              className={`px-2.5 py-1 text-left rounded-lg text-xs font-mono transition-all flex items-center justify-between ${
                activeLayer === 'ndwi'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span>NDWI Water Index</span>
              <span className="text-[9px] text-cyan-400 ml-2">Hydro</span>
            </button>

            <button
              onClick={() => setActiveLayer('hazard')}
              className={`px-2.5 py-1 text-left rounded-lg text-xs font-mono transition-all flex items-center justify-between ${
                activeLayer === 'hazard'
                  ? 'bg-red-500/20 text-red-300 border border-red-500/40 font-bold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span>Change Hazard Mask</span>
              <span className="text-[9px] text-red-400 ml-2">AI Diff</span>
            </button>
          </div>

          {/* Toggles */}
          <div className="border-t border-slate-800 pt-1.5 px-1 flex flex-col space-y-1 text-[11px] text-slate-400">
            <label className="flex items-center justify-between cursor-pointer">
              <span>Local Satellite Raster</span>
              <input
                type="checkbox"
                checked={useOfflineImageOverlay}
                onChange={e => setUseOfflineImageOverlay(e.target.checked)}
                className="rounded border-slate-700 bg-slate-800 text-emerald-500 focus:ring-0"
              />
            </label>

            <div className="flex items-center justify-between pt-0.5">
              <label className="flex items-center gap-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showPOIs}
                  onChange={e => setShowPOIs(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-emerald-500 focus:ring-0"
                />
                <span>POIs</span>
              </label>
              <label className="flex items-center gap-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showPolygons}
                  onChange={e => setShowPolygons(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0"
                />
                <span>Zones</span>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Left: Coordinates HUD */}
      <div className="absolute bottom-4 left-4 z-10 flex items-center space-x-2 bg-slate-950/85 border border-slate-800 px-3 py-1.5 rounded-lg backdrop-blur-md text-[11px] font-mono text-slate-300 shadow-xl">
        <div className="flex items-center gap-1 border-r border-slate-800 pr-2">
          <Crosshair className="h-3.5 w-3.5 text-emerald-400" />
          <span>{cursorCoords.lat}°N, {cursorCoords.lng}°E</span>
        </div>
        <div className="border-r border-slate-800 pr-2 text-slate-400">
          EPSG:32643
        </div>
        {useOfflineImageOverlay && (
          <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-1.5 py-0.2 rounded text-[10px] font-bold">
            100% OFFLINE RASTER ACTIVE
          </span>
        )}
      </div>

      {/* SOS Count Badge if any active */}
      {sosRequests.filter(s => s.status !== 'RESCUED').length > 0 && (
        <div className="absolute bottom-4 right-14 z-10 flex items-center gap-2 bg-rose-950/80 border border-rose-500/50 px-3 py-1 rounded-lg backdrop-blur-md text-xs font-mono text-rose-300 shadow-xl animate-pulse">
          <LifeBuoy className="h-3.5 w-3.5 text-rose-400" />
          <span>{sosRequests.filter(s => s.status !== 'RESCUED').length} Active Citizen SOS</span>
        </div>
      )}
    </div>
  );
};
