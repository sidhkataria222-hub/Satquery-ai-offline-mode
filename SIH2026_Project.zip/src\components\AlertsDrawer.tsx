import React from 'react';
import { 
  AlertItem, 
  WatchZone 
} from '../types';
import { 
  ShieldAlert, 
  CheckCircle2, 
  ExternalLink, 
  X, 
  Bell, 
  MapPin, 
  Clock, 
  Check 
} from 'lucide-react';

interface AlertsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: AlertItem[];
  onAcknowledgeAlert: (alertId: string) => void;
  onSelectZone: (zoneId: string) => void;
  watchZones: WatchZone[];
}

export const AlertsDrawer: React.FC<AlertsDrawerProps> = ({
  isOpen,
  onClose,
  alerts,
  onAcknowledgeAlert,
  onSelectZone,
  watchZones
}) => {
  if (!isOpen) return null;

  const unacknowledged = alerts.filter(a => !a.acknowledged);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border-l border-slate-800 w-full max-w-md h-full flex flex-col shadow-2xl text-slate-100 animate-slideLeft">
        {/* Drawer Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-red-500/15 border border-red-500/30 text-red-400">
              <ShieldAlert className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                Active Hazard Alerts
                {unacknowledged.length > 0 && (
                  <span className="bg-red-500 text-white text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full">
                    {unacknowledged.length}
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-slate-400">Automated Change & Threshold Detections</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Alerts List */}
        <div className="flex-1 p-4 space-y-4 overflow-y-auto">
          {alerts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-slate-500 space-y-2">
              <CheckCircle2 className="h-8 w-8 text-emerald-500" />
              <p className="text-xs">No active alerts. All Watch Zones normal.</p>
            </div>
          ) : (
            alerts.map(alert => {
              const isCrit = alert.severity === 'CRITICAL';
              const isHigh = alert.severity === 'HIGH';

              return (
                <div
                  key={alert.id}
                  className={`rounded-xl border p-4 space-y-3 transition-all ${
                    alert.acknowledged
                      ? 'bg-slate-950/40 border-slate-800/60 opacity-70'
                      : isCrit
                      ? 'bg-red-950/20 border-red-500/50 shadow-lg shadow-red-950/30 ring-1 ring-red-500/30'
                      : isHigh
                      ? 'bg-amber-950/20 border-amber-500/50 shadow-lg shadow-amber-950/30'
                      : 'bg-slate-950/70 border-slate-800'
                  }`}
                >
                  {/* Top Bar */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-0.5">
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                        isCrit ? 'bg-red-500 text-white' : isHigh ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                      }`}>
                        {alert.severity} ALERT
                      </span>
                      <h4 className="font-bold text-white text-xs pt-1">{alert.title}</h4>
                      <p className="text-[11px] text-slate-400 flex items-center gap-1">
                        <MapPin className="h-3 w-3 text-slate-500" />
                        {alert.zoneName}
                      </p>
                    </div>

                    <span className="text-[10px] font-mono text-slate-500 shrink-0">
                      {alert.timestamp.split(',')[1] || alert.timestamp}
                    </span>
                  </div>

                  {/* Message */}
                  <p className="text-xs text-slate-300 leading-relaxed font-sans">
                    {alert.message}
                  </p>

                  {/* Quantitative Pill */}
                  <div className="flex items-center space-x-3 bg-slate-900/90 p-2 rounded-lg border border-slate-800 text-[11px] font-mono">
                    <div>
                      <span className="text-slate-500 text-[9px] uppercase">Delta Surge:</span>{' '}
                      <strong className={alert.changePercent > 0 ? 'text-red-400' : 'text-emerald-400'}>
                        +{alert.changePercent}%
                      </strong>
                    </div>
                    <span>•</span>
                    <div>
                      <span className="text-slate-500 text-[9px] uppercase">Area:</span>{' '}
                      <strong className="text-white">+{alert.changeKm2} km²</strong>
                    </div>
                  </div>

                  {/* Evidence Points */}
                  <div className="space-y-1 text-[11px] font-mono text-slate-400 border-t border-slate-800/80 pt-2">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">
                      Evidence Telemetry:
                    </span>
                    {alert.evidence.map((ev, i) => (
                      <div key={i} className="flex items-start space-x-1.5">
                        <span className="text-emerald-400">›</span>
                        <span>{ev}</span>
                      </div>
                    ))}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                    <button
                      onClick={() => onSelectZone(alert.zoneId)}
                      className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                    >
                      <span>Focus on Map</span>
                      <ExternalLink className="h-3 w-3" />
                    </button>

                    {!alert.acknowledged ? (
                      <button
                        onClick={() => onAcknowledgeAlert(alert.id)}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-mono flex items-center gap-1 transition-colors"
                      >
                        <Check className="h-3 w-3" />
                        <span>Acknowledge</span>
                      </button>
                    ) : (
                      <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="h-3 w-3" />
                        Acknowledged
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
