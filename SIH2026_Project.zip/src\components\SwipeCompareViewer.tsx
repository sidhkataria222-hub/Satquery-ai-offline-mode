import React, { useState, useRef, useCallback } from 'react';
import { 
  Sliders, 
  Layers, 
  Eye, 
  Activity, 
  Sparkles, 
  ShieldAlert, 
  Calendar,
  Maximize2
} from 'lucide-react';
import { Scenario } from '../types';

interface SwipeCompareViewerProps {
  scenario: Scenario;
  showMask: boolean;
  setShowMask: (val: boolean) => void;
  maskOpacity: number;
  setMaskOpacity: (val: number) => void;
  showBboxes: boolean;
  setShowBboxes: (val: boolean) => void;
}

export const SwipeCompareViewer: React.FC<SwipeCompareViewerProps> = ({
  scenario,
  showMask,
  setShowMask,
  maskOpacity,
  setMaskOpacity,
  showBboxes,
  setShowBboxes
}) => {
  const [sliderPos, setSliderPos] = useState<number>(50); // percentage 0 - 100
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = useCallback((e: React.MouseEvent | MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const clientX = 'touches' in e ? (e as any).touches[0].clientX : (e as MouseEvent).clientX;
    const offsetX = Math.max(0, Math.min(clientX - rect.left, rect.width));
    const percentage = (offsetX / rect.width) * 100;
    setSliderPos(percentage);
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const clientX = e.touches[0].clientX;
    const offsetX = Math.max(0, Math.min(clientX - rect.left, rect.width));
    const percentage = (offsetX / rect.width) * 100;
    setSliderPos(percentage);
  }, []);

  const startDrag = () => {
    setIsDragging(true);
  };

  const stopDrag = () => {
    setIsDragging(false);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 rounded-xl overflow-hidden border border-slate-800 shadow-2xl">
      {/* Top Toolbar */}
      <div className="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
        <div className="flex items-center space-x-2">
          <span className="text-emerald-400 font-bold flex items-center gap-1.5">
            <Sliders className="h-3.5 w-3.5" />
            Bitemporal Swipe Comparator
          </span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-300">
            {scenario.modality === 'cross-modal' 
              ? 'Optical (T1) ⟷ SAR Radar (T2)' 
              : 'Baseline (T1) ⟷ Current Post-Event (T2)'}
          </span>
        </div>

        {/* Mask and BBox Controls */}
        <div className="flex items-center space-x-3">
          <label className="flex items-center space-x-1.5 cursor-pointer text-slate-300">
            <input
              type="checkbox"
              checked={showMask}
              onChange={e => setShowMask(e.target.checked)}
              className="rounded border-slate-700 bg-slate-800 text-emerald-500 focus:ring-0 h-3.5 w-3.5"
            />
            <span>AI Difference Heatmap</span>
          </label>

          {showMask && (
            <div className="flex items-center space-x-1.5">
              <span className="text-[10px] text-slate-400">Opacity:</span>
              <input
                type="range"
                min="10"
                max="90"
                value={maskOpacity}
                onChange={e => setMaskOpacity(Number(e.target.value))}
                className="w-16 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />
              <span className="text-[10px] font-mono text-emerald-400 w-6">{maskOpacity}%</span>
            </div>
          )}

          <label className="flex items-center space-x-1.5 cursor-pointer text-slate-300">
            <input
              type="checkbox"
              checked={showBboxes}
              onChange={e => setShowBboxes(e.target.checked)}
              className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0 h-3.5 w-3.5"
            />
            <span>Detections</span>
          </label>
        </div>
      </div>

      {/* Main Interactive Swipe Stage */}
      <div 
        ref={containerRef}
        className="relative flex-1 min-h-[360px] select-none overflow-hidden cursor-ew-resize"
        onMouseMove={isDragging ? handleMouseMove : undefined}
        onMouseUp={stopDrag}
        onMouseLeave={stopDrag}
        onTouchMove={handleTouchMove}
      >
        {/* RIGHT / AFTER IMAGE (Base under layer) */}
        <div 
          className="absolute inset-0 w-full h-full"
          style={{ background: scenario.visuals.baseImage2 || scenario.visuals.baseImage1 }}
        >
          {/* Subtle Grid / Texture for satellite authenticity */}
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px]"></div>

          {/* After image badge */}
          <div className="absolute top-4 right-4 bg-slate-950/80 border border-slate-800 px-3 py-1.5 rounded-lg backdrop-blur-md text-xs font-mono text-slate-300 shadow-xl z-10 pointer-events-none">
            <div className="text-[9px] text-emerald-400 font-bold uppercase">Current Observation (T2)</div>
            <div className="font-bold text-white">{scenario.image2Name || scenario.image1Name}</div>
            <div className="text-[10px] text-slate-400">03 Sep 2026 • Post-Inundation</div>
          </div>
        </div>

        {/* LEFT / BEFORE IMAGE (Clipped on top using clip-path) */}
        <div 
          className="absolute inset-0 w-full h-full overflow-hidden"
          style={{
            clipPath: `polygon(0% 0%, ${sliderPos}% 0%, ${sliderPos}% 100%, 0% 100%)`,
            background: scenario.visuals.baseImage1
          }}
        >
          {/* Subtle Grid / Texture */}
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px]"></div>

          {/* Before image badge */}
          <div className="absolute top-4 left-4 bg-slate-950/80 border border-slate-800 px-3 py-1.5 rounded-lg backdrop-blur-md text-xs font-mono text-slate-300 shadow-xl z-10 pointer-events-none">
            <div className="text-[9px] text-cyan-400 font-bold uppercase">Historical Baseline (T1)</div>
            <div className="font-bold text-white">{scenario.image1Name}</div>
            <div className="text-[10px] text-slate-400">01 Aug 2026 • Dry Pre-Monsoon</div>
          </div>
        </div>

        {/* AI DIFFERENCE HEATMAP OVERLAY */}
        {showMask && scenario.visuals.maskOverlay && (
          <div 
            className="absolute inset-0 pointer-events-none transition-opacity duration-200"
            style={{ opacity: maskOpacity / 100 }}
          >
            <svg className="w-full h-full">
              {scenario.visuals.maskOverlay.elements.map((elem, idx) => {
                if (elem.type === 'polygon') {
                  return (
                    <polygon
                      key={idx}
                      points={elem.coords}
                      fill={scenario.visuals.maskOverlay!.color}
                      stroke="#ef4444"
                      strokeWidth="2"
                      strokeDasharray="4 2"
                      className="animate-pulse"
                    />
                  );
                } else if (elem.type === 'circle') {
                  const [cx, cy, r] = elem.coords.split(/[ ,]+/).map(Number);
                  return (
                    <circle
                      key={idx}
                      cx={`${cx}%`}
                      cy={`${cy}%`}
                      r={`${r}%`}
                      fill={scenario.visuals.maskOverlay!.color}
                      stroke="#f59e0b"
                      strokeWidth="2"
                    />
                  );
                }
                return null;
              })}
            </svg>
          </div>
        )}

        {/* BOUNDING BOXES */}
        {showBboxes && scenario.visuals.boundingBoxes && (
          <div className="absolute inset-0 pointer-events-none">
            {scenario.visuals.boundingBoxes.map((bbox, idx) => (
              <div
                key={idx}
                className="absolute border-2 rounded shadow-lg transition-all"
                style={{
                  left: `${bbox.x}%`,
                  top: `${bbox.y}%`,
                  width: `${bbox.w}%`,
                  height: `${bbox.h}%`,
                  borderColor: bbox.color,
                  backgroundColor: `${bbox.color}18`
                }}
              >
                <div 
                  className="absolute -top-5 left-0 px-1.5 py-0.5 rounded text-[9px] font-mono font-bold text-white whitespace-nowrap shadow-md"
                  style={{ backgroundColor: bbox.color }}
                >
                  {bbox.label}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* SLIDER DIVIDER LINE WITH HANDLE */}
        <div 
          className="absolute top-0 bottom-0 z-20"
          style={{ left: `${sliderPos}%` }}
        >
          {/* Vertical dividing line with glow */}
          <div className="absolute inset-y-0 -left-[1px] w-[2px] bg-cyan-400 shadow-[0_0_10px_#22d3ee]"></div>

          {/* Draggable center button */}
          <div 
            onMouseDown={startDrag}
            onTouchStart={startDrag}
            className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-slate-900 border-2 border-cyan-400 shadow-xl flex items-center justify-center text-cyan-300 hover:scale-110 active:scale-95 transition-transform cursor-ew-resize group"
          >
            <Sliders className="h-4 w-4 rotate-90" />
            {/* Tooltip percentage on hover/drag */}
            <div className="absolute -top-7 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-[9px] font-mono text-cyan-300 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
              {Math.round(sliderPos)}%
            </div>
          </div>
        </div>

        {/* Bottom Metrics Bar */}
        <div className="absolute bottom-3 left-4 right-4 z-10 flex flex-wrap items-center justify-between gap-2 bg-slate-950/85 border border-slate-800/80 px-4 py-2 rounded-xl backdrop-blur-md text-xs font-mono shadow-2xl">
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-1.5 text-red-400">
              <ShieldAlert className="h-4 w-4" />
              <span className="font-bold">Delta: +198.7%</span>
            </div>
            <span className="text-slate-600">|</span>
            <div className="text-slate-300">
              Inundated Area: <span className="text-white font-bold">2.42 km²</span>
            </div>
            <span className="text-slate-600">|</span>
            <div className="text-slate-300">
              Confidence: <span className="text-emerald-400 font-bold">{scenario.confidence}%</span>
            </div>
          </div>

          <div className="text-[11px] text-slate-400">
            Drag vertical divider to compare before & after
          </div>
        </div>
      </div>
    </div>
  );
};
