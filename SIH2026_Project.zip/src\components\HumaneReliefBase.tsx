import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { 
  WatchZone, 
  SOSRequest, 
  ShelterCamp 
} from '../types';
import { 
  HeartHandshake, 
  ShieldAlert, 
  Home, 
  Users, 
  Droplet, 
  PhoneCall, 
  Plus, 
  LifeBuoy, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  MapPin, 
  Send, 
  Check, 
  Stethoscope, 
  Utensils, 
  Crosshair,
  WifiOff
} from 'lucide-react';

interface HumaneReliefBaseProps {
  selectedZone: WatchZone;
  shelters: ShelterCamp[];
  sosRequests: SOSRequest[];
  onAddSOS: (req: SOSRequest) => void;
  onDispatchSOS: (sosId: string) => void;
  isOffline: boolean;
  onFocusSOSOnMap: (sos: SOSRequest) => void;
}

export const HumaneReliefBase: React.FC<HumaneReliefBaseProps> = ({
  selectedZone,
  shelters,
  sosRequests,
  onAddSOS,
  onDispatchSOS,
  isOffline,
  onFocusSOSOnMap
}) => {
  const [isSOSModalOpen, setIsSOSModalOpen] = useState(false);
  const [citizenName, setCitizenName] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [locationDescription, setLocationDescription] = useState('');
  const [peopleCount, setPeopleCount] = useState(3);
  const [urgency, setUrgency] = useState<'CRITICAL' | 'HIGH' | 'MEDIUM'>('CRITICAL');
  const [selectedNeeds, setSelectedNeeds] = useState<string[]>(['Boat Evacuation', 'Drinking Water']);

  const zoneShelters = shelters.filter(s => s.zoneId === selectedZone.id);
  const zoneSOS = sosRequests.filter(s => s.zoneId === selectedZone.id);

  const toggleNeed = (need: string) => {
    setSelectedNeeds(prev =>
      prev.includes(need) ? prev.filter(n => n !== need) : [...prev, need]
    );
  };

  const handleCreateSOS = (e: React.FormEvent) => {
    e.preventDefault();
    if (!citizenName.trim()) return;

    // Slight offset from zone center for realistic placement
    const latOffset = (Math.random() - 0.5) * 0.02;
    const lngOffset = (Math.random() - 0.5) * 0.02;

    const newReq: SOSRequest = {
      id: `sos-${Date.now()}`,
      zoneId: selectedZone.id,
      citizenName,
      contactNumber: contactNumber || 'Community Radio / Flag Signal',
      locationDescription,
      lat: Number((selectedZone.lat + latOffset).toFixed(4)),
      lng: Number((selectedZone.lng + lngOffset).toFixed(4)),
      urgency,
      peopleCount,
      needs: selectedNeeds,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'PENDING_RESCUE',
      offlineCreated: isOffline
    };

    onAddSOS(newReq);
    setIsSOSModalOpen(false);
    setCitizenName('');
    setContactNumber('');
    setLocationDescription('');

    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 }
    });
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 rounded-xl border border-slate-800 shadow-xl overflow-hidden font-sans">
      {/* Top Header */}
      <div className="px-4 py-3 bg-gradient-to-r from-slate-900 via-slate-900 to-rose-950/40 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-400">
            <HeartHandshake className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              Humane Relief & Life-Safety Base
              {isOffline && (
                <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/40">
                  OFFLINE FIELD MODE
                </span>
              )}
            </h3>
            <p className="text-[10px] text-slate-400">
              Human-Centered Rescue Coordination, Citizen SOS Beacons & Relief Camp Logistics
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsSOSModalOpen(true)}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg shadow-rose-950/50 transition-all active:scale-95"
        >
          <LifeBuoy className="h-3.5 w-3.5 animate-pulse" />
          <span>Report Emergency SOS</span>
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-4 space-y-4 overflow-y-auto">
        {/* 1. Humane Life-Safety Impact Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-900/60 p-3.5 rounded-xl border border-slate-800 font-mono text-xs">
          <div className="space-y-0.5">
            <span className="text-[10px] text-slate-400 uppercase flex items-center gap-1">
              <Users className="h-3 w-3 text-rose-400" />
              At-Risk Citizens
            </span>
            <div className="text-lg font-bold text-white font-sans">
              ~{selectedZone.latestMetrics.estimatedAffectedCitizens} People
            </div>
            <span className="text-[10px] text-slate-500 font-sans">142 low-lying homes</span>
          </div>

          <div className="space-y-0.5">
            <span className="text-[10px] text-slate-400 uppercase flex items-center gap-1">
              <Home className="h-3 w-3 text-emerald-400" />
              Sheltered in Camps
            </span>
            <div className="text-lg font-bold text-emerald-400 font-sans">
              {selectedZone.latestMetrics.shelteredCount} Evacuated
            </div>
            <span className="text-[10px] text-slate-500 font-sans">Safe & dry facilities</span>
          </div>

          <div className="space-y-0.5">
            <span className="text-[10px] text-slate-400 uppercase flex items-center gap-1">
              <LifeBuoy className="h-3 w-3 text-cyan-400" />
              Active Rescue Units
            </span>
            <div className="text-lg font-bold text-cyan-400 font-sans">
              {selectedZone.latestMetrics.rescueTeamsActive} Boat Crews
            </div>
            <span className="text-[10px] text-slate-500 font-sans">NDRF & local fishermen</span>
          </div>

          <div className="space-y-0.5">
            <span className="text-[10px] text-slate-400 uppercase flex items-center gap-1">
              <PhoneCall className="h-3 w-3 text-amber-400" />
              Emergency SOS Queue
            </span>
            <div className="text-lg font-bold text-amber-400 font-sans">
              {zoneSOS.filter(s => s.status === 'PENDING_RESCUE').length} Pending
            </div>
            <span className="text-[10px] text-slate-500 font-sans">Zero internet required</span>
          </div>
        </div>

        {/* 2. Relief Camps Logistics */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300 font-bold uppercase flex items-center gap-1.5">
              <Home className="h-3.5 w-3.5 text-emerald-400" />
              Community Relief Camps & Supply Reserves
            </span>
            <span className="text-slate-500 text-[10px]">{zoneShelters.length} Designated Facilities</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {zoneShelters.map(shelter => {
              const occupancyPct = Math.round((shelter.occupied / shelter.capacity) * 100);
              return (
                <div
                  key={shelter.id}
                  className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 space-y-2.5 text-xs font-sans"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-white text-xs">{shelter.name}</h4>
                      <p className="text-[11px] text-slate-400 font-mono">
                        Occupancy: {shelter.occupied} / {shelter.capacity} ({occupancyPct}%)
                      </p>
                    </div>

                    <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded uppercase ${
                      shelter.status === 'CRITICAL_SHORTAGE' ? 'bg-red-950 text-red-400 border border-red-800' :
                      shelter.status === 'NEAR_CAPACITY' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                      'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    }`}>
                      {shelter.status.replace('_', ' ')}
                    </span>
                  </div>

                  {/* Occupancy bar */}
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all ${
                        occupancyPct > 80 ? 'bg-amber-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${occupancyPct}%` }}
                    />
                  </div>

                  {/* Supply Status */}
                  <div className="grid grid-cols-3 gap-2 pt-1 border-t border-slate-800/80 text-[10px] font-mono text-slate-300">
                    <div className="flex items-center gap-1">
                      <Droplet className="h-3 w-3 text-cyan-400" />
                      <span>{shelter.waterDaysLeft}d Water</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Utensils className="h-3 w-3 text-amber-400" />
                      <span>{shelter.foodDaysLeft}d Food</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Stethoscope className="h-3 w-3 text-rose-400" />
                      <span>{shelter.medicalStaffCount} Medics</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 3. Citizen SOS Beacon Queue */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300 font-bold uppercase flex items-center gap-1.5">
              <LifeBuoy className="h-3.5 w-3.5 text-rose-400" />
              Citizen Emergency SOS Beacons (Zero-Internet Compatible)
            </span>
            <span className="text-[10px] text-slate-400">
              {zoneSOS.length} Total Registered
            </span>
          </div>

          <div className="space-y-2">
            {zoneSOS.map(sos => (
              <div
                key={sos.id}
                className={`p-3 rounded-xl border space-y-2 transition-all ${
                  sos.status === 'RESCUED'
                    ? 'bg-slate-950/40 border-slate-800/60 opacity-60'
                    : sos.urgency === 'CRITICAL'
                    ? 'bg-rose-950/20 border-rose-500/50 shadow-lg shadow-rose-950/30'
                    : 'bg-slate-900/70 border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded uppercase ${
                        sos.urgency === 'CRITICAL' ? 'bg-red-500 text-white' :
                        sos.urgency === 'HIGH' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                      }`}>
                        {sos.urgency} URGENCY
                      </span>
                      <h4 className="font-bold text-white text-xs">{sos.citizenName}</h4>
                      {sos.offlineCreated && (
                        <span className="text-[9px] font-mono bg-amber-500/20 text-amber-300 px-1 rounded flex items-center gap-0.5">
                          <WifiOff className="h-2.5 w-2.5" />
                          Offline Logged
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-300 mt-1 flex items-center gap-1">
                      <MapPin className="h-3 w-3 text-slate-500 shrink-0" />
                      {sos.locationDescription}
                    </p>
                  </div>

                  <span className="text-[10px] font-mono text-slate-500 shrink-0">
                    {sos.timestamp}
                  </span>
                </div>

                {/* People & Needs tags */}
                <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-mono">
                  <span className="bg-slate-800 text-slate-200 px-2 py-0.5 rounded">
                    {sos.peopleCount} Stranded Persons
                  </span>
                  {sos.needs.map((need, i) => (
                    <span key={i} className="bg-slate-950 border border-slate-800 text-cyan-300 px-2 py-0.5 rounded">
                      {need}
                    </span>
                  ))}
                  <span className="text-slate-400 ml-auto text-[11px]">
                    Tel: {sos.contactNumber}
                  </span>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-xs font-mono">
                  <button
                    onClick={() => onFocusSOSOnMap(sos)}
                    className="text-cyan-400 hover:text-cyan-300 text-[11px] flex items-center gap-1"
                  >
                    <Crosshair className="h-3 w-3" />
                    <span>Pin on Map ({sos.lat}°N, {sos.lng}°E)</span>
                  </button>

                  {sos.status === 'PENDING_RESCUE' ? (
                    <button
                      onClick={() => onDispatchSOS(sos.id)}
                      className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold flex items-center gap-1 shadow-sm transition-colors"
                    >
                      <LifeBuoy className="h-3 w-3" />
                      <span>Dispatch Rescue Boat</span>
                    </button>
                  ) : sos.status === 'DISPATCHED' ? (
                    <span className="text-amber-400 text-[11px] font-bold flex items-center gap-1">
                      <Clock className="h-3 w-3 animate-spin" />
                      Rescue Team En Route
                    </span>
                  ) : (
                    <span className="text-emerald-400 text-[11px] font-bold flex items-center gap-1">
                      <CheckCircle2 className="h-3 w-3" />
                      Rescued & Sheltered
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 4. Emergency Community Hotlines */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-2 text-xs font-mono text-slate-300">
          <div className="flex items-center gap-2">
            <PhoneCall className="h-4 w-4 text-emerald-400" />
            <span className="font-bold text-white">Emergency Helplines:</span>
          </div>
          <div className="flex flex-wrap items-center gap-4 text-slate-400">
            <span>NDRF HQ: <strong className="text-emerald-400">1078</strong></span>
            <span>State Emergency: <strong className="text-emerald-400">1070</strong></span>
            <span>Alappuzha Flood Ops: <strong className="text-cyan-400">0477-2238630</strong></span>
            <span>Assam Flood Ops: <strong className="text-cyan-400">0361-2237011</strong></span>
          </div>
        </div>
      </div>

      {/* CREATE EMERGENCY SOS MODAL */}
      {isSOSModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 text-slate-100 font-sans">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-400">
                  <LifeBuoy className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Register Emergency SOS Beacon</h3>
                  <p className="text-xs text-slate-400">Logs directly to local device & queues for responder dispatch</p>
                </div>
              </div>
              <button
                onClick={() => setIsSOSModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs font-mono"
              >
                Close ✕
              </button>
            </div>

            <form onSubmit={handleCreateSOS} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Family / Citizen Name / Group
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Thomas Mathew (4 elderly + 1 infant)"
                  value={citizenName}
                  onChange={e => setCitizenName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Contact Phone / Signal Flag
                </label>
                <input
                  type="text"
                  placeholder="e.g. +91 98471 00000 or White Cloth on Roof"
                  value={contactNumber}
                  onChange={e => setContactNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Exact Landmark / Location Description
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="e.g. Behind Kuttanad cooperative bank, two-story house with green roof, water at 4 feet"
                  value={locationDescription}
                  onChange={e => setLocationDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Number of Persons
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={peopleCount}
                    onChange={e => setPeopleCount(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-rose-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Urgency Level
                  </label>
                  <select
                    value={urgency}
                    onChange={e => setUrgency(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-rose-500 font-mono text-xs"
                  >
                    <option value="CRITICAL">CRITICAL (Rising water / Medical)</option>
                    <option value="HIGH">HIGH (Food / Clean Water exhausted)</option>
                    <option value="MEDIUM">MEDIUM (Awaiting evacuation)</option>
                  </select>
                </div>
              </div>

              {/* Needs buttons */}
              <div>
                <label className="block font-semibold text-slate-300 mb-1.5">
                  Critical Immediate Supplies Needed
                </label>
                <div className="flex flex-wrap gap-2">
                  {['Boat Evacuation', 'Drinking Water', 'Medical / Insulin', 'Infant Formula', 'Food Ration', 'Dry Clothes'].map(need => (
                    <button
                      type="button"
                      key={need}
                      onClick={() => toggleNeed(need)}
                      className={`px-2.5 py-1 rounded-lg border text-xs font-mono transition-all ${
                        selectedNeeds.includes(need)
                          ? 'bg-rose-950/80 border-rose-500 text-rose-300 font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      {need}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsSOSModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg shadow-rose-950/50"
                >
                  Confirm & Broadcast SOS Beacon
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
