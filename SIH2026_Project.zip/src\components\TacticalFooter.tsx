import React, { useState, useEffect } from 'react';
import { 
  Terminal, 
  Activity, 
  Cpu, 
  Database, 
  Radio, 
  Send, 
  ShieldCheck, 
  WifiOff, 
  Volume2, 
  ChevronRight,
  HardDrive
} from 'lucide-react';

interface TacticalFooterProps {
  onExecuteCommand: (cmd: string) => void;
  isOffline: boolean;
  queuedOperationsCount: number;
  activeZoneName: string;
}

export const TacticalFooter: React.FC<TacticalFooterProps> = ({
  onExecuteCommand,
  isOffline,
  queuedOperationsCount,
  activeZoneName
}) => {
  const [inputCmd, setInputCmd] = useState('');
  const [terminalHistory, setTerminalHistory] = useState<string[]>([
    'SATQUERY TACTICAL COMMAND RUNTIME [VERSION 1.4.2-RELEASE]',
    'INITIALIZED HARDWARE BUS: EPSG:32643 UTM ZONE 43N',
    'LOCAL SQLITE TELEMETRY DATABASE ATTACHED (0.04ms LATENCY)',
    'TYPE "help" FOR OPERATOR DISPATCH DIRECTIVES.'
  ]);

  const [nmeaSentence, setNmeaSentence] = useState('$GPGGA,092953.00,0929.8860,N,07620.3280,E,1,08,0.9,4.2,M*47');

  // Simulated live GPS coordinate stream
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const timeStr = now.toISOString().slice(11, 19).replace(/:/g, '');
      const lat = (9.4981 + (Math.random() - 0.5) * 0.0008).toFixed(4);
      const lng = (76.3388 + (Math.random() - 0.5) * 0.0008).toFixed(4);
      setNmeaSentence(`$GPGGA,${timeStr}.00,${lat},N,${lng},E,1,09,0.8,3.8,M*${Math.floor(Math.random()*90+10)}`);
    }, 2500);
    return () => clearInterval(timer);
  }, []);

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = inputCmd.trim();
    if (!cmd) return;

    setTerminalHistory(prev => [...prev, `OP-CMD> ${cmd}`]);
    setInputCmd('');

    const lower = cmd.toLowerCase();
    if (lower === 'help') {
      setTerminalHistory(prev => [
        ...prev,
        '  globe     - Switch to 3D rotating world globe',
        '  map       - Switch to full GIS satellite map',
        '  relief    - Open Humane Life-Safety & Citizen SOS base',
        '  compare   - Open bitemporal swipe slider comparator',
        '  sitrep    - Generate and print automated disaster situation report',
        '  status    - Print local SQLite records, memory, and cache health',
        '  clear     - Clear terminal buffer'
      ]);
    } else if (lower === 'status') {
      setTerminalHistory(prev => [
        ...prev,
        `  SYSTEM MODE: ${isOffline ? 'OFFLINE EDGE ISOLATION' : 'CLOUD SATELLITE RELAY'}`,
        `  ACTIVE TARGET: ${activeZoneName}`,
        `  LOCAL DISK DB: ${queuedOperationsCount} pending operations queued`,
        '  CACHE STATUS: 2.8 GB verified on device'
      ]);
    } else if (lower === 'clear') {
      setTerminalHistory(['BUFFER CLEARED.']);
    } else {
      onExecuteCommand(cmd);
      setTerminalHistory(prev => [
        ...prev,
        `COMMAND DISPATCHED: "${cmd}" -> Routed to processing pipeline.`
      ]);
    }
  };

  return (
    <footer className="border-t-2 border-slate-800 bg-[#040810] text-slate-300 font-mono text-xs select-none shadow-2xl">
      {/* 1. TOP HARDWARE GAUGES & NMEA COORDINATE TICKER */}
      <div className="bg-[#020509] border-b border-slate-850 px-4 py-1.5 flex flex-wrap items-center justify-between gap-3 text-[11px]">
        <div className="flex items-center space-x-4 overflow-x-auto text-slate-400">
          <div className="flex items-center space-x-1 text-emerald-400 font-bold">
            <Cpu className="h-3 w-3" />
            <span>VRAM: 1.4 GB / 8.0 GB</span>
          </div>
          <span className="text-slate-700">|</span>
          <div className="flex items-center space-x-1 text-cyan-400">
            <HardDrive className="h-3 w-3" />
            <span>DISK CACHE: 2.8 GB</span>
          </div>
          <span className="text-slate-700">|</span>
          <div className="flex items-center space-x-1 text-amber-400">
            <Radio className="h-3 w-3" />
            <span>VHF MARINE CH 16 (156.800 MHz)</span>
          </div>
          <span className="text-slate-700 hidden md:inline">|</span>
          <div className="hidden md:flex items-center space-x-1 text-slate-400">
            <span className="text-slate-500">LIVE NMEA:</span>
            <span className="text-emerald-400/90 font-mono text-[10px]">{nmeaSentence}</span>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-[10px] text-slate-400">
          <span className="px-1.5 py-0.2 bg-slate-900 border border-slate-800 text-slate-300 font-bold rounded">
            {isOffline ? 'OFFLINE DISK ATTACHED' : 'ISRO TELEMETRY UP'}
          </span>
          <span className="text-emerald-400 font-bold">● 60 FPS CANVAS</span>
        </div>
      </div>

      {/* 2. EMBEDDED TACTICAL OPERATOR COMMAND TERMINAL */}
      <div className="px-4 py-2 flex flex-col md:flex-row items-stretch md:items-center gap-3">
        {/* Terminal output box */}
        <div className="flex-1 bg-black/80 border border-slate-800 rounded p-2 max-h-16 overflow-y-auto text-[10px] text-emerald-400/90 space-y-0.5 leading-tight">
          {terminalHistory.slice(-3).map((line, i) => (
            <div key={i} className="flex items-start space-x-1">
              <span className="text-slate-600 select-none">›</span>
              <span className={line.includes('OP-CMD') ? 'text-cyan-300 font-bold' : ''}>{line}</span>
            </div>
          ))}
        </div>

        {/* Input prompt */}
        <form onSubmit={handleCommandSubmit} className="flex items-center space-x-1 shrink-0 md:w-80">
          <div className="flex items-center bg-black/90 border border-slate-800 rounded px-2.5 py-1.5 w-full text-xs">
            <span className="text-emerald-500 font-bold mr-1.5 select-none">$</span>
            <input
              type="text"
              placeholder="cmd: help, map, relief, sitrep..."
              value={inputCmd}
              onChange={e => setInputCmd(e.target.value)}
              className="bg-transparent border-none text-white focus:outline-none text-xs font-mono w-full placeholder:text-slate-600"
            />
          </div>
          <button
            type="submit"
            className="p-1.5 bg-slate-900 border border-slate-700 hover:border-emerald-500 text-emerald-400 rounded transition-colors"
            title="Execute Command"
          >
            <Send className="h-3.5 w-3.5" />
          </button>
        </form>
      </div>
    </footer>
  );
};
