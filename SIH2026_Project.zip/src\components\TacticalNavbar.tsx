import React, { useState, useEffect } from 'react';
import { 
  Radio, 
  Satellite, 
  Wifi, 
  WifiOff, 
  Bell, 
  HardDriveDownload, 
  FileText, 
  RefreshCw, 
  LifeBuoy, 
  Layers, 
  Compass, 
  Sliders, 
  Bot, 
  Globe, 
  HeartHandshake,
  Volume2,
  VolumeX,
  AlertOctagon
} from 'lucide-react';
import { AlertItem, OfflinePackageState, SOSRequest } from '../types';

interface TacticalNavbarProps {
  currentWorkflow: 'globe' | 'map' | 'relief' | 'compare' | 'watch' | 'chat';
  onSelectWorkflow: (wf: 'globe' | 'map' | 'relief' | 'compare' | 'watch' | 'chat') => void;
  isOffline: boolean;
  onToggleOffline: () => void;
  alerts: AlertItem[];
  onOpenAlerts: () => void;
  onOpenOfflineModal: () => void;
  onOpenSitrep: () => void;
  activeZoneCount: number;
  offlinePackage: OfflinePackageState;
  pendingSyncCount: number;
  onTriggerSync: () => void;
  isSyncing: boolean;
  sosRequests: SOSRequest[];
}

export const TacticalNavbar: React.FC<TacticalNavbarProps> = ({
  currentWorkflow,
  onSelectWorkflow,
  isOffline,
  onToggleOffline,
  alerts,
  onOpenAlerts,
  onOpenOfflineModal,
  onOpenSitrep,
  activeZoneCount,
  offlinePackage,
  pendingSyncCount,
  onTriggerSync,
  isSyncing,
  sosRequests
}) => {
  const [utcTime, setUtcTime] = useState('');
  const [audioEnabled, setAudioEnabled] = useState(true);

  // Live UTC Clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setUtcTime(now.toUTCString().replace('GMT', 'UTC'));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const unreadAlerts = alerts.filter(a => !a.acknowledged);
  const pendingSOS = sosRequests.filter(s => s.status === 'PENDING_RESCUE').length;

  return (
    <header className="border-b-2 border-slate-800 bg-[#060b13] text-slate-200 sticky top-0 z-40 shadow-2xl font-mono select-none">
      {/* 1. TOP TACTICAL TELEMETRY BANNER (Field Radio Strip) */}
      <div className="bg-[#03060a] border-b border-slate-850 px-4 py-1 flex items-center justify-between text-[10px] text-slate-400">
        <div className="flex items-center space-x-4 overflow-x-auto">
          <div className="flex items-center space-x-1 text-emerald-400 font-bold">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            <span>BASE STATION: IND-DISASTER-OPS-09</span>
          </div>
          <span className="text-slate-650">|</span>
          <div className="flex items-center space-x-1">
            <Radio className="h-3 w-3 text-cyan-400" />
            <span>DOWNLINK: 5.405 GHz (C-BAND SAR)</span>
          </div>
          <span className="text-slate-650 hidden sm:inline">|</span>
          <div className="hidden sm:flex items-center space-x-1 text-slate-300">
            <span>ISRO NRSC • COPERNICUS HUB</span>
          </div>
        </div>

        <div className="flex items-center space-x-3 text-[10px] shrink-0">
          <div className="text-emerald-400 font-bold bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
            ⏱ {utcTime || '03 Sep 2026 10:24:00 UTC'}
          </div>
          <button
            onClick={() => setAudioEnabled(prev => !prev)}
            className="text-slate-400 hover:text-white p-0.5"
            title={audioEnabled ? 'Mute Alert Haptics' : 'Enable Alert Haptics'}
          >
            {audioEnabled ? <Volume2 className="h-3.5 w-3.5 text-emerald-400" /> : <VolumeX className="h-3.5 w-3.5 text-slate-500" />}
          </button>
        </div>
      </div>

      {/* 2. MAIN INDUSTRIAL NAVBAR */}
      <div className="px-4 py-2 flex flex-wrap items-center justify-between gap-3 bg-[#08101a]">
        {/* Brand & Call-Sign Logo */}
        <div className="flex items-center space-x-3">
          <div className="bg-slate-900 border-2 border-emerald-500/80 p-1.5 rounded text-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.3)]">
            <Satellite className="h-5 w-5 animate-pulse" />
          </div>

          <div>
            <div className="flex items-center space-x-2">
              <span className="text-base font-black tracking-widest text-white uppercase font-mono">
                SATQUERY<span className="text-emerald-400">//</span>OPS
              </span>
              <span className="text-[9px] px-1.5 py-0.2 bg-slate-900 border border-slate-700 text-slate-300 font-bold rounded">
                MIL-STD FIELD V1.4
              </span>
            </div>
            <p className="text-[10px] text-slate-400 uppercase tracking-tight">
              Humanitarian Remote Sensing & Tactical Relief Base
            </p>
          </div>
        </div>

        {/* Tactical Mechanical Mode Switcher (Workflows) */}
        <div className="flex items-center space-x-1 bg-slate-950/90 border border-slate-800 p-1 rounded-lg">
          <button
            onClick={() => onSelectWorkflow('globe')}
            className={`px-2.5 py-1.5 rounded text-xs font-bold transition-all flex items-center gap-1.5 ${
              currentWorkflow === 'globe'
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-500 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Globe className="h-3.5 w-3.5 text-cyan-400" />
            <span>[1] ORBIT GLOBE</span>
          </button>

          <button
            onClick={() => onSelectWorkflow('map')}
            className={`px-2.5 py-1.5 rounded text-xs font-bold transition-all flex items-center gap-1.5 ${
              currentWorkflow === 'map'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Compass className="h-3.5 w-3.5 text-emerald-400" />
            <span>[2] GIS MAP</span>
          </button>

          <button
            onClick={() => onSelectWorkflow('relief')}
            className={`px-2.5 py-1.5 rounded text-xs font-bold transition-all flex items-center gap-1.5 relative ${
              currentWorkflow === 'relief'
                ? 'bg-rose-950 text-rose-300 border border-rose-500 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <HeartHandshake className="h-3.5 w-3.5 text-rose-400" />
            <span>[3] HUMANE RELIEF</span>
            {pendingSOS > 0 && (
              <span className="flex h-3.5 w-3.5 items-center justify-center rounded-full bg-rose-600 text-white text-[8px] font-bold">
                {pendingSOS}
              </span>
            )}
          </button>

          <button
            onClick={() => onSelectWorkflow('compare')}
            className={`px-2.5 py-1.5 rounded text-xs font-bold transition-all flex items-center gap-1.5 ${
              currentWorkflow === 'compare'
                ? 'bg-amber-950 text-amber-300 border border-amber-500 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Sliders className="h-3.5 w-3.5 text-amber-400" />
            <span>[4] SWIPE COMPARE</span>
          </button>

          <button
            onClick={() => onSelectWorkflow('chat')}
            className={`px-2.5 py-1.5 rounded text-xs font-bold transition-all flex items-center gap-1.5 ${
              currentWorkflow === 'chat'
                ? 'bg-blue-950 text-blue-300 border border-blue-500 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Bot className="h-3.5 w-3.5 text-blue-400" />
            <span>[5] GEOCHAT</span>
          </button>
        </div>

        {/* Industrial Action Switches */}
        <div className="flex items-center space-x-2">
          {/* Tactile Hardware Network Toggle */}
          <button
            onClick={onToggleOffline}
            className={`flex items-center space-x-2 px-3 py-1.5 rounded border-2 text-xs font-bold uppercase transition-all shadow-lg active:translate-y-0.5 ${
              isOffline
                ? 'bg-amber-500/20 border-amber-500 text-amber-300 ring-2 ring-amber-500/30'
                : 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
            }`}
            title="Toggle between Cloud Relay and Local Zero-Internet Edge"
          >
            {isOffline ? (
              <>
                <WifiOff className="h-3.5 w-3.5 text-amber-400 animate-pulse" />
                <span>OFFLINE FIELD EDGE</span>
              </>
            ) : (
              <>
                <Wifi className="h-3.5 w-3.5 text-emerald-400" />
                <span>CLOUD RELAY LIVE</span>
              </>
            )}
          </button>

          {/* Sync Queue */}
          {pendingSyncCount > 0 && (
            <button
              onClick={onTriggerSync}
              disabled={isSyncing || isOffline}
              className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded border text-xs font-bold uppercase ${
                isOffline
                  ? 'bg-slate-800 border-slate-700 text-slate-500 cursor-not-allowed'
                  : 'bg-cyan-950 border-cyan-500 text-cyan-300 hover:bg-cyan-900 shadow-md'
              }`}
            >
              <RefreshCw className={`h-3 w-3 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>SYNC ({pendingSyncCount})</span>
            </button>
          )}

          {/* Tactical SITREP Export button */}
          <button
            onClick={onOpenSitrep}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-slate-900 border border-slate-700 hover:border-emerald-500 text-slate-200 text-xs font-bold uppercase transition-colors"
          >
            <FileText className="h-3.5 w-3.5 text-emerald-400" />
            <span className="hidden sm:inline">SITREP BRIEF</span>
          </button>

          {/* Critical Alerts Bell */}
          <button
            onClick={onOpenAlerts}
            className="relative p-2 rounded bg-slate-900 border border-slate-700 hover:border-rose-500 text-slate-300 hover:text-white transition-colors"
            title="Active Disaster Alerts"
          >
            <Bell className="h-4 w-4" />
            {unreadAlerts.length > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-600 text-white text-[9px] font-bold animate-pulse">
                {unreadAlerts.length}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
