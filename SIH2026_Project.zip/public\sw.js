// SatQuery AI Service Worker - Full Offline Emergency Resilience
// Engineered for zero-internet disaster environments (e.g. Nepal flood blackouts)

const CACHE_NAME = 'satquery-offline-v2';

const CORE_STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/imagery/flood_optical.jpg',
  '/imagery/sar_radar.jpg',
  '/imagery/false_color.jpg'
];

// Install Event: Pre-cache core application shell and satellite assets
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async cache => {
      console.log('[SatQuery SW] Pre-caching core application shell & imagery...');
      for (const asset of CORE_STATIC_ASSETS) {
        try {
          await cache.add(asset);
        } catch (err) {
          console.warn('[SatQuery SW] Could not pre-cache asset:', asset, err);
        }
      }
    })
  );
  self.skipWaiting();
});

// Activate Event: Clean up stale legacy caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => {
      return Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      );
    })
  );
  self.clients.claim();
});

// Fetch Event: Intelligent offline routing
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);

  // 1. Navigation requests (HTML document loads & page refreshes)
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then(networkResponse => {
          if (networkResponse && networkResponse.status === 200) {
            const clone = networkResponse.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
          }
          return networkResponse;
        })
        .catch(async () => {
          // OFFLINE: Return cached index.html
          const cachedResponse = await caches.match('/index.html');
          if (cachedResponse) return cachedResponse;
          return caches.match('/');
        })
    );
    return;
  }

  // 2. Same-origin assets (JS bundles, CSS, satellite imagery, icons)
  if (url.origin === self.location.origin) {
    event.respondWith(
      caches.match(request).then(cachedResponse => {
        // Cache-First with Stale-While-Revalidate
        const fetchPromise = fetch(request)
          .then(networkResponse => {
            if (networkResponse && networkResponse.status === 200) {
              const clone = networkResponse.clone();
              caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
            }
            return networkResponse;
          })
          .catch(() => {
            return cachedResponse;
          });

        return cachedResponse || fetchPromise;
      })
    );
    return;
  }

  // 3. External requests (e.g. Map tile servers like OpenStreetMap / Esri)
  event.respondWith(
    caches.match(request).then(cachedTile => {
      if (cachedTile) return cachedTile;

      return fetch(request)
        .then(networkTile => {
          if (networkTile && networkTile.status === 200) {
            const clone = networkTile.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
          }
          return networkTile;
        })
        .catch(() => {
          // Offline fallback: transparent 1x1 GIF so Leaflet doesn't display broken image icons
          const transparentGif = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
          return fetch(transparentGif);
        });
    })
  );
});

// Message Event: Enable client to trigger offline mission package caching
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'PRECACHE_EMERGENCY_PACKAGE') {
    caches.open(CACHE_NAME).then(async cache => {
      console.log('[SatQuery SW] Caching full Emergency Mission Package on client command...');
      const extraAssets = [
        '/manifest.json',
        '/imagery/flood_optical.jpg',
        '/imagery/sar_radar.jpg',
        '/imagery/false_color.jpg'
      ];
      await cache.addAll(extraAssets).catch(e => console.warn(e));
      event.ports[0]?.postMessage({ status: 'DONE' });
    });
  }
});
