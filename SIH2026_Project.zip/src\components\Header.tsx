import React from 'react';
import {
  Compass,
  Wifi,
  WifiOff,
  Bell,
  HardDriveDownload,
  FileSpreadsheet,
  RefreshCw,
  Layers,
  Sparkles,
  HeartHandshake,
  LifeBuoy
} from 'lucide-react';
import { AlertItem, OfflinePackageState, SyncOperation, SOSRequest } from '../types';

interface HeaderProps {
  isOffline: boolean;
  onToggleOffline: () => void;
  alerts: AlertItem[];
  onOpenAlerts: () => void;
  onOpenOfflineModal: () => void;
  onOpenSitrep: () => void;
  activeZoneCount: number;
  offlinePackage: OfflinePackageState;
  pendingSyncCount: number;
  onTriggerSync: () => void;
  isSyncing: boolean;
  sosRequests?: SOSRequest[];
  onOpenHumaneBase?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  isOffline,
  onToggleOffline,
  alerts,
  onOpenAlerts,
  onOpenOfflineModal,
  onOpenSitrep,
  activeZoneCount,
  offlinePackage,
  pendingSyncCount,
  onTriggerSync,
  isSyncing,
  sosRequests = [],
  onOpenHumaneBase
}) => {
  const unreadAlerts = alerts.filter(a => !a.acknowledged);
  const criticalCount = alerts.filter(a => a.severity === 'CRITICAL' && !a.acknowledged).length;
  const pendingSOS = sosRequests.filter(s => s.status === 'PENDING_RESCUE').length;

  return (
    <header className="border-b border-slate-800/80 bg-slate-950/90 px-4 lg:px-6 py-3 flex items-center justify-between backdrop-blur-md sticky top-0 z-40 shadow-xl">
      {/* Brand */}
      <div className="flex items-center space-x-3">
        <div className={`p-2 rounded-xl border transition-all ${
          isOffline 
            ? 'bg-amber-500/15 border-amber-500/40 text-amber-400' 
            : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
        }`}>
          <Compass className={`h-6 w-6 ${isOffline ? '' : 'animate-spin-slow'}`} />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg lg:text-xl font-black tracking-tight text-white flex items-center gap-2">
              SatQuery <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-cyan-400 to-rose-400">AI</span>
            </h1>
            <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border font-bold uppercase tracking-wider ${
              isOffline
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
            }`}>
              {isOffline ? 'Offline Edge Active' : 'Humane Multi-Sensor'}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 hidden sm:block">
            {isOffline 
              ? 'Works 100% Offline • Local Satellite Imagery • Citizen SOS Beacons' 
              : 'Human-Centered Disaster Response, Persistent Watch Zones & Emergency Edge'}
          </p>
        </div>
      </div>

      {/* Center status pill / Quick metrics */}
      <div className="hidden xl:flex items-center space-x-3 bg-slate-900/80 border border-slate-800 rounded-full px-4 py-1.5 text-xs text-slate-300">
        <div className="flex items-center gap-1.5 border-r border-slate-800 pr-3">
          <Layers className="h-3.5 w-3.5 text-cyan-400" />
          <span className="font-semibold text-white">{activeZoneCount}</span>
          <span className="text-slate-400 text-[11px]">Watch Zones</span>
        </div>
        <div className="flex items-center gap-1.5 border-r border-slate-800 pr-3">
          <HeartHandshake className="h-3.5 w-3.5 text-rose-400" />
          <span className="font-semibold text-white">420 Sheltered</span>
          <span className="text-slate-400 text-[11px]">Relief Active</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span className="text-slate-300 font-mono text-[11px]">Zero-Internet Resilient</span>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex items-center space-x-2 sm:space-x-3">
        {/* Offline Mode Toggle Button */}
        <button
          onClick={onToggleOffline}
          className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all shadow-md ${
            isOffline
              ? 'bg-amber-500/20 border-amber-500/50 text-amber-300 hover:bg-amber-500/30 ring-1 ring-amber-500/40'
              : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-slate-600 hover:text-white'
          }`}
          title="Toggle between Live Internet and Zero-Internet Offline Mode"
        >
          {isOffline ? (
            <>
              <WifiOff className="h-3.5 w-3.5 text-amber-400 animate-pulse" />
              <span className="font-bold text-amber-400">OFFLINE EDGE</span>
            </>
          ) : (
            <>
              <Wifi className="h-3.5 w-3.5 text-emerald-400" />
              <span className="text-emerald-400 font-medium">ONLINE</span>
            </>
          )}
        </button>

        {/* Humane Relief Base / SOS Quick Button */}
        {onOpenHumaneBase && (
          <button
            onClick={onOpenHumaneBase}
            className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg border border-rose-500/40 bg-rose-950/30 hover:bg-rose-900/40 text-rose-300 text-xs font-semibold transition-colors shadow-sm relative"
            title="Open Humane Relief Base & Citizen SOS Tracker"
          >
            <HeartHandshake className="h-3.5 w-3.5 text-rose-400" />
            <span className="hidden sm:inline">Relief Base</span>
            {pendingSOS > 0 && (
              <span className="flex h-4 w-4 items-center justify-center rounded-full bg-rose-600 text-white text-[9px] font-bold">
                {pendingSOS}
              </span>
            )}
          </button>
        )}

        {/* Sync Reconnect Button if pending items */}
        {pendingSyncCount > 0 && (
          <button
            onClick={onTriggerSync}
            disabled={isSyncing}
            className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition-all ${
              isOffline
                ? 'bg-slate-850 border-slate-700 text-slate-400 cursor-not-allowed'
                : 'bg-cyan-950/60 border-cyan-500/50 text-cyan-300 hover:bg-cyan-900/60 shadow-lg shadow-cyan-950/30'
            }`}
            title="Synchronize queued offline actions with Cloud Database"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-cyan-400 ${isSyncing ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Sync ({pendingSyncCount})</span>
          </button>
        )}

        {/* Mission Package Download Button */}
        <button
          onClick={onOpenOfflineModal}
          className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg border border-slate-800 bg-slate-900/70 hover:bg-slate-850 hover:border-slate-700 text-slate-300 hover:text-white text-xs transition-colors"
          title="Manage Offline Mission Package & Cached Telemetry"
        >
          <HardDriveDownload className={`h-3.5 w-3.5 ${offlinePackage.isDownloaded ? 'text-emerald-400' : 'text-slate-400'}`} />
          <span className="hidden md:inline">Mission Pack</span>
        </button>

        {/* Situation Report (SITREP) Generator */}
        <button
          onClick={onOpenSitrep}
          className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg border border-emerald-500/30 bg-emerald-950/30 hover:bg-emerald-900/40 text-emerald-300 text-xs font-semibold transition-colors shadow-sm"
          title="Generate Comprehensive Situation Report for Responders"
        >
          <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-400" />
          <span className="hidden sm:inline">SITREP</span>
        </button>

        {/* Alerts Bell Drawer Toggle */}
        <button
          onClick={onOpenAlerts}
          className="relative p-2 rounded-lg border border-slate-800 bg-slate-900/80 hover:bg-slate-850 text-slate-300 hover:text-white transition-colors"
          title="View Active Watch Zone Alerts"
        >
          <Bell className="h-4 w-4" />
          {unreadAlerts.length > 0 && (
            <span className={`absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full text-[9px] font-bold text-white ${
              criticalCount > 0 ? 'bg-red-500 animate-ping-fast' : 'bg-amber-500'
            }`}>
              {unreadAlerts.length}
            </span>
          )}
        </button>
      </div>
    </header>
  );
};
