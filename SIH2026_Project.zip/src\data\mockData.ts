import { WatchZone, AlertItem, Scenario, VAEScene, POIMarker, SOSRequest, ShelterCamp } from '../types';

export const WATCH_ZONES: WatchZone[] = [
  {
    id: 'zone-nepal',
    name: 'Nepal Koshi & Kathmandu Flood Basin',
    region: 'Kathmandu Valley & Koshi Basin, Nepal',
    lat: 27.7000,
    lng: 85.3200,
    zoom: 12,
    polygonCoords: [
      [27.7400, 85.2800],
      [27.7550, 85.3600],
      [27.6950, 85.3900],
      [27.6500, 85.3500],
      [27.6450, 85.2900],
      [27.6900, 85.2650]
    ],
    areaKm2: 54.2,
    satellites: ['Sentinel-1 SAR', 'Sentinel-2 Optical', 'ALOS-2 PALSAR'],
    monitoringTypes: ['flooding', 'vegetation_change'],
    thresholdPercent: 15,
    status: 'alert',
    baselineDate: '01 Aug 2026',
    lastProcessedDate: '03 Sep 2026, 07:45 UTC',
    latestMetrics: {
      inundatedAreaKm2: 4.85,
      baselineAreaKm2: 1.12,
      deltaPercent: 333.0,
      confidence: 93.8,
      affectedStructures: 310,
      severity: 'CRITICAL',
      estimatedAffectedCitizens: 1420,
      shelteredCount: 890,
      rescueTeamsActive: 18
    },
    timeline: [
      { date: '01 Aug', valueKm2: 1.12, rainfallMm: 15, label: 'Normal river corridor baseline' },
      { date: '10 Aug', valueKm2: 1.40, rainfallMm: 60, label: 'Monsoon Himalayan foothills rain' },
      { date: '20 Aug', valueKm2: 2.15, rainfallMm: 130, label: 'Bagmati embankment overflow' },
      { date: '28 Aug', valueKm2: 3.90, rainfallMm: 210, label: 'Flash floods cut Ring Road' },
      { date: '03 Sep', valueKm2: 4.85, rainfallMm: 185, label: 'Peak deluge; zero net / offline' }
    ],
    description: 'Himalayan foothills river basin experiencing severe cloudburst inundation with complete telecommunications & internet blackout.'
  },
  {
    id: 'zone-kerala',
    name: 'Kerala Kuttanad Flood Basin',
    region: 'Alappuzha & Kottayam, Kerala',
    lat: 9.4981,
    lng: 76.3388,
    zoom: 12,
    polygonCoords: [
      [9.5400, 76.3100],
      [9.5550, 76.3700],
      [9.5100, 76.4100],
      [9.4600, 76.3800],
      [9.4500, 76.3200],
      [9.4900, 76.2950]
    ],
    areaKm2: 48.6,
    satellites: ['Sentinel-1 SAR', 'Sentinel-2 Optical', 'RISAT-1B'],
    monitoringTypes: ['flooding'],
    thresholdPercent: 15,
    status: 'alert',
    baselineDate: '01 Aug 2026',
    lastProcessedDate: '03 Sep 2026, 06:14 UTC',
    latestMetrics: {
      inundatedAreaKm2: 2.42,
      baselineAreaKm2: 0.81,
      deltaPercent: 198.7,
      confidence: 91.4,
      affectedStructures: 142,
      severity: 'CRITICAL',
      estimatedAffectedCitizens: 580,
      shelteredCount: 420,
      rescueTeamsActive: 14
    },
    timeline: [
      { date: '01 Aug', valueKm2: 0.81, rainfallMm: 12, label: 'Dry baseline condition' },
      { date: '08 Aug', valueKm2: 0.94, rainfallMm: 35, label: 'Monsoon onset showers' },
      { date: '15 Aug', valueKm2: 1.25, rainfallMm: 85, label: 'Canal spillover observed' },
      { date: '22 Aug', valueKm2: 2.10, rainfallMm: 140, label: 'Severe flash flood burst' },
      { date: '29 Aug', valueKm2: 2.58, rainfallMm: 175, label: 'Peak inundation recorded' },
      { date: '03 Sep', valueKm2: 2.42, rainfallMm: 45, label: 'Slow drainage / persistent pooling' }
    ],
    description: 'Low-lying delta below sea level vulnerable to Vembanad lake backflow and Pamba river surges.'
  },
  {
    id: 'zone-assam',
    name: 'Assam Brahmaputra Floodplain',
    region: 'Kaziranga & Nagaon, Assam',
    lat: 26.6638,
    lng: 93.3540,
    zoom: 11,
    polygonCoords: [
      [26.7100, 93.2800],
      [26.7400, 93.3900],
      [26.6900, 93.4600],
      [26.6200, 93.4100],
      [26.6100, 93.3000]
    ],
    areaKm2: 72.4,
    satellites: ['Sentinel-1 SAR', 'Sentinel-2 Optical'],
    monitoringTypes: ['flooding', 'vegetation_change'],
    thresholdPercent: 20,
    status: 'alert',
    baselineDate: '10 Aug 2026',
    lastProcessedDate: '02 Sep 2026, 14:30 UTC',
    latestMetrics: {
      inundatedAreaKm2: 4.15,
      baselineAreaKm2: 1.45,
      deltaPercent: 186.2,
      confidence: 88.7,
      affectedStructures: 68,
      severity: 'HIGH',
      estimatedAffectedCitizens: 840,
      shelteredCount: 680,
      rescueTeamsActive: 8
    },
    timeline: [
      { date: '10 Aug', valueKm2: 1.45, rainfallMm: 20, label: 'Normal river corridor' },
      { date: '17 Aug', valueKm2: 1.90, rainfallMm: 60, label: 'Upper catchment downpour' },
      { date: '24 Aug', valueKm2: 3.40, rainfallMm: 120, label: 'Embankment breach at Sector 4' },
      { date: '02 Sep', valueKm2: 4.15, rainfallMm: 95, label: 'Park grasslands submerged' }
    ],
    description: 'Braided river floodway adjacent to wildlife migration corridors and agricultural lowlands.'
  },
  {
    id: 'zone-mumbai',
    name: 'Mumbai Mithi Coastal Zone',
    region: 'Bandra-Kurla & Mahim, Maharashtra',
    lat: 19.0600,
    lng: 72.8656,
    zoom: 13,
    polygonCoords: [
      [19.0850, 72.8450],
      [19.0900, 72.8800],
      [19.0450, 72.8900],
      [19.0350, 72.8550]
    ],
    areaKm2: 24.1,
    satellites: ['Sentinel-1 SAR', 'Sentinel-2 Optical'],
    monitoringTypes: ['flooding', 'urban_expansion'],
    thresholdPercent: 10,
    status: 'normal',
    baselineDate: '05 Aug 2026',
    lastProcessedDate: '03 Sep 2026, 09:20 UTC',
    latestMetrics: {
      inundatedAreaKm2: 0.32,
      baselineAreaKm2: 0.29,
      deltaPercent: 10.3,
      confidence: 94.5,
      affectedStructures: 4,
      severity: 'LOW',
      estimatedAffectedCitizens: 60,
      shelteredCount: 0,
      rescueTeamsActive: 4
    },
    timeline: [
      { date: '05 Aug', valueKm2: 0.28, rainfallMm: 15, label: 'Baseline tidal levels' },
      { date: '15 Aug', valueKm2: 0.45, rainfallMm: 90, label: 'High tide tidal swell' },
      { date: '25 Aug', valueKm2: 0.34, rainfallMm: 30, label: 'Normal channel flow' },
      { date: '03 Sep', valueKm2: 0.32, rainfallMm: 18, label: 'Drains cleared, stable' }
    ],
    description: 'Tidal urban estuary monitoring for flash-flood choke points and mangrove encroachments.'
  },
  {
    id: 'zone-wayanad',
    name: 'Wayanad Meppadi Hill Slope',
    region: 'Meppadi & Chooralmala, Kerala',
    lat: 11.5360,
    lng: 76.1550,
    zoom: 13,
    polygonCoords: [
      [11.5650, 76.1300],
      [11.5700, 76.1800],
      [11.5200, 76.1900],
      [11.5100, 76.1400]
    ],
    areaKm2: 19.8,
    satellites: ['Sentinel-2 Optical', 'Cartosat-3'],
    monitoringTypes: ['vegetation_change', 'flooding'],
    thresholdPercent: 12,
    status: 'monitoring',
    baselineDate: '12 Aug 2026',
    lastProcessedDate: '02 Sep 2026, 11:00 UTC',
    latestMetrics: {
      inundatedAreaKm2: 0.78,
      baselineAreaKm2: 0.12,
      deltaPercent: 550.0,
      confidence: 93.1,
      affectedStructures: 89,
      severity: 'HIGH',
      estimatedAffectedCitizens: 320,
      shelteredCount: 290,
      rescueTeamsActive: 9
    },
    timeline: [
      { date: '12 Aug', valueKm2: 0.12, rainfallMm: 25, label: 'Stable forest canopy' },
      { date: '20 Aug', valueKm2: 0.22, rainfallMm: 110, label: 'Soil saturation warning' },
      { date: '28 Aug', valueKm2: 0.72, rainfallMm: 290, label: 'Debris flow path detected' },
      { date: '02 Sep', valueKm2: 0.78, rainfallMm: 65, label: 'Debris runout stabilization' }
    ],
    description: 'Steep tea plantation slopes vulnerable to extreme rainfall triggered debris torrents.'
  },
  {
    id: 'zone-joshimath',
    name: 'Joshimath Subsidence Escarpment',
    region: 'Chamoli, Uttarakhand',
    lat: 30.5564,
    lng: 79.5658,
    zoom: 14,
    polygonCoords: [
      [30.5700, 79.5450],
      [30.5750, 79.5850],
      [30.5400, 79.5800],
      [30.5350, 79.5400]
    ],
    areaKm2: 12.3,
    satellites: ['Sentinel-1 SAR', 'RISAT-1B'],
    monitoringTypes: ['urban_expansion'],
    thresholdPercent: 8,
    status: 'monitoring',
    baselineDate: '01 Jul 2026',
    lastProcessedDate: '01 Sep 2026, 05:40 UTC',
    latestMetrics: {
      inundatedAreaKm2: 0.05,
      baselineAreaKm2: 0.04,
      deltaPercent: 25.0,
      confidence: 89.2,
      affectedStructures: 32,
      severity: 'MEDIUM',
      estimatedAffectedCitizens: 120,
      shelteredCount: 95,
      rescueTeamsActive: 3
    },
    timeline: [
      { date: '01 Jul', valueKm2: 0.04, rainfallMm: 10, label: 'InSAR baseline run' },
      { date: '01 Aug', valueKm2: 0.045, rainfallMm: 45, label: 'Differential subsidence track' },
      { date: '01 Sep', valueKm2: 0.05, rainfallMm: 30, label: 'Cumulative settlement phase' }
    ],
    description: 'Perched moraine escarpment monitored for ground displacement using SAR interferometry.'
  }
];

export const SHELTER_CAMPS: ShelterCamp[] = [
  {
    id: 'camp-nepal-1',
    name: 'Balkhu Community Disaster Relief Camp (Kathmandu)',
    zoneId: 'zone-nepal',
    capacity: 800,
    occupied: 620,
    medicalStaffCount: 6,
    waterDaysLeft: 2.0,
    foodDaysLeft: 2.5,
    status: 'NEAR_CAPACITY'
  },
  {
    id: 'camp-nepal-2',
    name: 'Koshi Barrage High Ground Emergency School',
    zoneId: 'zone-nepal',
    capacity: 500,
    occupied: 270,
    medicalStaffCount: 3,
    waterDaysLeft: 3.5,
    foodDaysLeft: 4.0,
    status: 'NORMAL'
  },
  {
    id: 'camp-1',
    name: 'Kuttanad Government Higher Secondary School Camp',
    zoneId: 'zone-kerala',
    capacity: 500,
    occupied: 420,
    medicalStaffCount: 4,
    waterDaysLeft: 3.5,
    foodDaysLeft: 4.0,
    status: 'NEAR_CAPACITY'
  },
  {
    id: 'camp-2',
    name: 'Nedumudi Parish Community Center',
    zoneId: 'zone-kerala',
    capacity: 250,
    occupied: 180,
    medicalStaffCount: 2,
    waterDaysLeft: 2.0,
    foodDaysLeft: 2.5,
    status: 'NORMAL'
  },
  {
    id: 'camp-3',
    name: 'Bokakhat Tribal Welfare Hall',
    zoneId: 'zone-assam',
    capacity: 750,
    occupied: 680,
    medicalStaffCount: 5,
    waterDaysLeft: 1.5,
    foodDaysLeft: 2.0,
    status: 'CRITICAL_SHORTAGE'
  }
];

export const INITIAL_SOS_REQUESTS: SOSRequest[] = [
  {
    id: 'sos-nepal-1',
    zoneId: 'zone-nepal',
    citizenName: 'Balkhu Riverside Residents (8 Families / 26 People)',
    contactNumber: '+977 98412 34567 [Cell Outage - Logged Offline]',
    locationDescription: 'Trapped on 2nd floor rooftops behind Balkhu vegetable market, Bagmati river overflowed',
    lat: 27.6850,
    lng: 85.2980,
    urgency: 'CRITICAL',
    peopleCount: 26,
    needs: ['Boat Evacuation', 'Drinking Water', 'Infant Care', 'Emergency Medical Kit'],
    timestamp: '08:15 AM',
    status: 'PENDING_RESCUE',
    offlineCreated: true
  },
  {
    id: 'sos-nepal-2',
    zoneId: 'zone-nepal',
    citizenName: 'Chobhar Farming Hamlet',
    contactNumber: '+977 98031 98765 [Offline Beacon]',
    locationDescription: 'Debris flow blocked main access trail near gorge; elderly residents isolated',
    lat: 27.6620,
    lng: 85.2890,
    urgency: 'HIGH',
    peopleCount: 11,
    needs: ['Food/Water', 'Medical'],
    timestamp: '07:50 AM',
    status: 'DISPATCHED',
    offlineCreated: true
  },
  {
    id: 'sos-1',
    zoneId: 'zone-kerala',
    citizenName: 'Devan & Family (Elderly Mother + 2 Children)',
    contactNumber: '+91 98471 22910',
    locationDescription: 'Near Champakulam East Church, water entered first floor porch',
    lat: 9.5120,
    lng: 76.3520,
    urgency: 'CRITICAL',
    peopleCount: 4,
    needs: ['Boat Evacuation', 'Insulin Supplies', 'Drinking Water'],
    timestamp: '10:05 AM',
    status: 'PENDING_RESCUE',
    offlineCreated: false
  },
  {
    id: 'sos-2',
    zoneId: 'zone-kerala',
    citizenName: 'Nedumudi Rice Farmers Cluster',
    contactNumber: '+91 94473 18924',
    locationDescription: 'Trapped on polder dyke storage shed',
    lat: 9.4890,
    lng: 76.3280,
    urgency: 'HIGH',
    peopleCount: 6,
    needs: ['Food/Water', 'Tarpaulin'],
    timestamp: '09:40 AM',
    status: 'DISPATCHED',
    offlineCreated: false
  }
];

export const POI_MARKERS: Record<string, POIMarker[]> = {
  'zone-nepal': [
    {
      id: 'poi-np-1',
      lat: 27.6850,
      lng: 85.3050,
      type: 'shelter',
      title: 'Balkhu Disaster Emergency Camp',
      status: 'Operational',
      details: '620 citizens sheltered. Operating on backup solar generator with emergency water filtration.'
    },
    {
      id: 'poi-np-2',
      lat: 27.6780,
      lng: 85.3120,
      type: 'bridge',
      title: 'Bagmati Balkhu Underpass Bridge',
      status: 'Submerged',
      details: 'Completely inundated by 2.2m flood water. Ring Road traffic severed; impassable.'
    },
    {
      id: 'poi-np-3',
      lat: 27.6590,
      lng: 85.2840,
      type: 'danger',
      title: 'Chobhar Gorge Chokepoint & Landslide',
      status: 'Critical',
      details: 'High sediment discharge and mudflow chokepoint causing upstream water back-pooling.'
    },
    {
      id: 'poi-np-4',
      lat: 27.7120,
      lng: 85.3280,
      type: 'station',
      title: 'Kathmandu Flood Early Warning Station',
      status: 'Standby',
      details: 'Operating on battery telemetry; transmitting SAR-derived river heights via radio packet.'
    },
    {
      id: 'poi-sos-np-1',
      lat: 27.6850,
      lng: 85.2980,
      type: 'sos',
      title: 'EMERGENCY SOS: Balkhu Rooftop Cluster (26 People)',
      status: 'Urgent',
      details: 'Stranded on rooftops. Water level rising +15cm/hour. Immediate raft/boat extraction needed.'
    }
  ],
  'zone-kerala': [
    {
      id: 'poi-1',
      lat: 9.5050,
      lng: 76.3450,
      type: 'shelter',
      title: 'Kuttanad Government College Camp',
      status: 'Operational',
      details: '420 displaced citizens sheltered. Clean water & medical teams on-site.'
    },
    {
      id: 'poi-2',
      lat: 9.5250,
      lng: 76.3600,
      type: 'bridge',
      title: 'Champakulam Link Causeway',
      status: 'Submerged',
      details: 'Overtopped by 0.7m flood water. Heavy vehicles diverted via AC Road.'
    },
    {
      id: 'poi-3',
      lat: 9.4820,
      lng: 76.3250,
      type: 'danger',
      title: 'Polder Embankment Breach #3',
      status: 'Critical',
      details: '35m breach spilling into paddy polders. Sandbagging ongoing with NDRF.'
    },
    {
      id: 'poi-4',
      lat: 9.5350,
      lng: 76.3200,
      type: 'station',
      title: 'Nedumudi High-Capacity Pumping Station',
      status: 'Operational',
      details: '4x 500HP diesel dewatering pumps discharging 12,000 L/min back to canal.'
    },
    {
      id: 'poi-sos-1',
      lat: 9.5120,
      lng: 76.3520,
      type: 'sos',
      title: 'EMERGENCY SOS: Devan Family (4 People)',
      status: 'Urgent',
      details: 'Water entered porch. Elderly person requiring insulin. Rescue boat requested.'
    }
  ],
  'zone-assam': [
    {
      id: 'poi-5',
      lat: 26.6800,
      lng: 93.3400,
      type: 'shelter',
      title: 'Bokakhat Relief Center',
      status: 'Operational',
      details: 'Providing shelter to 680 villagers from submerged fringe riverbanks.'
    },
    {
      id: 'poi-6',
      lat: 26.7050,
      lng: 93.3800,
      type: 'danger',
      title: 'Brahmaputra South Dyke Breach',
      status: 'Critical',
      details: 'Rapid erosion of earthen dyke. Flood waters spreading into NH-715.'
    }
  ]
};

export const ALERTS: AlertItem[] = [
  {
    id: 'alt-nepal',
    zoneId: 'zone-nepal',
    zoneName: 'Nepal Koshi & Kathmandu Flood Basin',
    title: 'CRITICAL: Severe Himalayan Cloudburst Inundation',
    severity: 'CRITICAL',
    message: 'Water extent surged from 1.12 km² to 4.85 km² (+333.0%), triggering catastrophic inundation across low-lying Bagmati river settlements. 310 structures submerged. Cellular grid down; field responders operating in 100% Offline Edge Mode.',
    changeKm2: 3.73,
    changePercent: 333.0,
    evidence: [
      'Sentinel-1 SAR C-band radar penetrated 100% cloud cover over Himalayan foothills',
      'Radar backscatter dropped by -13.2 dB indicating high-velocity flood plains',
      'Bitemporal change mask detects severe inundation along 8.6km river corridor',
      'Over 1,420 citizens in high-risk zones; local offline coordination active'
    ],
    timestamp: '03 Sep 2026, 07:45 UTC',
    acknowledged: false,
    humanImpactSummary: '1,420 citizens impacted; 890 sheltered in Balkhu Camp. Optical fiber severed; local edge bus active.'
  },
  {
    id: 'alt-1',
    zoneId: 'zone-kerala',
    zoneName: 'Kerala Kuttanad Flood Basin',
    title: 'CRITICAL: Severe Inundation Surge Detected',
    severity: 'CRITICAL',
    message: 'Monitored water surface expanded from 0.81 km² to 2.42 km² (+198.7%), exceeding the 15% alert threshold. 142 built structures and ~580 citizens are within the high-risk hazard contour.',
    changeKm2: 1.61,
    changePercent: 198.7,
    evidence: [
      'Sentinel-1 SAR dual-pol VV backscatter dropped by -11.4 dB (specular open water reflection)',
      'Sentinel-2 NDWI index surged above +0.42 across 24,200 pixels',
      'Spatial expansion correlates with Pamba river level rise of +1.8m',
      'High confidence (91.4%) corroborated across both optical and radar sensors'
    ],
    timestamp: '03 Sep 2026, 06:14 UTC',
    acknowledged: false,
    humanImpactSummary: '580 citizens at risk; 420 sheltered in Kuttanad High School Camp. Relief boats operating on AC road canal.'
  },
  {
    id: 'alt-2',
    zoneId: 'zone-assam',
    zoneName: 'Assam Brahmaputra Floodplain',
    title: 'HIGH: Embankment Breach Flooding',
    severity: 'HIGH',
    message: 'Water extent increased by 2.70 km² (+186.2%). Inundation has cut off secondary access roads near Bokakhat, impacting 68 homesteads.',
    changeKm2: 2.70,
    changePercent: 186.2,
    evidence: [
      'SAR imagery shows riverbank overflow through the breached embankment',
      'False-Color NIR reveals loss of vegetative canopy in 280 hectares of grassland',
      'Confidence calibrated at 88.7%'
    ],
    timestamp: '02 Sep 2026, 14:30 UTC',
    acknowledged: false,
    humanImpactSummary: '840 citizens impacted; 680 evacuated to Bokakhat Tribal Hall. Critical shortage of clean drinking water.'
  },
  {
    id: 'alt-3',
    zoneId: 'zone-wayanad',
    zoneName: 'Wayanad Meppadi Hill Slope',
    title: 'HIGH: Massive Debris Scar Detected',
    severity: 'HIGH',
    message: 'Vegetation loss and sediment deposition detected along 2.4km drainage ravine. 89 plantation quarters damaged.',
    changeKm2: 0.66,
    changePercent: 550.0,
    evidence: [
      'NDVI dropped from 0.78 (dense canopy) to 0.11 (exposed mineral soil & mud)',
      'High-resolution Cartosat optical matching confirms mud deposit width of 65m'
    ],
    timestamp: '02 Sep 2026, 11:00 UTC',
    acknowledged: true,
    humanImpactSummary: '290 citizens safely moved to Chooralmala Church auditorium.'
  }
];

export const VAE_SCENES: VAEScene[] = [
  {
    id: 'vae-nepal',
    name: 'Nepal Koshi & Terai Flash Deluge (Aug 2024)',
    cluster: 'Flooded Wetland',
    coords: [-7.8, 5.8],
    similarityScore: 95.4,
    date: '18 Aug 2024',
    region: 'Koshi Basin, Nepal',
    inundationLevel: 'Extreme (4.9 km²)'
  },
  {
    id: 'vae-1',
    name: 'Kerala Kuttanad Inundation (Aug 2025)',
    cluster: 'Flooded Wetland',
    coords: [-6.8, 5.2],
    similarityScore: 94.8,
    date: '14 Aug 2025',
    region: 'Kerala, India',
    inundationLevel: 'Extensive (2.6 km²)'
  },
  {
    id: 'vae-2',
    name: 'Assam Brahmaputra Monsoon (Jul 2024)',
    cluster: 'Flooded Wetland',
    coords: [-5.9, 6.1],
    similarityScore: 89.2,
    date: '22 Jul 2024',
    region: 'Assam, India',
    inundationLevel: 'Major (4.3 km²)'
  },
  {
    id: 'vae-3',
    name: 'Bihar Kosi River Flood (Sep 2023)',
    cluster: 'Flooded Wetland',
    coords: [-7.2, 4.4],
    similarityScore: 86.5,
    date: '05 Sep 2023',
    region: 'Bihar, India',
    inundationLevel: 'Severe (5.1 km²)'
  },
  {
    id: 'vae-4',
    name: 'Godavari Delta Storm Surge (Aug 2022)',
    cluster: 'Coastal',
    coords: [-4.5, 3.1],
    similarityScore: 78.4,
    date: '18 Aug 2022',
    region: 'Andhra Pradesh, India',
    inundationLevel: 'Moderate (1.8 km²)'
  },
  {
    id: 'vae-5',
    name: 'Mumbai Mithi Urban Runoff (Jul 2023)',
    cluster: 'Dense Urban',
    coords: [4.2, -3.8],
    similarityScore: 72.1,
    date: '26 Jul 2023',
    region: 'Maharashtra, India',
    inundationLevel: 'Urban Flash Flood'
  },
  {
    id: 'vae-6',
    name: 'Sundarbans Estuary Tidal Mangrove',
    cluster: 'Coastal',
    coords: [-2.1, 1.8],
    similarityScore: 68.3,
    date: '11 Mar 2025',
    region: 'West Bengal, India',
    inundationLevel: 'Tidal Fluctuation'
  },
  {
    id: 'vae-7',
    name: 'Punjab Agricultural Irrigation Grid',
    cluster: 'Agricultural',
    coords: [5.5, 4.8],
    similarityScore: 34.0,
    date: '10 May 2025',
    region: 'Punjab, India',
    inundationLevel: 'Canal Irrigated'
  },
  {
    id: 'vae-8',
    name: 'Western Ghats Moist Deciduous Canopy',
    cluster: 'Forest/Hill',
    coords: [1.2, 7.5],
    similarityScore: 28.5,
    date: '15 Jan 2026',
    region: 'Karnataka, India',
    inundationLevel: 'None'
  },
  {
    id: 'vae-9',
    name: 'Bengaluru IT Corridor Expansion',
    cluster: 'Dense Urban',
    coords: [6.8, -4.2],
    similarityScore: 21.0,
    date: '02 Feb 2026',
    region: 'Karnataka, India',
    inundationLevel: 'Impervious Built-Up'
  }
];

export const SCENARIOS: Scenario[] = [
  {
    id: 'sc-nepal-flood',
    title: 'Nepal Cloudburst — Offline SAR Flood Delineation',
    query: 'What is the flood status in Nepal Koshi and Kathmandu basin with zero internet?',
    modality: 'temporal',
    zoneId: 'zone-nepal',
    image1Name: 'Sentinel1_SAR_Nepal_Baseline.tif',
    image2Name: 'Sentinel1_SAR_Nepal_PostFlood.tif',
    image1Type: 'SAR',
    image2Type: 'SAR',
    answer: 'OFFLINE EDGE ANALYSIS (NEPAL FLOOD DISASTER):\nAnalyzed locally via quantized on-device Edge Engine using cached Sentinel-1 SAR imagery:\n\n1. Inundation Extent: Flooding surged across 4.85 km² (+333.0% over baseline), submerging riverside settlements along the Bagmati and Koshi tributaries.\n2. Telecom Blackout: Cellular towers and internet severed; running on local device cache with zero external network.\n3. Human Impact: Estimated 1,420 citizens impacted; 890 sheltered in Balkhu Relief Camp; 26 citizens trapped on rooftops near Balkhu Market.\n4. Route Status: Balkhu Ring Road underpass is submerged (depth 2.2m). Chobhar gorge has active debris flow.\n5. Provenance: Data Source: Cached Sentinel-1 SAR (03 Sep 2026) | Model: Quantized Edge ONNX | Status: Field Verified.',
    confidence: 93.8,
    trace: [
      { name: 'Local Edge Bus Initialization', status: 'completed', duration: '12ms', details: 'Zero-internet environment confirmed. Loaded Nepal Koshi/Kathmandu vector boundary from local storage.' },
      { name: 'Cached SAR GeoTIFF Raster Retrieval', status: 'completed', duration: '28ms', details: 'Fetched pre-cached Sentinel-1 C-band SAR radar imagery (03-Sep 2026 pass).' },
      { name: 'On-Device Quantized Inference', status: 'completed', duration: '180ms', details: 'Executed 8-bit INT8 quantized UNet segmentation model on local device CPU/Wasm.' },
      { name: 'Water Mask & POI Intersection', status: 'completed', duration: '35ms', details: 'Overlaid water mask on local OpenStreetMap vector layer: identified 310 submerged buildings & severed bridge.' },
      { name: 'Offline Evidence Logging', status: 'completed', duration: '20ms', details: 'Appended inference trace and active SOS coordinates to local SQLite/IndexedDB sync queue.' }
    ],
    visuals: {
      baseImage1: "url('/imagery/sar_radar.jpg') center/cover no-repeat",
      baseImage2: "url('/imagery/flood_optical.jpg') center/cover no-repeat",
      maskOverlay: {
        color: 'rgba(239, 68, 68, 0.7)',
        elements: [
          { type: 'polygon', coords: '20,30 50,15 80,35 75,80 30,85', label: 'Nepal Flood Inundation Zone (4.85 km²)' },
          { type: 'circle', coords: '45,45 15', label: 'Balkhu Submerged Corridor' }
        ]
      },
      boundingBoxes: [
        { x: 18, y: 15, w: 65, h: 72, label: 'Critical Flood Zone - Nepal (93.8% Conf)', color: '#ef4444' },
        { x: 38, y: 40, w: 20, h: 20, label: 'Severed Bridge Link', color: '#f59e0b' }
      ]
    }
  },
  {
    id: 'sc-kerala-flood',
    title: 'Kerala Flood Zone — Bitemporal Change & Inundation',
    query: 'What changed in the Kerala Kuttanad Watch Zone between baseline and today?',
    modality: 'temporal',
    zoneId: 'zone-kerala',
    image1Name: 'Sentinel2_Kuttanad_01Aug2026.tif',
    image2Name: 'Sentinel2_Kuttanad_03Sep2026.tif',
    image1Type: 'Optical',
    image2Type: 'Optical',
    answer: 'HUMANITARIAN IMPACT & SURGE DETECTED:\nBetween 01 Aug 2026 and 03 Sep 2026, flood inundation expanded across 2.42 km² (a 198.7% surge over the dry baseline of 0.81 km²).\n\n1. Human Impact: Approximately 580 citizens reside in the newly inundated zone; 142 homes and 3 rural link roads are under water.\n2. Evacuation: 420 people are sheltered in Kuttanad Govt Higher Secondary School Camp.\n3. Model Output: Siamese ResNet-50 + ChangeChat segmented 24,200 flooded pixels with a high confidence score of 91.4%.\n4. Evidence: Co-registered Sentinel-1 SAR confirms persistent water ponding with a sharp drop in backscatter (-11.4 dB).',
    confidence: 91.4,
    trace: [
      { name: 'Watch Zone Boundary Clipping', status: 'completed', duration: '18ms', details: 'Extracted polygon ROI for Kuttanad Basin (48.6 km²) using EPSG:32643.' },
      { name: 'Query Classification & Routing', status: 'completed', duration: '24ms', details: 'Router classified query as "Temporal Change Detection & Impact Localization". Directed to Siamese ChangeChat VLM.' },
      { name: 'Multi-Temporal Alignment', status: 'completed', duration: '55ms', details: 'Sub-pixel co-registration between 01-Aug baseline and 03-Sep post-event image. Geometric RMSE: 0.08px.' },
      { name: 'Siamese Difference Convolution', status: 'completed', duration: '240ms', details: 'Calculated bitemporal cosine distance feature maps. Detected major class transition: Agriculture/Dry Land -> Standing Water.' },
      { name: 'Calibrated Evidence & Threshold Check', status: 'completed', duration: '32ms', details: 'Calculated +198.7% change vs baseline. Surpasses 15% threshold; escalated to CRITICAL alert engine.' },
      { name: 'Humane Report Synthesis', status: 'completed', duration: '48ms', details: 'Generated grounded disaster damage summary with spatial coordinates and affected citizens.' }
    ],
    visuals: {
      baseImage1: "url('/imagery/false_color.jpg') center/cover no-repeat",
      baseImage2: "url('/imagery/flood_optical.jpg') center/cover no-repeat",
      maskOverlay: {
        color: 'rgba(239, 68, 68, 0.65)',
        elements: [
          { type: 'polygon', coords: '35,20 65,25 75,65 50,85 25,65', label: 'Primary Inundation Zone (2.42 km²)' },
          { type: 'circle', coords: '30,75 12', label: 'Breached Embankment Polder' }
        ]
      },
      boundingBoxes: [
        { x: 30, y: 15, w: 48, h: 65, label: 'High-Hazard Inundation (91.4% Conf)', color: '#ef4444' },
        { x: 20, y: 68, w: 22, h: 22, label: 'Submerged Causeway', color: '#f59e0b' }
      ]
    }
  },
  {
    id: 'sc-crossmodal',
    title: 'Multimodal Fusion — Optical + SAR Cloud Penetration',
    query: 'Can you detect water extent through dense monsoon clouds using Optical and SAR?',
    modality: 'cross-modal',
    zoneId: 'zone-kerala',
    image1Name: 'Sentinel2_Optical_CloudCover.tif',
    image2Name: 'Sentinel1_SAR_Cband_VV.tif',
    image1Type: 'Optical',
    image2Type: 'SAR',
    answer: 'MULTIMODAL FUSION COMPLETE:\nDespite 68% dense cloud obscuration in the optical Sentinel-2 pass, the Sentinel-1 C-band synthetic aperture radar (SAR) microwave pulses penetrated cloud cover without attenuation.\n\n1. SAR Specular Reflectance: Flat water surfaces reflect radar pulses away from the sensor, producing distinct dark pixels (VV < -21 dB).\n2. Built-Up Confirmation: Surrounding concrete and metal structures create characteristic double-bounce scatter (> -5 dB), pinpointing flooded village boundaries.\n3. Cross-Attention Agreement: Sensor agreement is 92.4%, confirming 2.42 km² inundated without waiting for clear skies.',
    confidence: 96.1,
    agreement: 92.4,
    trace: [
      { name: 'Cloud Masking (Optical)', status: 'completed', duration: '30ms', details: 'Cloud probability algorithm identified 68% cloud cover. Triggered automatic multimodal SAR fallback.' },
      { name: 'SAR Radiometric Calibration', status: 'completed', duration: '85ms', details: 'Converted Sentinel-1 GRD digital numbers to gamma-nought backscatter intensity (dB).' },
      { name: 'Cross-Attention Multimodal Fusion', status: 'completed', duration: '190ms', details: 'Fused optical RGB/NIR features with SAR VV/VH polarizations using multi-head cross-attention.' },
      { name: 'Sensor Agreement Matrix', status: 'completed', duration: '40ms', details: 'Calculated agreement: 92.4% between SAR specular reflection and optical spectral dips.' },
      { name: 'All-Weather Water Delineation', status: 'completed', duration: '45ms', details: 'Final water mask extracted with zero cloud occlusion error.' }
    ],
    visuals: {
      baseImage1: "url('/imagery/flood_optical.jpg') center/cover no-repeat",
      baseImage2: "url('/imagery/sar_radar.jpg') center/cover no-repeat",
      maskOverlay: {
        color: 'rgba(56, 189, 248, 0.6)',
        elements: [
          { type: 'polygon', coords: '30,25 70,25 80,75 25,80', label: 'Cloud-Penetrating Fused Water Mask' }
        ]
      },
      boundingBoxes: [
        { x: 25, y: 20, w: 58, h: 62, label: 'SAR Water Detection (96.1% Conf)', color: '#0ea5e9' }
      ]
    }
  },
  {
    id: 'sc-single-vqa',
    title: 'Single-Image GeoChat — Land Use & Infrastructure',
    query: 'What critical infrastructure and land use types are visible in this scene?',
    modality: 'single-optical',
    image1Name: 'Sentinel2_TrueColor_10m.tif',
    image1Type: 'Optical',
    answer: 'GEOCHAT SCENE UNDERSTANDING:\nThis high-resolution 10-meter scene captures a coastal river estuary interface:\n\n1. Central Waterway: An estuary navigable channel running north-to-south (dark blue low reflectance, width ~320m).\n2. Agricultural Polders: Eastern section contains geometric paddy fields (high NIR reflectance, green/yellow spectrum).\n3. Urban Settlement: Western bank shows clustered residential buildings, asphalt roadways, and dock facilities.\n4. Critical Facilities: Bridges crossing the channel at coordinates (9.525°N, 76.360°E) and an adjacent pumping station.',
    confidence: 94.2,
    trace: [
      { name: 'GeoTIFF Decoding & Normalization', status: 'completed', duration: '14ms', details: 'Loaded 4 spectral bands (B2, B3, B4, B8). Contrast stretched with 2% percentile clip.' },
      { name: 'GeoChat-7B Vision Tokenizer', status: 'completed', duration: '120ms', details: 'Patch embedding ViT-L/14 tokenized image into 256 spatial tokens.' },
      { name: 'Vision-Language Decoding', status: 'completed', duration: '310ms', details: 'Autoregressive generation conditioned on geographic prompt. Zero-shot recognition of polders & waterways.' },
      { name: 'Spatial Grounding Alignment', status: 'completed', duration: '35ms', details: 'Aligned bounding box logits with true UTM coordinates.' }
    ],
    visuals: {
      baseImage1: "url('/imagery/flood_optical.jpg') center/cover no-repeat",
      maskOverlay: {
        color: 'rgba(34, 197, 94, 0.45)',
        elements: [
          { type: 'polygon', coords: '55,15 90,15 90,85 60,85', label: 'Agricultural Polders' }
        ]
      },
      boundingBoxes: [
        { x: 12, y: 15, w: 35, h: 70, label: 'Urban Coastal Zone', color: '#f43f5e' },
        { x: 45, y: 10, w: 18, h: 80, label: 'Navigable River Estuary', color: '#38bdf8' }
      ]
    }
  }
];
