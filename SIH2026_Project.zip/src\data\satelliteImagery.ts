// High-fidelity SVG/Canvas textures and visual layer definitions for satellite imagery

export interface LayerMetadata {
  id: string;
  name: string;
  description: string;
  badge: string;
  bands: string;
  colorScheme: string;
}

export const SATELLITE_LAYERS: LayerMetadata[] = [
  {
    id: 'optical',
    name: 'Sentinel-2 True Color (RGB)',
    description: 'Natural visible spectrum bands (B4-Red, B3-Green, B2-Blue). High 10m spatial resolution.',
    badge: '10m / Multi-Spectral',
    bands: 'B4 (665nm), B3 (560nm), B2 (490nm)',
    colorScheme: 'Natural Color'
  },
  {
    id: 'nir',
    name: 'False Color Infrared (NIR)',
    description: 'Near-Infrared band (B8) highlighting vegetation in deep crimson red and water in pitch black.',
    badge: 'Vegetation & Biomass',
    bands: 'B8 (842nm), B4 (665nm), B3 (560nm)',
    colorScheme: 'Infrared / CIR'
  },
  {
    id: 'sar',
    name: 'Sentinel-1 C-Band SAR (Radar)',
    description: 'Active microwave radar backscatter. All-weather, day/night cloud penetrating radar imagery.',
    badge: 'Active Radar / All-Weather',
    bands: 'VV + VH Polarizations (C-Band 5.4 GHz)',
    colorScheme: 'Grayscale Backscatter (dB)'
  },
  {
    id: 'ndwi',
    name: 'Normalized Water Index (NDWI)',
    description: 'Calculates (Green - NIR) / (Green + NIR) to delineate surface water bodies with high contrast.',
    badge: 'Water Extraction',
    bands: '(B3 - B8) / (B3 + B8)',
    colorScheme: 'Cyan / Deep Blue Hydro'
  },
  {
    id: 'change',
    name: 'AI Change Detection Heatmap',
    description: 'Bitemporal difference mask output from Siamese ResNet-50 showing new inundation in red/amber.',
    badge: 'AI Hazard Mask',
    bands: 'Siamese Cosine Feature Distance',
    colorScheme: 'Hazard Thermal Gradient'
  }
];

export const SATELLITE_PASSES = [
  {
    mission: 'Sentinel-1A (SAR GRD)',
    orbit: 'Descending #142',
    timestamp: '03 Sep 2026, 06:14 UTC',
    incidenceAngle: '38.4°',
    status: 'Fresh Acquisition'
  },
  {
    mission: 'Sentinel-2B (MSI L2A)',
    orbit: 'Relative Orbit #062',
    timestamp: '03 Sep 2026, 05:22 UTC',
    cloudCover: '68.2%',
    status: 'Cloud Impacted'
  },
  {
    mission: 'Cartosat-3 (PAN/MX)',
    orbit: 'Pass #3019',
    timestamp: '02 Sep 2026, 11:00 UTC',
    resolution: '0.28m PAN',
    status: 'Archived Baseline'
  }
];
