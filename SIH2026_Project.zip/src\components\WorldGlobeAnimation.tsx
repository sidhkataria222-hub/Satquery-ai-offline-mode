import React, { useRef, useEffect, useState } from 'react';
import { WatchZone } from '../types';
import { Globe, Compass, Radio, Satellite, ShieldAlert, Sparkles, Navigation } from 'lucide-react';

interface WorldGlobeAnimationProps {
  watchZones: WatchZone[];
  selectedZone: WatchZone;
  onSelectZone: (zone: WatchZone) => void;
  isOffline: boolean;
}

// Major world landmass polygon coordinates [lat, lng] for true vector globe rendering
const WORLD_CONTINENTS: [number, number][][] = [
  // India & South Asia subcontinent
  [
    [35, 74], [32, 76], [28, 77], [26, 80], [24, 88], [22, 89], [21, 87], [18, 84],
    [13, 80], [8, 77], [9, 76], [15, 73], [20, 72], [24, 69], [28, 70], [32, 73], [35, 74]
  ],
  // Sri Lanka
  [[9, 80], [7, 81], [6, 80], [8, 79], [9, 80]],
  // Southeast Asia & East Asia
  [
    [22, 98], [15, 100], [10, 99], [4, 103], [1, 104], [6, 108], [14, 109], [20, 107],
    [22, 114], [30, 122], [38, 120], [42, 130], [50, 140], [55, 135], [52, 120], [45, 100],
    [35, 90], [28, 89], [25, 94], [22, 98]
  ],
  // Middle East & Arabian Peninsula
  [
    [30, 35], [32, 45], [30, 50], [25, 55], [22, 60], [15, 53], [12, 45], [20, 40],
    [28, 35], [30, 35]
  ],
  // Africa
  [
    [36, -5], [37, 10], [32, 25], [30, 32], [22, 38], [12, 51], [2, 45], [-10, 40],
    [-25, 33], [-34, 18], [-33, 26], [-20, 12], [-5, 11], [5, 2], [5, -4], [10, -14],
    [15, -17], [25, -15], [35, -5], [36, -5]
  ],
  // Europe
  [
    [36, -5], [43, -9], [48, -5], [54, 8], [60, 5], [68, 15], [70, 28], [60, 30],
    [55, 38], [45, 35], [40, 26], [38, 15], [36, -5]
  ],
  // Australia
  [
    [-12, 131], [-15, 136], [-12, 142], [-22, 150], [-32, 152], [-38, 145], [-35, 138],
    [-34, 122], [-22, 114], [-15, 123], [-12, 131]
  ]
];

// Satellites with orbital inclinations and speeds
interface SatelliteOrbit {
  name: string;
  altitude: number; // radius factor
  inclination: number; // degrees
  speed: number;
  color: string;
  angle: number;
}

export const WorldGlobeAnimation: React.FC<WorldGlobeAnimationProps> = ({
  watchZones,
  selectedZone,
  onSelectZone,
  isOffline
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [rotation, setRotation] = useState({ yaw: -76, pitch: 15 }); // centered on India
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [isAutoSpin, setIsAutoSpin] = useState(true);
  const [hoveredZone, setHoveredZone] = useState<WatchZone | null>(null);

  // Satellites state
  const satellitesRef = useRef<SatelliteOrbit[]>([
    { name: 'Sentinel-1A (SAR)', altitude: 1.25, inclination: 45, speed: 0.012, color: '#f59e0b', angle: 0.4 },
    { name: 'Sentinel-2B (MSI)', altitude: 1.35, inclination: -55, speed: 0.009, color: '#10b981', angle: 1.8 },
    { name: 'RISAT-1B (Radar)', altitude: 1.18, inclination: 25, speed: 0.015, color: '#06b6d4', angle: 3.2 },
    { name: 'Cartosat-3 (Optical)', altitude: 1.28, inclination: -75, speed: 0.011, color: '#a855f7', angle: 4.5 }
  ]);

  // Center on selected zone whenever it changes
  useEffect(() => {
    if (selectedZone) {
      setRotation({
        yaw: -selectedZone.lng,
        pitch: Math.max(-40, Math.min(40, selectedZone.lat))
      });
    }
  }, [selectedZone.id]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      const radius = Math.min(width, height) * 0.38;
      const cx = width / 2;
      const cy = height / 2;

      ctx.clearRect(0, 0, width, height);

      // Auto-spin if not dragging
      if (isAutoSpin && !isDragging) {
        setRotation(prev => ({
          ...prev,
          yaw: prev.yaw - 0.12
        }));
      }

      // Update satellites
      satellitesRef.current.forEach(sat => {
        sat.angle += sat.speed;
      });

      const yawRad = (rotation.yaw * Math.PI) / 180;
      const pitchRad = (rotation.pitch * Math.PI) / 180;

      // 3D Spherical Projection Function
      const project = (lat: number, lng: number, rFactor = 1): { x: number; y: number; visible: boolean; depth: number } => {
        const phi = (lat * Math.PI) / 180;
        const theta = (lng * Math.PI) / 180;

        // 3D Cartesian on unit sphere
        const x0 = Math.cos(phi) * Math.sin(theta);
        const y0 = Math.sin(phi);
        const z0 = Math.cos(phi) * Math.cos(theta);

        // Rotate by Yaw (around Y axis)
        const x1 = x0 * Math.cos(yawRad) + z0 * Math.sin(yawRad);
        const y1 = y0;
        const z1 = -x0 * Math.sin(yawRad) + z0 * Math.cos(yawRad);

        // Rotate by Pitch (around X axis)
        const x2 = x1;
        const y2 = y1 * Math.cos(pitchRad) - z1 * Math.sin(pitchRad);
        const z2 = y1 * Math.sin(pitchRad) + z1 * Math.cos(pitchRad);

        const r = radius * rFactor;
        const screenX = cx + x2 * r;
        const screenY = cy - y2 * r;
        const visible = z2 > 0; // Front side of sphere

        return { x: screenX, y: screenY, visible, depth: z2 };
      };

      // 1. Atmospheric Outer Glow
      const glowGrad = ctx.createRadialGradient(cx, cy, radius * 0.85, cx, cy, radius * 1.3);
      glowGrad.addColorStop(0, 'rgba(6, 182, 212, 0.08)');
      glowGrad.addColorStop(0.5, 'rgba(16, 185, 129, 0.05)');
      glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 1.3, 0, Math.PI * 2);
      ctx.fill();

      // 2. Globe Dark Base Sphere with Shading
      const sphereGrad = ctx.createRadialGradient(
        cx - radius * 0.3,
        cy - radius * 0.3,
        radius * 0.1,
        cx,
        cy,
        radius
      );
      sphereGrad.addColorStop(0, '#091522');
      sphereGrad.addColorStop(0.7, '#040911');
      sphereGrad.addColorStop(1, '#020509');

      ctx.fillStyle = sphereGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fill();

      // Globe Rim Ring
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.stroke();

      // 3. Latitude & Longitude Coordinate Grid Lines
      ctx.strokeStyle = 'rgba(30, 41, 59, 0.6)';
      ctx.lineWidth = 1;

      // Parallels (Latitudes)
      for (let lat = -60; lat <= 60; lat += 30) {
        ctx.beginPath();
        let first = true;
        for (let lng = -180; lng <= 180; lng += 10) {
          const pt = project(lat, lng);
          if (pt.visible) {
            if (first) {
              ctx.moveTo(pt.x, pt.y);
              first = false;
            } else {
              ctx.lineTo(pt.x, pt.y);
            }
          } else {
            first = true;
          }
        }
        ctx.stroke();
      }

      // Meridians (Longitudes)
      for (let lng = -180; lng <= 180; lng += 30) {
        ctx.beginPath();
        let first = true;
        for (let lat = -80; lat <= 80; lat += 5) {
          const pt = project(lat, lng);
          if (pt.visible) {
            if (first) {
              ctx.moveTo(pt.x, pt.y);
              first = false;
            } else {
              ctx.lineTo(pt.x, pt.y);
            }
          } else {
            first = true;
          }
        }
        ctx.stroke();
      }

      // Equator Highlight
      ctx.strokeStyle = 'rgba(16, 185, 129, 0.25)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      let eqFirst = true;
      for (let lng = -180; lng <= 180; lng += 5) {
        const pt = project(0, lng);
        if (pt.visible) {
          if (eqFirst) {
            ctx.moveTo(pt.x, pt.y);
            eqFirst = false;
          } else {
            ctx.lineTo(pt.x, pt.y);
          }
        } else {
          eqFirst = true;
        }
      }
      ctx.stroke();

      // 4. Continents & Landmasses
      ctx.fillStyle = 'rgba(15, 30, 48, 0.9)';
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.35)';
      ctx.lineWidth = 1.2;

      WORLD_CONTINENTS.forEach(polygon => {
        ctx.beginPath();
        let polyVisible = false;
        polygon.forEach((coord, idx) => {
          const pt = project(coord[0], coord[1]);
          if (pt.visible) {
            polyVisible = true;
            if (idx === 0) ctx.moveTo(pt.x, pt.y);
            else ctx.lineTo(pt.x, pt.y);
          }
        });
        if (polyVisible) {
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
      });

      // 5. Orbital Satellite Rings & Beams
      satellitesRef.current.forEach(sat => {
        const satLat = Math.sin(sat.angle) * sat.inclination;
        const satLng = ((sat.angle * 180) / Math.PI) * 1.5;
        const pt = project(satLat, satLng, sat.altitude);

        // Ground track line
        const groundPt = project(satLat, satLng, 1.0);
        if (pt.visible && groundPt.visible) {
          // Beam from satellite to Earth
          ctx.strokeStyle = `${sat.color}40`;
          ctx.setLineDash([2, 4]);
          ctx.beginPath();
          ctx.moveTo(pt.x, pt.y);
          ctx.lineTo(groundPt.x, groundPt.y);
          ctx.stroke();
          ctx.setLineDash([]);

          // Ground footprint circle
          ctx.fillStyle = `${sat.color}20`;
          ctx.beginPath();
          ctx.arc(groundPt.x, groundPt.y, 8, 0, Math.PI * 2);
          ctx.fill();
        }

        // Satellite Body
        if (pt.visible) {
          ctx.fillStyle = sat.color;
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 3.5, 0, Math.PI * 2);
          ctx.fill();

          // Satellite solar panel wings
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(pt.x - 7, pt.y);
          ctx.lineTo(pt.x + 7, pt.y);
          ctx.stroke();

          // Satellite Label
          ctx.fillStyle = '#94a3b8';
          ctx.font = '9px monospace';
          ctx.fillText(sat.name.split(' ')[0], pt.x + 8, pt.y + 3);
        }
      });

      // 6. Watch Zone Hotspots on Earth
      watchZones.forEach(zone => {
        const pt = project(zone.lat, zone.lng);
        if (pt.visible) {
          const isSelected = selectedZone.id === zone.id;
          const isAlert = zone.status === 'alert';
          const color = isAlert ? '#ef4444' : isSelected ? '#38bdf8' : '#10b981';

          // Pulsing wave ring
          const time = Date.now() * 0.003;
          const waveSize = 8 + Math.sin(time + zone.lat) * 6;

          ctx.strokeStyle = `${color}60`;
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, waveSize, 0, Math.PI * 2);
          ctx.stroke();

          // Core dot
          ctx.fillStyle = color;
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, isSelected ? 5.5 : 4, 0, Math.PI * 2);
          ctx.fill();

          // Target pointer line & text label
          ctx.strokeStyle = color;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(pt.x, pt.y);
          ctx.lineTo(pt.x + 18, pt.y - 14);
          ctx.lineTo(pt.x + 45, pt.y - 14);
          ctx.stroke();

          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 10px monospace';
          ctx.fillText(zone.name.split(' ')[0], pt.x + 20, pt.y - 18);

          if (isAlert) {
            ctx.fillStyle = '#f87171';
            ctx.font = 'bold 9px monospace';
            ctx.fillText('+198% FLOOD', pt.x + 20, pt.y - 6);
          }
        }
      });

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [rotation, isAutoSpin, isDragging, watchZones, selectedZone]);

  // Mouse drag handlers to rotate globe
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setIsAutoSpin(false);
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStart.x;
    const dy = e.clientY - dragStart.y;

    setRotation(prev => ({
      yaw: prev.yaw + dx * 0.4,
      pitch: Math.max(-65, Math.min(65, prev.pitch - dy * 0.4))
    }));

    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div className="relative w-full h-full bg-[#020509] rounded-2xl border border-slate-800 overflow-hidden flex flex-col shadow-2xl">
      {/* Top Header Overlay */}
      <div className="absolute top-4 left-4 right-4 z-10 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        <div className="flex items-center space-x-2.5 bg-slate-900/85 border border-slate-700/80 px-3 py-1.5 rounded-xl backdrop-blur-md shadow-xl pointer-events-auto">
          <Globe className="h-4 w-4 text-cyan-400 animate-pulse" />
          <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
            Orthographic Earth Orbital Tracker
          </span>
          <span className="text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800 px-1.5 py-0.2 rounded">
            4 Satellites Tracked
          </span>
        </div>

        <div className="flex items-center space-x-2 pointer-events-auto">
          <button
            onClick={() => setIsAutoSpin(prev => !prev)}
            className={`px-2.5 py-1 rounded-lg text-xs font-mono border backdrop-blur-md transition-all ${
              isAutoSpin
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 font-bold'
                : 'bg-slate-900/80 border-slate-700 text-slate-400 hover:text-white'
            }`}
          >
            {isAutoSpin ? 'Auto-Orbit: ON' : 'Auto-Orbit: OFF'}
          </button>
          <button
            onClick={() => {
              setRotation({ yaw: -76, pitch: 15 }); // Reset to India
            }}
            className="px-2.5 py-1 rounded-lg text-xs font-mono bg-slate-900/80 border border-slate-700 hover:border-slate-600 text-slate-300 hover:text-white backdrop-blur-md"
            title="Reset focus to Indian Subcontinent"
          >
            Center India
          </button>
        </div>
      </div>

      {/* Main Canvas */}
      <div 
        className="w-full flex-1 cursor-grab active:cursor-grabbing flex items-center justify-center relative"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <canvas
          ref={canvasRef}
          width={700}
          height={480}
          className="w-full h-full max-h-[480px] object-contain"
        />

        {/* Tactical Crosshair overlay */}
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-10">
          <div className="w-80 h-80 rounded-full border border-cyan-400"></div>
          <div className="absolute w-full h-[1px] bg-cyan-400"></div>
          <div className="absolute h-full w-[1px] bg-cyan-400"></div>
        </div>
      </div>

      {/* Bottom Floating Hotspot Selector */}
      <div className="absolute bottom-4 left-4 right-4 z-10 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        <div className="flex flex-wrap gap-1.5 pointer-events-auto">
          <span className="text-[10px] font-mono text-slate-400 uppercase bg-slate-950/80 px-2 py-1 rounded-md border border-slate-800 self-center">
            Hotspots:
          </span>
          {watchZones.map(zone => (
            <button
              key={zone.id}
              onClick={() => onSelectZone(zone)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-1.5 shadow-lg ${
                selectedZone.id === zone.id
                  ? 'bg-cyan-500/20 border border-cyan-400 text-cyan-300 ring-1 ring-cyan-400/50'
                  : 'bg-slate-900/80 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-850'
              }`}
            >
              <span className={`h-2 w-2 rounded-full ${
                zone.status === 'alert' ? 'bg-red-500 animate-ping' : 'bg-emerald-400'
              }`}></span>
              <span>{zone.name.split(' ')[0]}</span>
            </button>
          ))}
        </div>

        <div className="text-[10px] font-mono text-slate-400 bg-slate-950/80 px-3 py-1 rounded-lg border border-slate-800 backdrop-blur-md pointer-events-auto">
          Drag globe to rotate • Hover hotspots to track
        </div>
      </div>
    </div>
  );
};
