import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { 
  WatchZone, 
  AlertItem 
} from '../types';
import { 
  Layers, 
  MapPin, 
  Plus, 
  ShieldAlert, 
  Calendar, 
  Compass, 
  Satellite, 
  CheckCircle2, 
  Sliders, 
  X, 
  ExternalLink,
  HardDriveDownload,
  Activity,
  Flame,
  TreePine,
  Building2,
  Droplets
} from 'lucide-react';

interface WatchZoneManagerProps {
  watchZones: WatchZone[];
  selectedZone: WatchZone | null;
  onSelectZone: (zone: WatchZone) => void;
  onCreateZone: (newZone: WatchZone) => void;
  isCreateModalOpen: boolean;
  setIsCreateModalOpen: (open: boolean) => void;
  initialCoords?: [number, number][];
  onFocusMap: (zone: WatchZone) => void;
  onAskAIAboutZone: (zone: WatchZone) => void;
}

export const WatchZoneManager: React.FC<WatchZoneManagerProps> = ({
  watchZones,
  selectedZone,
  onSelectZone,
  onCreateZone,
  isCreateModalOpen,
  setIsCreateModalOpen,
  initialCoords,
  onFocusMap,
  onAskAIAboutZone
}) => {
  // New Zone Form State
  const [name, setName] = useState('');
  const [region, setRegion] = useState('');
  const [monitoringTypes, setMonitoringTypes] = useState<('flooding' | 'vegetation_change' | 'urban_expansion' | 'fire_burn')[]>(['flooding']);
  const [satellites, setSatellites] = useState<string[]>(['Sentinel-1 SAR', 'Sentinel-2 Optical']);
  const [thresholdPercent, setThresholdPercent] = useState<number>(15);
  const [frequency, setFrequency] = useState('Every new satellite pass');

  const handleToggleMonitoring = (type: 'flooding' | 'vegetation_change' | 'urban_expansion' | 'fire_burn') => {
    setMonitoringTypes(prev => 
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const handleToggleSatellite = (sat: string) => {
    setSatellites(prev =>
      prev.includes(sat) ? prev.filter(s => s !== sat) : [...prev, sat]
    );
  };

  const handleSubmitNewZone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    // Default polygon if not drawn: around southern India
    const coords: [number, number][] = initialCoords && initialCoords.length >= 3 ? initialCoords : [
      [9.54, 76.31],
      [9.55, 76.37],
      [9.51, 76.41],
      [9.46, 76.38]
    ];

    const centerLat = coords.reduce((acc, c) => acc + c[0], 0) / coords.length;
    const centerLng = coords.reduce((acc, c) => acc + c[1], 0) / coords.length;

    const newZone: WatchZone = {
      id: `zone-${Date.now()}`,
      name,
      region: region || 'Autonomous Geographic Region',
      lat: centerLat,
      lng: centerLng,
      zoom: 12,
      polygonCoords: coords,
      areaKm2: Number((Math.random() * 30 + 15).toFixed(1)),
      satellites,
      monitoringTypes,
      thresholdPercent,
      status: 'monitoring',
      baselineDate: '03 Sep 2026',
      lastProcessedDate: 'Just now (Initial pass)',
      latestMetrics: {
        inundatedAreaKm2: 0.45,
        baselineAreaKm2: 0.45,
        deltaPercent: 0,
        confidence: 94.0,
        affectedStructures: 0,
        severity: 'LOW'
      },
      timeline: [
        { date: '03 Sep', valueKm2: 0.45, rainfallMm: 10, label: 'Baseline acquisition established' }
      ],
      description: `Active persistent monitoring for ${monitoringTypes.join(', ')} with alert threshold ${thresholdPercent}%.`
    };

    onCreateZone(newZone);
    setIsCreateModalOpen(false);

    // Reset Form
    setName('');
    setRegion('');

    // Confetti celebration for creating a new Watch Zone
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.6 }
    });
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 rounded-xl border border-slate-800 shadow-xl overflow-hidden">
      {/* Top Header */}
      <div className="px-4 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Layers className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Autonomous Watch Zones
            </h3>
            <p className="text-[10px] text-slate-400">
              Persistent Multi-Satellite Area Observation ({watchZones.length} Active)
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-950/40 transition-all"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>New Watch Zone</span>
        </button>
      </div>

      {/* Watch Zones List */}
      <div className="flex-1 p-4 space-y-3 overflow-y-auto">
        {watchZones.map(zone => {
          const isSelected = selectedZone?.id === zone.id;
          const isAlert = zone.status === 'alert';

          return (
            <div
              key={zone.id}
              onClick={() => onSelectZone(zone)}
              className={`p-3.5 rounded-xl border text-sm transition-all cursor-pointer ${
                isSelected
                  ? 'bg-slate-900/90 border-cyan-500/60 shadow-xl shadow-cyan-950/20 ring-1 ring-cyan-500/30'
                  : 'bg-slate-900/50 border-slate-800/80 hover:bg-slate-850 hover:border-slate-700'
              }`}
            >
              {/* Top row */}
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center space-x-2">
                  <span className={`h-2.5 w-2.5 rounded-full ${
                    isAlert ? 'bg-red-500 animate-ping' : 'bg-emerald-400'
                  }`} />
                  <h4 className="font-bold text-white text-sm">{zone.name}</h4>
                </div>

                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-md font-bold uppercase ${
                  isAlert 
                    ? 'bg-red-500/20 text-red-300 border border-red-500/30' 
                    : 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                }`}>
                  {isAlert ? 'CRITICAL ALERT' : 'ACTIVE OBSERVATION'}
                </span>
              </div>

              {/* Sub-region and area */}
              <div className="flex items-center space-x-3 text-xs text-slate-400 mb-3">
                <span className="flex items-center gap-1 text-[11px]">
                  <MapPin className="h-3 w-3 text-slate-500" />
                  {zone.region}
                </span>
                <span>•</span>
                <span className="font-mono text-[11px] text-slate-300">{zone.areaKm2} km² ROI</span>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-3 gap-2 bg-slate-950/60 p-2.5 rounded-lg border border-slate-850 text-xs font-mono mb-3">
                <div>
                  <div className="text-slate-500 text-[9px] uppercase">Inundated Area</div>
                  <div className="font-bold text-white text-sm">
                    {zone.latestMetrics.inundatedAreaKm2} km²
                  </div>
                </div>

                <div>
                  <div className="text-slate-500 text-[9px] uppercase">Baseline Delta</div>
                  <div className={`font-bold text-sm ${
                    zone.latestMetrics.deltaPercent > zone.thresholdPercent ? 'text-red-400' : 'text-emerald-400'
                  }`}>
                    +{zone.latestMetrics.deltaPercent}%
                  </div>
                </div>

                <div>
                  <div className="text-slate-500 text-[9px] uppercase">Confidence</div>
                  <div className="font-bold text-cyan-400 text-sm">
                    {zone.latestMetrics.confidence}%
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-xs">
                <div className="flex items-center space-x-2 text-[10px] font-mono text-slate-400">
                  <Satellite className="h-3 w-3 text-slate-500" />
                  <span>{zone.satellites.join(', ')}</span>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onFocusMap(zone);
                    }}
                    className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono transition-colors"
                  >
                    View Map
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onAskAIAboutZone(zone);
                    }}
                    className="px-2 py-1 rounded bg-emerald-950/70 border border-emerald-600/40 hover:bg-emerald-900/70 text-emerald-300 text-xs font-mono transition-colors"
                  >
                    Ask AI
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* CREATE WATCH ZONE MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5 text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
                  <Compass className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Create New Watch Zone</h3>
                  <p className="text-xs text-slate-400">Establish persistent orbital monitoring over a geographic ROI</p>
                </div>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitNewZone} className="space-y-4 text-xs font-sans">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Zone Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Godavari Delta Vulnerability Zone"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Geographic Region / State
                </label>
                <input
                  type="text"
                  placeholder="e.g., East Godavari, Andhra Pradesh"
                  value={region}
                  onChange={e => setRegion(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Monitoring Types */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  Phenomena to Monitor
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <label className={`flex items-center space-x-2 p-2.5 rounded-lg border cursor-pointer transition-all ${
                    monitoringTypes.includes('flooding')
                      ? 'bg-cyan-950/40 border-cyan-500 text-cyan-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}>
                    <input
                      type="checkbox"
                      checked={monitoringTypes.includes('flooding')}
                      onChange={() => handleToggleMonitoring('flooding')}
                      className="hidden"
                    />
                    <Droplets className="h-4 w-4 text-cyan-400" />
                    <span className="font-semibold text-xs">Flooding & Inundation</span>
                  </label>

                  <label className={`flex items-center space-x-2 p-2.5 rounded-lg border cursor-pointer transition-all ${
                    monitoringTypes.includes('vegetation_change')
                      ? 'bg-emerald-950/40 border-emerald-500 text-emerald-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}>
                    <input
                      type="checkbox"
                      checked={monitoringTypes.includes('vegetation_change')}
                      onChange={() => handleToggleMonitoring('vegetation_change')}
                      className="hidden"
                    />
                    <TreePine className="h-4 w-4 text-emerald-400" />
                    <span className="font-semibold text-xs">Vegetation Decline</span>
                  </label>

                  <label className={`flex items-center space-x-2 p-2.5 rounded-lg border cursor-pointer transition-all ${
                    monitoringTypes.includes('urban_expansion')
                      ? 'bg-purple-950/40 border-purple-500 text-purple-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}>
                    <input
                      type="checkbox"
                      checked={monitoringTypes.includes('urban_expansion')}
                      onChange={() => handleToggleMonitoring('urban_expansion')}
                      className="hidden"
                    />
                    <Building2 className="h-4 w-4 text-purple-400" />
                    <span className="font-semibold text-xs">Urban Sprawl & Roads</span>
                  </label>

                  <label className={`flex items-center space-x-2 p-2.5 rounded-lg border cursor-pointer transition-all ${
                    monitoringTypes.includes('fire_burn')
                      ? 'bg-amber-950/40 border-amber-500 text-amber-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}>
                    <input
                      type="checkbox"
                      checked={monitoringTypes.includes('fire_burn')}
                      onChange={() => handleToggleMonitoring('fire_burn')}
                      className="hidden"
                    />
                    <Flame className="h-4 w-4 text-amber-400" />
                    <span className="font-semibold text-xs">Wildfire & Burn Scars</span>
                  </label>
                </div>
              </div>

              {/* Alert Threshold Slider */}
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Disaster Alert Escalation Threshold
                  </label>
                  <span className="font-mono text-emerald-400 font-bold">{thresholdPercent}% Change</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="50"
                  step="5"
                  value={thresholdPercent}
                  onChange={e => setThresholdPercent(Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
                <p className="text-[10px] text-slate-500 mt-1">
                  Triggers high-priority alerts when pixel difference vs baseline exceeds this ratio.
                </p>
              </div>

              {/* Satellites */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Satellite Constellations
                </label>
                <div className="flex flex-wrap gap-2">
                  {['Sentinel-1 SAR', 'Sentinel-2 Optical', 'RISAT-1B', 'Landsat-9'].map(sat => (
                    <button
                      type="button"
                      key={sat}
                      onClick={() => handleToggleSatellite(sat)}
                      className={`px-2.5 py-1 rounded-lg border text-xs font-mono transition-all ${
                        satellites.includes(sat)
                          ? 'bg-emerald-950/70 border-emerald-500 text-emerald-300 font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      {sat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-950/50"
                >
                  Confirm & Start Monitoring
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
