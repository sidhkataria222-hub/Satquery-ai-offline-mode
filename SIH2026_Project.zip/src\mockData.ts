export interface TraceStep {
  name: string;
  status: 'completed' | 'processing' | 'pending' | 'failed';
  duration?: string;
  details: string;
}

export interface Scenario {
  id: string;
  title: string;
  query: string;
  modality: 'single-optical' | 'temporal' | 'cross-modal';
  image1Name: string;
  image2Name?: string;
  image1Type: 'Optical' | 'SAR';
  image2Type?: 'Optical' | 'SAR';
  answer: string;
  confidence: number;
  agreement?: number; // Sensor agreement percentage (for cross-modal)
  trace: TraceStep[];
  // SVG drawing instructions or CSS styles representing satellite image mockups
  visuals: {
    baseImage1: string; // CSS background/gradient representing satellite view
    baseImage2?: string;
    maskOverlay?: {
      color: string;
      elements: Array<{ type: 'rect' | 'circle' | 'polygon'; coords: string; label: string }>;
    };
    boundingBoxes?: Array<{ x: number; y: number; w: number; h: number; label: string; color: string }>;
  };
}

export const SCENARIOS: Scenario[] = [
  {
    id: 'sc1',
    title: 'Single-Image Land Cover Analysis',
    query: 'Describe the land cover in this image.',
    modality: 'single-optical',
    image1Name: 'Optical_L2A_2026.tif',
    image1Type: 'Optical',
    answer: 'The image shows a diverse coastal landscape. The western section is dominated by dense urban/built-up structures (gray blocks). A significant water body (estuary) cuts through the center, showing low reflectance (dark blue). The eastern zone is primarily agricultural fields (green/yellow grid patterns) and light forest cover.',
    confidence: 94.2,
    trace: [
      { name: 'Input Validation', status: 'completed', duration: '12ms', details: 'Checked GeoTIFF resolution (10m) & CRS (EPSG:32643). Validated successfully.' },
      { name: 'Query Classification', status: 'completed', duration: '34ms', details: 'Identified task type: "Single-Image Visual Question Answering & Description".' },
      { name: 'Agent Routing', status: 'completed', duration: '45ms', details: 'Routed payload to GeoChat-7B Remote-Sensing VLM.' },
      { name: 'Model Inference', status: 'completed', duration: '320ms', details: 'VLM generated token probabilities. Detected major classes: Urban (34%), Water (28%), Agricultural (38%).' },
      { name: 'Evidence Calibration', status: 'completed', duration: '18ms', details: 'Calibrated output logits using temperature scaling. Reliability index: 0.94.' },
      { name: 'Final Answer Generation', status: 'completed', duration: '50ms', details: 'Synthesized final natural language summary report.' }
    ],
    visuals: {
      baseImage1: 'linear-gradient(135deg, #1e293b 25%, #064e3b 50%, #0c4a6e 75%)',
      maskOverlay: {
        color: 'rgba(34, 197, 94, 0.4)', // transparent green for vegetation
        elements: [
          { type: 'polygon', coords: '60,10 90,10 90,80 70,90 50,60', label: 'Vegetation' },
          { type: 'rect', coords: '10,10 40,80', label: 'Urban Grid' }
        ]
      },
      boundingBoxes: [
        { x: 10, y: 15, w: 30, h: 65, label: 'Urban Zone', color: '#ef4444' },
        { x: 42, y: 5, w: 20, h: 90, label: 'Water Estuary', color: '#3b82f6' }
      ]
    }
  },
  {
    id: 'sc2',
    title: 'Bitemporal Change Detection',
    query: 'What changed between these two dates?',
    modality: 'temporal',
    image1Name: 'Cartosat_T1_2024.tif',
    image2Name: 'Cartosat_T2_2026.tif',
    image1Type: 'Optical',
    image2Type: 'Optical',
    answer: 'Between T1 (2024) and T2 (2026), there is a significant expansion of the urban area in the northeast quadrant, replacing approximately 14.5 hectares of agricultural land. The central water body boundary remains stable, with slight seasonal vegetation drying along the riverbank.',
    confidence: 89.5,
    trace: [
      { name: 'Input Validation', status: 'completed', duration: '28ms', details: 'Validated matching dimensions (1024x1024) and co-registered coordinates. Shift error < 0.1px.' },
      { name: 'Query Classification', status: 'completed', duration: '41ms', details: 'Identified task type: "Bitemporal Change Detection & Localization".' },
      { name: 'Agent Routing', status: 'completed', duration: '60ms', details: 'Routed to Siamese Change Detection Network + ChangeChat VLM.' },
      { name: 'Siamese Pixel Match', status: 'completed', duration: '180ms', details: 'Feature extraction using ResNet-50. Generated pixel difference heatmap (Dice Coeff: 0.88).' },
      { name: 'Change Captioning VLM', status: 'completed', duration: '290ms', details: 'ChangeChat model generated text sequence conditioned on the difference feature maps.' },
      { name: 'Evidence Fusion', status: 'completed', duration: '22ms', details: 'Fused quantitative pixel diff metrics with natural language tokens. High confidence in urban expansion.' }
    ],
    visuals: {
      baseImage1: 'linear-gradient(135deg, #1e293b 30%, #14532d 60%, #0f172a 90%)',
      baseImage2: 'linear-gradient(135deg, #334155 30%, #166534 50%, #0f172a 90%)',
      maskOverlay: {
        color: 'rgba(239, 68, 68, 0.55)', // bright red for change
        elements: [
          { type: 'circle', coords: '75,30 20', label: 'New Construction Area' }
        ]
      },
      boundingBoxes: [
        { x: 55, y: 10, w: 35, h: 40, label: 'Urban Expansion Detector', color: '#f59e0b' }
      ]
    }
  },
  {
    id: 'sc3',
    title: 'Cross-Modal Fusion (Optical + SAR)',
    query: 'Use the optical and SAR images together to identify built-up and water-covered regions.',
    modality: 'cross-modal',
    image1Name: 'Sentinel2_Optical.tif',
    image2Name: 'RISAT1_SAR.tif',
    image1Type: 'Optical',
    image2Type: 'SAR',
    answer: 'By fusing the optical spectral bands with SAR backscatter intensity:\n1. Water bodies are identified in the center-south region, showing extremely low SAR backscatter (specular reflection) and high optical absorption.\n2. Built-up regions are highlighted in the north, showing high SAR double-bounce backscatter (metallic/concrete structures) and characteristic optical texture.',
    confidence: 96.1,
    agreement: 92.4,
    trace: [
      { name: 'Input Validation', status: 'completed', duration: '35ms', details: 'Aligned multispectral (4 bands) and SAR (VV/VH polarization) grids. Verified spatial overlap.' },
      { name: 'Query Classification', status: 'completed', duration: '22ms', details: 'Identified task type: "Cross-Modal Sensor Fusion & Segmentation".' },
      { name: 'Agent Routing', status: 'completed', duration: '50ms', details: 'Routed to Query-Conditioned Cross-Attention Fusion Encoder.' },
      { name: 'Feature Extraction', status: 'completed', duration: '140ms', details: 'Extracted optical features (ViT-L/14) and SAR backscatter features (ResNet-SAR).' },
      { name: 'Cross-Attention Fusion', status: 'completed', duration: '110ms', details: 'Calculated attention weights: Optical (62% weight for color/spectral), SAR (38% weight for double-bounce texture).' },
      { name: 'Evidence Output & Calibration', status: 'completed', duration: '30ms', details: 'Analyzed sensor agreement. Both optical absorption and SAR specular reflections confirm the water body boundary.' }
    ],
    visuals: {
      baseImage1: 'linear-gradient(135deg, #1e293b 20%, #065f46 50%, #0f172a 80%)', // optical representation
      baseImage2: 'repeating-linear-gradient(45deg, #334155, #334155 10px, #1e293b 10px, #1e293b 20px)', // SAR striped/noise representation
      maskOverlay: {
        color: 'rgba(59, 130, 246, 0.45)', // blue for water classification
        elements: [
          { type: 'polygon', coords: '20,70 80,70 90,95 10,95', label: 'Fused Water Area' }
        ]
      },
      boundingBoxes: [
        { x: 10, y: 5, w: 80, h: 40, label: 'High Density Built-up (Double Bounce)', color: '#a855f7' }
      ]
    }
  }
];
