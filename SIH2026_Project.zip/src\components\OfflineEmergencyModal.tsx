import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { 
  OfflinePackageState, 
  SyncOperation, 
  WatchZone 
} from '../types';
import { 
  HardDriveDownload, 
  Wifi, 
  WifiOff, 
  Database, 
  Cpu, 
  CheckCircle2, 
  RefreshCw, 
  X, 
  FolderArchive, 
  Layers, 
  ShieldAlert,
  ArrowUpRight,
  Clock,
  Download,
  FileJson,
  Radio,
  Sparkles
} from 'lucide-react';

interface OfflineEmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  isOffline: boolean;
  onToggleOffline: () => void;
  offlinePackage: OfflinePackageState;
  onDownloadPackage: () => void;
  syncQueue: SyncOperation[];
  onTriggerSync: () => void;
  isSyncing: boolean;
  watchZones: WatchZone[];
}

export const OfflineEmergencyModal: React.FC<OfflineEmergencyModalProps> = ({
  isOpen,
  onClose,
  isOffline,
  onToggleOffline,
  offlinePackage,
  onDownloadPackage,
  syncQueue,
  onTriggerSync,
  isSyncing,
  watchZones
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-6 text-slate-100 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-xl border ${
              isOffline
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-400'
                : 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
            }`}>
              <FolderArchive className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Emergency Edge Package & Offline Operation
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded uppercase font-bold ${
                  isOffline
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                }`}>
                  {isOffline ? 'Offline Mode Active' : 'Online Sync Active'}
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Self-contained deployment package for zero-connectivity field operations
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* 1. Status Banner */}
        <div className={`p-4 rounded-xl border flex items-center justify-between ${
          isOffline
            ? 'bg-amber-950/30 border-amber-500/40 text-amber-200'
            : 'bg-slate-950/70 border-slate-800 text-slate-300'
        }`}>
          <div className="space-y-1">
            <div className="flex items-center gap-2 font-bold text-sm">
              {isOffline ? (
                <>
                  <WifiOff className="h-4 w-4 text-amber-400 animate-pulse" />
                  <span>DISCONNECTED (Edge Mode Active)</span>
                </>
              ) : (
                <>
                  <Wifi className="h-4 w-4 text-emerald-400" />
                  <span>CONNECTED TO SATELLITE CLOUD</span>
                </>
              )}
            </div>
            <p className="text-xs text-slate-400 font-mono">
              {isOffline
                ? 'Using cached Sentinel GeoTIFFs, quantized ONNX models, and local SQLite database.'
                : 'Live access to Sentinel-1, Sentinel-2, ISRO RISAT passes & cloud GPUs.'}
            </p>
          </div>

          <button
            onClick={onToggleOffline}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
              isOffline
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                : 'bg-amber-600 hover:bg-amber-500 text-white'
            }`}
          >
            {isOffline ? 'Switch to Online' : 'Simulate Offline Cut'}
          </button>
        </div>

        {/* 2. Mission Package Builder */}
        <div className="bg-slate-950/70 rounded-xl border border-slate-800 p-4 space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-slate-400 font-bold uppercase text-[11px] flex items-center gap-1.5">
              <Database className="h-3.5 w-3.5 text-cyan-400" />
              Emergency Mission Package Specification
            </span>
            <span className="text-slate-400 text-[10px]">
              {offlinePackage.packageSizeMb} MB Total
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-slate-300">
            <div className="space-y-1.5">
              <div className="flex items-center gap-1 text-white font-bold">
                <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                <span>Offline Vector & Satellite Tiles</span>
              </div>
              <p className="text-[10px] text-slate-500">
                10m resolution raster tiles for {watchZones.length} Watch Zones (zoom levels 8 to 15).
              </p>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center gap-1 text-white font-bold">
                <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                <span>Cached Telemetry & GeoTIFFs</span>
              </div>
              <p className="text-[10px] text-slate-500">
                14 recent Sentinel-1 SAR & Sentinel-2 Optical acquisitions + historical baselines.
              </p>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center gap-1 text-white font-bold">
                <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                <span>Quantized Edge Models</span>
              </div>
              <p className="text-[10px] text-slate-500">
                GeoChat INT8 (1.4 GB), Siamese FloodSeg FP16 (380 MB), SAR Classifier (120 MB).
              </p>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center gap-1 text-white font-bold">
                <CheckCircle2 className="h-3 w-3 text-emerald-400" />
                <span>Local Embedded SQLite DB</span>
              </div>
              <p className="text-[10px] text-slate-500">
                Persistent local schema storing offline inferences, annotations & sync queue.
              </p>
            </div>
          </div>

          {/* Download Progress Bar */}
          <div className="pt-2">
            {offlinePackage.isDownloading ? (
              <div className="space-y-1.5">
                <div className="flex justify-between text-[11px] text-cyan-400 font-bold">
                  <span>Downloading Mission Package...</span>
                  <span>{offlinePackage.progress}%</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-cyan-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${offlinePackage.progress}%` }}
                  />
                </div>
              </div>
            ) : offlinePackage.isDownloaded ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between bg-emerald-950/40 border border-emerald-500/30 p-2.5 rounded-lg text-emerald-300">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                    Mission package ready on local disk ({offlinePackage.packageSizeMb} MB).
                  </span>
                  <span className="text-[10px] text-slate-400">Synced: {offlinePackage.lastSyncTime}</span>
                </div>

                {/* Nepal Disaster Mission Pack Quick Cache Action */}
                <div className="bg-cyan-950/40 border border-cyan-500/30 p-2.5 rounded-lg flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5 text-cyan-300 font-bold text-xs">
                      <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
                      <span>Nepal Flood Emergency Mission Pack</span>
                      <span className="text-[9px] bg-cyan-500/20 text-cyan-300 px-1 py-0.2 rounded border border-cyan-500/30">Zero Net Armed</span>
                    </div>
                    <p className="text-[10px] text-slate-400">
                      Pre-cached Koshi/Kathmandu Basin rasters, Balkhu SOS queue & quantized INT8 weights.
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
                        navigator.serviceWorker.controller.postMessage({ type: 'PRECACHE_EMERGENCY_PACKAGE' });
                      }
                      confetti({ particleCount: 30, spread: 50 });
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-[10px] flex items-center gap-1 shrink-0"
                  >
                    <RefreshCw className="h-3 w-3" />
                    <span>Re-verify Cache</span>
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={onDownloadPackage}
                className="w-full py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold transition-colors flex items-center justify-center space-x-2 shadow-lg shadow-cyan-950/40"
              >
                <HardDriveDownload className="h-4 w-4" />
                <span>Download Mission Package for Field Use (2.8 GB)</span>
              </button>
            )}
          </div>
        </div>

        {/* 3. Offline Sync Queue Table */}
        <div className="bg-slate-950/70 rounded-xl border border-slate-800 p-4 space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-slate-400 font-bold uppercase text-[11px] flex items-center gap-1.5">
              <RefreshCw className="h-3.5 w-3.5 text-emerald-400" />
              SQLite Disconnected Sync Queue ({syncQueue.length} Operations)
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  const exportPayload = {
                    version: '2.0-emergency-edge',
                    exportedAt: new Date().toISOString(),
                    operatingMode: isOffline ? 'OFFLINE_EDGE' : 'ONLINE_CLOUD',
                    watchZonesCount: watchZones.length,
                    watchZones: watchZones,
                    syncQueue: syncQueue,
                    offlinePackage: offlinePackage
                  };
                  const blob = new Blob([JSON.stringify(exportPayload, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `satquery-nepal-disaster-package-${Date.now()}.json`;
                  a.click();
                  URL.revokeObjectURL(url);
                }}
                className="px-2.5 py-1 rounded-md text-[11px] font-bold flex items-center space-x-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
                title="Export current offline Watch Zones, Citizen SOS, and Sync Queue to portable JSON"
              >
                <FileJson className="h-3 w-3 text-amber-400" />
                <span>Export Package</span>
              </button>

              {syncQueue.length > 0 && (
                <button
                  onClick={onTriggerSync}
                  disabled={isOffline || isSyncing}
                  className={`px-3 py-1 rounded-md text-xs font-bold flex items-center space-x-1.5 transition-all ${
                    isOffline
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg'
                  }`}
                >
                  <RefreshCw className={`h-3 w-3 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'Syncing...' : 'Reconcile & Synchronize'}</span>
                </button>
              )}
            </div>
          </div>

          {syncQueue.length === 0 ? (
            <div className="text-center py-4 text-slate-500 text-xs">
              No pending disconnected actions. Local SQLite DB is synchronized with Cloud.
            </div>
          ) : (
            <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
              {syncQueue.map(item => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-2 rounded-lg bg-slate-900/60 border border-slate-800 text-[11px]"
                >
                  <div className="flex items-center space-x-2">
                    <span className="px-1.5 py-0.2 rounded bg-slate-800 text-cyan-400 text-[9px] font-bold">
                      {item.type}
                    </span>
                    <span className="text-slate-200">{item.label}</span>
                  </div>

                  <div className="flex items-center space-x-3 text-slate-400 text-[10px]">
                    <span>{item.timestamp}</span>
                    <span className={`px-1.5 py-0.2 rounded font-bold uppercase ${
                      item.status === 'pending' ? 'bg-amber-950 text-amber-400' : 'bg-emerald-950 text-emerald-400'
                    }`}>
                      {item.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-between items-center pt-2 text-xs font-mono text-slate-400 border-t border-slate-800">
          <span>SatQuery Edge Runtime v1.2</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
