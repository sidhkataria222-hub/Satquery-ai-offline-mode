export type ModalityType = 'single-optical' | 'temporal' | 'cross-modal' | 'watch-zone';

export interface TraceStep {
  name: string;
  status: 'completed' | 'processing' | 'pending' | 'failed';
  duration?: string;
  details: string;
}

export interface TimelineDataPoint {
  date: string;
  valueKm2: number;
  rainfallMm: number;
  label: string;
}

export interface WatchZone {
  id: string;
  name: string;
  region: string;
  lat: number;
  lng: number;
  zoom: number;
  polygonCoords: [number, number][]; // [lat, lng][]
  areaKm2: number;
  satellites: string[];
  monitoringTypes: ('flooding' | 'vegetation_change' | 'urban_expansion' | 'fire_burn')[];
  thresholdPercent: number;
  status: 'normal' | 'alert' | 'monitoring' | 'offline_cached';
  baselineDate: string;
  lastProcessedDate: string;
  latestMetrics: {
    inundatedAreaKm2: number;
    baselineAreaKm2: number;
    deltaPercent: number;
    confidence: number;
    affectedStructures: number;
    severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    // Humane Life Safety Metrics
    estimatedAffectedCitizens: number;
    shelteredCount: number;
    rescueTeamsActive: number;
  };
  timeline: TimelineDataPoint[];
  description: string;
}

export interface AlertItem {
  id: string;
  zoneId: string;
  zoneName: string;
  title: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  message: string;
  changeKm2: number;
  changePercent: number;
  evidence: string[];
  timestamp: string;
  acknowledged: boolean;
  syncPending?: boolean;
  humanImpactSummary?: string;
}

export interface Scenario {
  id: string;
  title: string;
  query: string;
  modality: ModalityType;
  image1Name: string;
  image2Name?: string;
  image1Type: 'Optical' | 'SAR';
  image2Type?: 'Optical' | 'SAR';
  answer: string;
  confidence: number;
  agreement?: number;
  trace: TraceStep[];
  zoneId?: string;
  visuals: {
    baseImage1: string;
    baseImage2?: string;
    maskOverlay?: {
      color: string;
      elements: Array<{ type: 'rect' | 'circle' | 'polygon'; coords: string; label: string }>;
    };
    boundingBoxes?: Array<{ x: number; y: number; w: number; h: number; label: string; color: string }>;
  };
}

export interface VAEScene {
  id: string;
  name: string;
  cluster: 'Flooded Wetland' | 'Dense Urban' | 'Agricultural' | 'Forest/Hill' | 'Coastal';
  coords: [number, number]; // 2D projection [x, y] in [-10, 10]
  similarityScore: number;
  date: string;
  region: string;
  inundationLevel: string;
}

export interface SyncOperation {
  id: string;
  type: 'ALERT_ACK' | 'ZONE_CREATED' | 'ANNOTATION' | 'OFFLINE_INFERENCE' | 'SOS_CREATED';
  label: string;
  timestamp: string;
  status: 'pending' | 'syncing' | 'synced';
}

export interface OfflinePackageState {
  isDownloaded: boolean;
  isDownloading: boolean;
  progress: number;
  packageSizeMb: number;
  cachedZonesCount: number;
  cachedScenesCount: number;
  localModels: string[];
  lastSyncTime: string;
}

export interface POIMarker {
  id: string;
  lat: number;
  lng: number;
  type: 'shelter' | 'bridge' | 'danger' | 'station' | 'sos';
  title: string;
  status: 'Operational' | 'Submerged' | 'Critical' | 'Standby' | 'Urgent';
  details: string;
}

export interface SOSRequest {
  id: string;
  zoneId: string;
  citizenName: string;
  contactNumber: string;
  locationDescription: string;
  lat: number;
  lng: number;
  urgency: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  peopleCount: number;
  needs: string[]; // 'Medical', 'Food/Water', 'Infant Care', 'Boat Evacuation'
  timestamp: string;
  status: 'PENDING_RESCUE' | 'DISPATCHED' | 'RESCUED';
  offlineCreated: boolean;
}

export interface ShelterCamp {
  id: string;
  name: string;
  zoneId: string;
  capacity: number;
  occupied: number;
  medicalStaffCount: number;
  waterDaysLeft: number;
  foodDaysLeft: number;
  status: 'NORMAL' | 'NEAR_CAPACITY' | 'CRITICAL_SHORTAGE';
}
