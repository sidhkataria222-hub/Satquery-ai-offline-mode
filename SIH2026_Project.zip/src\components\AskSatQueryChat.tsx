import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Sparkles, 
  Cpu, 
  Bot, 
  User, 
  CheckCircle2, 
  ShieldAlert, 
  ExternalLink, 
  ChevronRight, 
  CornerDownLeft,
  Layers,
  Activity,
  Maximize2
} from 'lucide-react';
import { Scenario, WatchZone, TraceStep } from '../types';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  routedModel?: string;
  confidence?: number;
  evidence?: string[];
  trace?: TraceStep[];
  timestamp: string;
  zoneRef?: string;
}

interface AskSatQueryChatProps {
  currentScenario: Scenario;
  selectedZone: WatchZone;
  isOffline: boolean;
  onExecuteScenario: (query: string) => void;
  isAnalyzing: boolean;
}

export const AskSatQueryChat: React.FC<AskSatQueryChatProps> = ({
  currentScenario,
  selectedZone,
  isOffline,
  onExecuteScenario,
  isAnalyzing
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-1',
      sender: 'assistant',
      text: `Hello! I am SatQuery AI. I am monitoring your active Watch Zones including ${selectedZone.name}. Ask me about spatial changes, flood extent, sensor comparisons, or similar historical disaster analogs.`,
      timestamp: 'Just now'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [activeTraceMessage, setActiveTraceMessage] = useState<Message | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickPrompts = selectedZone.id === 'zone-nepal' ? [
    'What is the flood status in Nepal Koshi & Kathmandu with zero internet?',
    'How many citizens are stranded or need rescue in Balkhu?',
    'Can Sentinel-1 SAR penetrate Nepal Himalayan clouds?',
    'List operational offline shelters and bridge status'
  ] : [
    `What changed in ${selectedZone.name.split(' ')[0]}?`,
    'Compare Optical and SAR imagery for water detection',
    'Why was a CRITICAL flood alert triggered?',
    'Find similar historical disaster scenes in latent space'
  ];

  const handleSendMessage = (textToSend?: string) => {
    const query = textToSend || inputText;
    if (!query.trim()) return;

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');

    // Trigger analysis
    onExecuteScenario(query);

    // Simulate Query Router & AI Response
    setTimeout(() => {
      let routedModel = 'GeoChat-7B Remote-Sensing VLM';
      let confidence = 94.2;
      let evidence = [
        'Visible spectral reflectance matches inundated agricultural land',
        'Spatial grounding matches bounding box coordinates within 0.08px RMSE'
      ];
      let responseText = currentScenario.answer;
      let traceSteps: TraceStep[] = currentScenario.trace;

      const qLower = query.toLowerCase();

      // INTENT 1: NEPAL / KOSHI / BAGMATI / KATHMANDU
      if (qLower.includes('nepal') || qLower.includes('koshi') || qLower.includes('bagmati') || qLower.includes('kathmandu') || qLower.includes('balkhu')) {
        routedModel = isOffline ? 'Quantized Siamese Edge VLM (INT8 ONNX)' : 'Multimodal Remote-Sensing Transformer';
        confidence = 93.8;
        evidence = [
          'Sentinel-1 C-band SAR backscatter dropped by -13.2 dB along 8.6km river corridor',
          'Local offline boundary intersection confirms 4.85 km² total inundation (+333.0% surge)',
          'Balkhu Ring Road underpass confirmed submerged under 2.2m flood water',
          '26 citizens in Balkhu cluster flagged for emergency boat extraction'
        ];
        responseText = isOffline
          ? `[OFFLINE EDGE INFERENCE - NEPAL FLOOD BLACKOUT]\nExecuted locally on device without internet connection.\n\n1. Inundation Extent: 4.85 km² currently inundated along the Bagmati & Koshi corridors (+333.0% surge over 1.12 km² baseline).\n2. Human Safety Impact: ~1,420 citizens impacted; 890 sheltered in Balkhu Disaster Relief Camp; 26 citizens trapped on rooftops near Balkhu Market.\n3. Infrastructure Chokepoints: Balkhu Ring Road Underpass is completely submerged and impassable. Chobhar gorge debris flow active.\n4. Telecommunications: Optical fiber and cellular towers are down; all field decisions operating on local edge storage.\n\nData Source: Cached Sentinel-1 SAR (03 Sep 2026) | Inference: On-Device Edge Engine | Zero Internet.`
          : `NEPAL KOSHI & KATHMANDU FLOOD BASIN ANALYSIS:\nMonsoon cloudburst has produced widespread inundation across the valley:\n\n1. Inundated Area: 4.85 km² (+333.0% over baseline).\n2. Affected Population: ~1,420 citizens; 890 accommodated in primary relief camps.\n3. Critical Infrastructure: Severed bridge links in Balkhu and active sediment choke at Chobhar.\n4. Satellite Sensors: Sentinel-1 SAR radar penetrated 100% cloud cover to map water extent.`;
        
        traceSteps = [
          { name: 'Zero-Internet Bus Check', status: 'completed', duration: '8ms', details: 'Confirmed network blackout. Switched execution to local quantized weights.' },
          { name: 'Local Vector ROI Clipping', status: 'completed', duration: '22ms', details: 'Extracted Nepal Koshi & Kathmandu Basin polygon from local SQLite/IndexedDB.' },
          { name: 'Cached SAR GeoTIFF Processing', status: 'completed', duration: '140ms', details: 'Segmented water pixels using 8-bit quantized UNet. Extracted specular reflection contours.' },
          { name: 'Human Impact Geospatial Join', status: 'completed', duration: '30ms', details: 'Cross-referenced water contours with local offline POI & SOS beacons database.' }
        ];
      } 
      // INTENT 2: SHELTERS, RESCUE, EVACUATION, STRANDED CITIZENS
      else if (qLower.includes('shelter') || qLower.includes('camp') || qLower.includes('stranded') || qLower.includes('rescue') || qLower.includes('evacuat') || qLower.includes('sos')) {
        routedModel = isOffline ? 'Local Humanitarian Relief Engine (Edge)' : 'Humane Impact Synthesizer';
        confidence = 95.0;
        evidence = [
          selectedZone.id === 'zone-nepal'
            ? 'Balkhu Relief Camp: 620/800 occupied (2.0 days water remaining)'
            : `${selectedZone.name} Relief Camps: 82% average capacity utilized`,
          'Local offline SOS queue tracking active citizen rescue beacons with high-precision GPS',
          'Automated route planning deployed for inflatable motorized rescue boats'
        ];
        responseText = selectedZone.id === 'zone-nepal'
          ? `HUMANITARIAN RELIEF & RESCUE STATUS (NEPAL BASIN):\n\n1. Active Shelters: Balkhu Disaster Emergency Camp (620 citizens sheltered, near capacity) and Koshi Barrage High Ground School (270 sheltered).\n2. Stranded Citizens: 26 people in Balkhu riverside cluster need immediate boat rescue; 11 residents isolated by debris flow near Chobhar.\n3. Offline Logging: All SOS rescue logs and water ration tracking are stored directly on device local disk, queued for sync once internet returns.`
          : `HUMANITARIAN RELIEF STATUS (${selectedZone.name.toUpperCase()}):\n\n1. Shelter Status: Primary relief stations are operating with active food, clean drinking water, and emergency triage kits.\n2. Rescue Assets: Rapid response boats and amphibious transport staged at safe perimeter zones.\n3. Offline SOS Dispatch: Local beacons are cataloged in the on-device incident queue for field commanders.`;
        traceSteps = [
          { name: 'Local Beacon Indexing', status: 'completed', duration: '12ms', details: 'Retrieved active SOS coordinates from browser localStorage cache.' },
          { name: 'Capacity Aggregation', status: 'completed', duration: '18ms', details: 'Calculated remaining bunk capacity across registered camp coordinates.' },
          { name: 'Safe Path Delineation', status: 'completed', duration: '45ms', details: 'Computed high-ground navigation corridors avoiding inundated road nodes.' }
        ];
      }
      // INTENT 3: SAR / RADAR / OPTICAL / CLOUD PENETRATION
      else if (qLower.includes('sar') || qLower.includes('radar') || qLower.includes('cloud') || qLower.includes('optical') || qLower.includes('penetrat') || qLower.includes('sensor')) {
        routedModel = isOffline ? 'Cross-Modal Radar Core (Edge Tensor)' : 'Cross-Attention Sensor Fusion (Optical + SAR)';
        confidence = 96.1;
        evidence = [
          'Sentinel-1 C-band SAR (5.405 GHz) penetrated 100% heavy monsoon cloud decks',
          'Specular reflection signature confirms water backscatter drop to -18.4 dB',
          'Multi-temporal SAR coherence filtering stripped vegetation false positives'
        ];
        responseText = `RADAR (SAR) vs OPTICAL SATELLITE CAPABILITY:\n\n1. All-Weather Day/Night Penetration: Optical sensors (Sentinel-2, Landsat) cannot see through dense rain or night clouds. Synthetic Aperture Radar (SAR on Sentinel-1) emits microwave pulses that easily penetrate cloud cover, haze, and rain.\n2. Specular Water Reflection: Calm water acts as a mirror, reflecting radar pulses away from the receiver. This makes flooded areas appear distinctively pitch-black in SAR rasters.\n3. Edge Fusion: In offline mode, the system uses cached SAR GeoTIFF amplitude maps to compute real-time inundation boundaries without needing fresh satellite downlinks.`;
        traceSteps = [
          { name: 'Spectral Band Extraction', status: 'completed', duration: '35ms', details: 'Extracted VV/VH polarization channels from cached Sentinel-1 scene.' },
          { name: 'Backscatter Thresholding', status: 'completed', duration: '50ms', details: 'Applied Otsu bimodal segmentation to isolate specular water surfaces.' },
          { name: 'Cloud Mask Verification', status: 'completed', duration: '20ms', details: 'Confirmed optical sensor blindness index > 85% over target coordinates.' }
        ];
      }
      // INTENT 4: DAMAGE, INFRASTRUCTURE, ROADS, BRIDGES
      else if (qLower.includes('damage') || qLower.includes('road') || qLower.includes('bridge') || qLower.includes('infrastructure') || qLower.includes('building') || qLower.includes('house')) {
        routedModel = isOffline ? 'Local Infrastructure Damage Vector Model' : 'Multitask Semantic Damage Segmenter';
        confidence = 92.7;
        evidence = [
          'Overlaid flood inundation mask with OpenStreetMap vector road network',
          '3 major arterial bridge approaches cut off by scouring and backwater',
          '142 residential and commercial structures flagged in high-hazard inundation zone'
        ];
        responseText = `INFRASTRUCTURE DAMAGE & ACCESSIBILITY ASSESSMENT (${selectedZone.name}):\n\n1. Transport Corridors: Arterial bridges and low-elevation ring road underpasses are submerged and impassable to conventional motor vehicles.\n2. Structural Hazard: 142 structures detected inside the dynamic water perimeter with structural foundation risks.\n3. Critical Lifelines: Power substations in low-lying sectors isolated; backup diesel generators activated at regional emergency centers.\n4. Field Route Advice: All ground relief vehicles must route via designated high-elevation bypass ridges.`;
        traceSteps = [
          { name: 'OSM Vector Geometry Load', status: 'completed', duration: '15ms', details: 'Parsed offline vector road network from local GeoJSON storage.' },
          { name: 'Spatial Polygon Intersection', status: 'completed', duration: '60ms', details: 'Identified all road segments intersecting the >0.5m flood depth contour.' },
          { name: 'Chokepoint Classification', status: 'completed', duration: '25ms', details: 'Ranked damaged segments by traffic throughput and evacuation criticality.' }
        ];
      }
      // INTENT 5: HISTORICAL DISASTERS & ANALOG MATCHING
      else if (qLower.includes('similar') || qLower.includes('historical') || qLower.includes('latent') || qLower.includes('analog') || qLower.includes('past') || qLower.includes('compare')) {
        routedModel = isOffline ? 'FAISS Offline KD-Tree (Cached Vectors)' : 'FAISS Cosine Similarity + VAE Latent Cluster';
        confidence = 94.8;
        evidence = [
          'Identified nearest historical scene: Nepal Koshi & Terai Flash Deluge (Aug 2024) with 95.4% cosine similarity',
          'Nearest Indian analog: Kerala Kuttanad Inundation (Aug 2025) at 94.8% match',
          'Latent spatial embedding matches bitemporal surge dynamics across 128 dimensions'
        ];
        responseText = `HISTORICAL DISASTER ANALOG RETRIEVAL:\n\n1. Nepal Koshi Deluge (Aug 2024): 95.4% cosine similarity. Inundation pattern matches current flash flood surges.\n2. Kerala Kuttanad Inundation (Aug 2025): 94.8% similarity.\n3. Bihar Kosi River Breach (Sep 2023): 86.5% similarity.\n\nTactical Benefit: Historical event retrieval allows relief teams to predict which downstream embankments and culverts will experience secondary collapse next based on past drainage bottlenecks.`;
        traceSteps = [
          { name: 'Latent Vector Lookup', status: 'completed', duration: '14ms', details: 'Retrieved 128-d VAE feature embeddings from local index.' },
          { name: 'Exact Nearest Neighbor Search', status: 'completed', duration: '28ms', details: 'Executed L2 Euclidean & Cosine distance metrics over 14 cached disaster scenes.' },
          { name: 'Analog Rank Output', status: 'completed', duration: '10ms', details: 'Sorted matching scenes by hazard severity and spatial overlap index.' }
        ];
      }
      // INTENT 6: OFFLINE MODE / HOW IT WORKS / CAPABILITY
      else if (qLower.includes('offline') || qLower.includes('internet') || qLower.includes('connection') || qLower.includes('blackout') || qLower.includes('how it work') || qLower.includes('capabilities')) {
        routedModel = 'SatQuery Edge Architecture (Local Disk)';
        confidence = 99.0;
        evidence = [
          'Full PWA Service Worker caching active for application shell and imagery rasters',
          'IndexedDB & LocalStorage managing watch zones, SOS logs, and sync buffers',
          'Local INT8 quantized inference engine executing queries with zero network latency'
        ];
        responseText = `OFFLINE EMERGENCY RESILIENCE CAPABILITIES:\n\n1. Zero-Internet Operation: Designed for severe disaster zones where cellular towers and fiber optics are destroyed.\n2. Cached Satellite Data: High-resolution Sentinel-1 SAR and Sentinel-2 optical GeoTIFFs are cached on your device storage.\n3. Edge AI Reasoning: Natural language queries, flood area computations, and shelter statuses run locally on your device hardware without sending data to external cloud APIs.\n4. Offline Sync Bus: All annotations, acknowledged alerts, and SOS beacons are placed in a local sync queue and automatically batch-uploaded when internet connectivity is re-established.`;
        traceSteps = [
          { name: 'Local Cache Probe', status: 'completed', duration: '6ms', details: 'Verified Service Worker satquery-offline-v2 cache hit.' },
          { name: 'Storage Health Verification', status: 'completed', duration: '12ms', details: 'Local disk sync queue verified with active write-ahead buffer.' }
        ];
      }
      // INTENT 7: GENERAL / CONTEXTUAL LOCAL INTELLIGENCE
      else {
        routedModel = isOffline ? 'SatQuery Edge Intelligence Engine (INT8)' : 'GeoChat-7B Remote-Sensing VLM';
        confidence = 91.2;
        evidence = [
          `Active Zone: ${selectedZone.name} (Coordinates: ${selectedZone.coordinates[0].toFixed(2)}°N, ${selectedZone.coordinates[1].toFixed(2)}°E)`,
          `Current Inundation Extent: ${selectedZone.floodedAreaSqKm} km² (${selectedZone.changePercentage > 0 ? '+' : ''}${selectedZone.changePercentage}% change vs baseline)`,
          `Risk Level: ${selectedZone.riskLevel.toUpperCase()} | Sensor: ${selectedZone.sensor}`
        ];
        responseText = isOffline
          ? `[LOCAL EDGE INFERENCE - ACTIVE WATCH ZONE: ${selectedZone.name.toUpperCase()}]\n\n` +
            `• Flood Extent: ${selectedZone.floodedAreaSqKm} km² inundated (Surge: ${selectedZone.changePercentage > 0 ? '+' : ''}${selectedZone.changePercentage}% over ${selectedZone.baselineAreaSqKm} km² normal baseline).\n` +
            `• Primary Sensor: ${selectedZone.sensor} (Spatial resolution: 10m Ground Sample Distance).\n` +
            `• Risk Assessment: ${selectedZone.riskLevel.toUpperCase()} hazard status.\n` +
            `• Local Grounding: Data retrieved from local edge package. You can query specific details about shelters, stranded citizens, radar penetration, road damage, or historical analogs.`
          : currentScenario.answer || `Analysis for ${selectedZone.name}:\nCurrent flooded surface is ${selectedZone.floodedAreaSqKm} km² with ${selectedZone.riskLevel} risk level. All radar and optical layers are aligned.`;
        
        traceSteps = [
          { name: 'Local Intent Routing', status: 'completed', duration: '11ms', details: `Dispatched query to local edge engine for zone: ${selectedZone.name}.` },
          { name: 'Local Geometry & Telemetry Parse', status: 'completed', duration: '24ms', details: 'Extracted zone metrics, sensor band ratios, and hazard thresholds.' },
          { name: 'Synthesized Grounded Response', status: 'completed', duration: '35ms', details: 'Formatted evidence-backed response with zero network dependencies.' }
        ];
      }

      const assistantMsg: Message = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: responseText,
        routedModel: isOffline ? `${routedModel} (Local Edge ONNX)` : routedModel,
        confidence,
        evidence,
        trace: traceSteps,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, assistantMsg]);
    }, 1100);
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isAnalyzing]);

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 rounded-xl border border-slate-800 shadow-xl overflow-hidden">
      {/* Top Bar */}
      <div className="px-4 py-3 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Bot className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              GeoChat Conversational Router
              <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-500/30">
                {isOffline ? 'Edge ONNX' : 'Multimodal VLM'}
              </span>
            </h3>
            <p className="text-[10px] text-slate-400">
              Natural-Language Interface to Satellites, Watch Zones & Evidence
            </p>
          </div>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {messages.map(msg => {
          const isUser = msg.sender === 'user';

          return (
            <div
              key={msg.id}
              className={`flex gap-3 text-xs leading-relaxed ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="h-7 w-7 rounded-lg bg-emerald-950 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 shadow-md">
                  <Sparkles className="h-4 w-4" />
                </div>
              )}

              <div className={`max-w-[85%] rounded-2xl p-3.5 space-y-2.5 shadow-lg ${
                isUser
                  ? 'bg-emerald-600 text-white rounded-tr-none'
                  : 'bg-slate-900/90 border border-slate-800 text-slate-200 rounded-tl-none'
              }`}>
                {/* Router Badge if Assistant */}
                {!isUser && msg.routedModel && (
                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 text-[10px] font-mono">
                    <span className="text-cyan-400 flex items-center gap-1 font-semibold">
                      <Cpu className="h-3 w-3 text-cyan-400" />
                      Routed Model: {msg.routedModel}
                    </span>
                    {msg.confidence && (
                      <span className="text-emerald-400 font-bold bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800">
                        {msg.confidence}% Conf
                      </span>
                    )}
                  </div>
                )}

                {/* Main Text Content */}
                <div className="whitespace-pre-line font-sans text-xs leading-relaxed">
                  {msg.text}
                </div>

                {/* Offline Source & Provenance Disclosure */}
                {!isUser && isOffline && (
                  <div className="bg-amber-950/30 border border-amber-500/30 rounded-lg p-2 text-[10px] font-mono text-amber-200 space-y-1">
                    <div className="flex items-center justify-between font-bold text-amber-300">
                      <span>● ZERO-INTERNET RESILIENCE</span>
                      <span>100% LOCAL INFERENCE</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400 text-[9px]">
                      <span>Source: Cached Sentinel GeoTIFF</span>
                      <span>Edge Engine: Quantized INT8</span>
                    </div>
                  </div>
                )}

                {/* Evidence Checklist if Assistant */}
                {!isUser && msg.evidence && (
                  <div className="bg-slate-950/80 border border-slate-850 rounded-lg p-2.5 space-y-1.5 text-[11px] font-mono">
                    <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider block border-b border-slate-850 pb-1">
                      Calibrated Evidence
                    </span>
                    {msg.evidence.map((item, idx) => (
                      <div key={idx} className="flex items-start space-x-2 text-slate-300">
                        <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* View Trace Action */}
                {!isUser && msg.trace && (
                  <button
                    onClick={() => setActiveTraceMessage(msg)}
                    className="flex items-center space-x-1 text-[10px] font-mono text-cyan-400 hover:text-cyan-300 transition-colors"
                  >
                    <span>View Grounded Agent Trace</span>
                    <ChevronRight className="h-3 w-3" />
                  </button>
                )}

                <div className="text-[9px] text-slate-400 text-right">
                  {msg.timestamp}
                </div>
              </div>

              {isUser && (
                <div className="h-7 w-7 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 flex items-center justify-center shrink-0 mt-0.5">
                  <User className="h-4 w-4" />
                </div>
              )}
            </div>
          );
        })}

        {isAnalyzing && (
          <div className="flex gap-3 text-xs leading-relaxed">
            <div className="h-7 w-7 rounded-lg bg-emerald-950 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0 animate-pulse">
              <Activity className="h-4 w-4 animate-spin" />
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 text-slate-400 flex items-center space-x-2">
              <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping"></span>
              <span className="font-mono text-xs">Routing through remote-sensing multi-agent graph...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompts */}
      <div className="px-4 py-2 bg-slate-900/40 border-t border-slate-800/60 flex items-center gap-1.5 overflow-x-auto text-[11px] font-mono">
        <span className="text-slate-500 shrink-0 text-[10px] uppercase font-bold">Suggested:</span>
        {quickPrompts.map((qp, i) => (
          <button
            key={i}
            onClick={() => handleSendMessage(qp)}
            className="px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white shrink-0 transition-colors"
          >
            {qp}
          </button>
        ))}
      </div>

      {/* Chat Input Bar */}
      <div className="p-3 bg-slate-900/90 border-t border-slate-800">
        <form
          onSubmit={e => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center space-x-2"
        >
          <input
            type="text"
            placeholder="Ask SatQuery anything (e.g., 'What changed in Kerala?', 'Is water flooded?')..."
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 shadow-inner"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-500 text-white transition-colors shadow-lg shadow-emerald-950/40"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>

      {/* TRACE MODAL IF ACTIVE */}
      {activeTraceMessage && activeTraceMessage.trace && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center space-x-2">
                <Activity className="h-4 w-4 text-cyan-400" />
                <h4 className="text-sm font-bold text-white font-mono">Agent Execution Pipeline</h4>
              </div>
              <button
                onClick={() => setActiveTraceMessage(null)}
                className="text-slate-400 hover:text-white text-xs font-mono"
              >
                Close ✕
              </button>
            </div>

            <div className="space-y-3 relative border-l-2 border-slate-800 ml-3 pl-4 py-1 text-xs">
              {activeTraceMessage.trace.map((step, idx) => (
                <div key={idx} className="relative">
                  <span className="absolute -left-[23px] top-0.5 flex h-4 w-4 items-center justify-center rounded-full border border-emerald-500 bg-emerald-950 text-emerald-400 text-[9px] font-bold">
                    ✓
                  </span>
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white">{step.name}</span>
                    <span className="text-[10px] font-mono text-slate-500">{step.duration}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug mt-0.5">{step.details}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
