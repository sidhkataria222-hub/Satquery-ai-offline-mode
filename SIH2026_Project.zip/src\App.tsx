import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  TacticalNavbar 
} from './components/TacticalNavbar';
import { 
  TacticalFooter 
} from './components/TacticalFooter';
import { 
  WorldGlobeAnimation 
} from './components/WorldGlobeAnimation';
import { 
  InteractiveMap 
} from './components/InteractiveMap';
import { 
  SwipeCompareViewer 
} from './components/SwipeCompareViewer';
import { 
  AnalyticsCharts 
} from './components/AnalyticsCharts';
import { 
  WatchZoneManager 
} from './components/WatchZoneManager';
import { 
  AskSatQueryChat 
} from './components/AskSatQueryChat';
import { 
  OfflineEmergencyModal 
} from './components/OfflineEmergencyModal';
import { 
  SitrepReportModal 
} from './components/SitrepReportModal';
import { 
  AlertsDrawer 
} from './components/AlertsDrawer';
import { 
  HumaneReliefBase 
} from './components/HumaneReliefBase';
import { 
  MainOfflineFeatureHub 
} from './components/MainOfflineFeatureHub';

import { 
  WATCH_ZONES, 
  ALERTS, 
  POI_MARKERS, 
  VAE_SCENES, 
  SCENARIOS,
  SHELTER_CAMPS,
  INITIAL_SOS_REQUESTS
} from './data/mockData';
import { 
  SATELLITE_PASSES 
} from './data/satelliteImagery';
import { 
  WatchZone, 
  AlertItem, 
  Scenario, 
  VAEScene, 
  SyncOperation, 
  OfflinePackageState, 
  TraceStep,
  SOSRequest,
  ShelterCamp
} from './types';

import { 
  Layers, 
  Sliders, 
  MapPin, 
  Compass, 
  Bot, 
  Activity, 
  BarChart3, 
  ShieldAlert, 
  WifiOff, 
  HardDriveDownload, 
  RotateCcw, 
  Sparkles,
  Search,
  ExternalLink,
  ChevronRight,
  HeartHandshake,
  LifeBuoy,
  Wifi,
  Globe,
  Radio,
  Satellite
} from 'lucide-react';

export default function App() {
  // Navigation Workflows: 6 Tactile Modes
  // 'globe' | 'map' | 'relief' | 'compare' | 'watch' | 'chat'
  const [currentWorkflow, setCurrentWorkflow] = useState<'globe' | 'map' | 'relief' | 'compare' | 'watch' | 'chat'>('map');

  // Load from localStorage for true offline persistence across page refreshes
  const [watchZones, setWatchZones] = useState<WatchZone[]>(() => {
    const saved = localStorage.getItem('satquery_watch_zones');
    if (!saved) return WATCH_ZONES;
    try {
      const parsed: WatchZone[] = JSON.parse(saved);
      if (!parsed.some(z => z.id === 'zone-nepal')) {
        const nepalZone = WATCH_ZONES.find(z => z.id === 'zone-nepal');
        return nepalZone ? [nepalZone, ...parsed] : parsed;
      }
      return parsed;
    } catch {
      return WATCH_ZONES;
    }
  });

  const [selectedZone, setSelectedZone] = useState<WatchZone>(() => watchZones[0] || WATCH_ZONES[0]);

  const [alerts, setAlerts] = useState<AlertItem[]>(() => {
    const saved = localStorage.getItem('satquery_alerts');
    if (!saved) return ALERTS;
    try {
      const parsed: AlertItem[] = JSON.parse(saved);
      if (!parsed.some(a => a.id === 'alt-nepal')) {
        const nepalAlert = ALERTS.find(a => a.id === 'alt-nepal');
        return nepalAlert ? [nepalAlert, ...parsed] : parsed;
      }
      return parsed;
    } catch {
      return ALERTS;
    }
  });

  const [sosRequests, setSosRequests] = useState<SOSRequest[]>(() => {
    const saved = localStorage.getItem('satquery_sos_requests');
    if (!saved) return INITIAL_SOS_REQUESTS;
    try {
      const parsed: SOSRequest[] = JSON.parse(saved);
      if (!parsed.some(s => s.id.includes('nepal'))) {
        const nepalSos = INITIAL_SOS_REQUESTS.filter(s => s.id.includes('nepal'));
        return [...nepalSos, ...parsed];
      }
      return parsed;
    } catch {
      return INITIAL_SOS_REQUESTS;
    }
  });

  const [shelters, setShelters] = useState<ShelterCamp[]>(SHELTER_CAMPS);
  const [currentScenario, setCurrentScenario] = useState<Scenario>(SCENARIOS[0]);

  // Network State - Auto detect online/offline from browser
  const [isOffline, setIsOffline] = useState<boolean>(!navigator.onLine);

  const [isAlertsOpen, setIsAlertsOpen] = useState<boolean>(false);
  const [isOfflineModalOpen, setIsOfflineModalOpen] = useState<boolean>(false);
  const [isSitrepOpen, setIsSitrepOpen] = useState<boolean>(false);
  const [isCreateZoneModalOpen, setIsCreateZoneModalOpen] = useState<boolean>(false);

  // Map Drawing Mode
  const [isDrawingMode, setIsDrawingMode] = useState<boolean>(false);
  const [drawnCoords, setDrawnCoords] = useState<[number, number][]>([]);

  // Image Swipe Controls
  const [showMask, setShowMask] = useState<boolean>(true);
  const [maskOpacity, setMaskOpacity] = useState<number>(65);
  const [showBboxes, setShowBboxes] = useState<boolean>(true);

  // Analysis Simulation
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [consoleLogs, setConsoleLogs] = useState<string[]>([
    `[${new Date().toLocaleTimeString()}] [BASE INITIALIZE] Station ID: SATQUERY-DELTA-9 Armed.`,
    `[${new Date().toLocaleTimeString()}] [ORBIT ENGINE] 3D Vector Orthographic World Sphere running 60fps.`,
    `[${new Date().toLocaleTimeString()}] [LOCAL STORAGE] All Watch Zones, SOS Beacons & local caches bound to local disk.`
  ]);

  // Offline Mission Package State
  const [offlinePackage, setOfflinePackage] = useState<OfflinePackageState>(() => {
    const saved = localStorage.getItem('satquery_offline_package');
    return saved ? JSON.parse(saved) : {
      isDownloaded: true,
      isDownloading: false,
      progress: 100,
      packageSizeMb: 2840,
      cachedZonesCount: 5,
      cachedScenesCount: 14,
      localModels: ['geochat_int8.onnx', 'flood_seg_fp16.onnx', 'sar_fusion_fp16.onnx'],
      lastSyncTime: '03 Sep 2026, 06:14 UTC'
    };
  });

  // Offline Sync Queue
  const [syncQueue, setSyncQueue] = useState<SyncOperation[]>(() => {
    const saved = localStorage.getItem('satquery_sync_queue');
    return saved ? JSON.parse(saved) : [
      {
        id: 'sync-1',
        type: 'ALERT_ACK',
        label: 'Acknowledged high-hazard flood alert in Kerala Basin',
        timestamp: '10:14 AM',
        status: 'pending'
      },
      {
        id: 'sync-2',
        type: 'ANNOTATION',
        label: 'Marked submerged causeway on Champakulam bridge',
        timestamp: '10:22 AM',
        status: 'pending'
      }
    ];
  });
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Synchronize state with localStorage
  useEffect(() => {
    localStorage.setItem('satquery_watch_zones', JSON.stringify(watchZones));
  }, [watchZones]);

  useEffect(() => {
    localStorage.setItem('satquery_sos_requests', JSON.stringify(sosRequests));
  }, [sosRequests]);

  useEffect(() => {
    localStorage.setItem('satquery_alerts', JSON.stringify(alerts));
  }, [alerts]);

  useEffect(() => {
    localStorage.setItem('satquery_sync_queue', JSON.stringify(syncQueue));
  }, [syncQueue]);

  useEffect(() => {
    localStorage.setItem('satquery_offline_package', JSON.stringify(offlinePackage));
  }, [offlinePackage]);

  // Automatic browser network listener
  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      setConsoleLogs(logs => [
        `[${new Date().toLocaleTimeString()}] [NETWORK RESTORED] Connected to cloud. Ready to reconcile pending operations.`,
        ...logs
      ]);
    };

    const handleOffline = () => {
      setIsOffline(true);
      setConsoleLogs(logs => [
        `[${new Date().toLocaleTimeString()}] [NETWORK LOST] Automatically transitioned to 100% Offline Edge Mode. All local tools active.`,
        ...logs
      ]);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // PWA Install Prompt Handler
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setConsoleLogs(logs => [
        `[${new Date().toLocaleTimeString()}] [PWA READY] Web Application Manifest primed for standalone offline installation.`,
        ...logs
      ]);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallPWA = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setDeferredPrompt(null);
        confetti({ particleCount: 60, spread: 70 });
      }
    } else {
      alert('SatQuery AI is ready for offline installation. Click the Install (⊕) button in your browser address bar or menu to install as a standalone desktop/mobile app.');
    }
  };

  // Register window hook for leaflet polygon drawing
  useEffect(() => {
    (window as any).__onAddVertex = (coord: [number, number]) => {
      setDrawnCoords(prev => [...prev, coord]);
    };
    return () => {
      delete (window as any).__onAddVertex;
    };
  }, []);

  // Handle Offline Toggle
  const handleToggleOffline = () => {
    setIsOffline(prev => {
      const next = !prev;
      setConsoleLogs(logs => [
        `[${new Date().toLocaleTimeString()}] [HARDWARE TOGGLE] Manual override: ${next ? 'OFFLINE LOCAL FIELD EDGE' : 'CLOUD SATELLITE RELAY'}`,
        ...logs
      ]);
      return next;
    });
  };

  // Download Simulated Mission Package
  const handleDownloadPackage = () => {
    setOfflinePackage(prev => ({ ...prev, isDownloading: true, progress: 0 }));
    let prog = 0;
    const interval = setInterval(() => {
      prog += 25;
      if (prog >= 100) {
        clearInterval(interval);
        setOfflinePackage(prev => ({
          ...prev,
          isDownloading: false,
          isDownloaded: true,
          progress: 100,
          lastSyncTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }));
        confetti({ particleCount: 50, spread: 60 });
        setConsoleLogs(logs => [
          `[${new Date().toLocaleTimeString()}] [CACHE] Emergency Mission Package verified & persisted to local browser storage.`,
          ...logs
        ]);
      } else {
        setOfflinePackage(prev => ({ ...prev, progress: prog }));
      }
    }, 350);
  };

  // Trigger Sync Queue Reconciliation
  const handleTriggerSync = () => {
    if (isOffline || syncQueue.length === 0) return;
    setIsSyncing(true);
    setConsoleLogs(logs => [
      `[${new Date().toLocaleTimeString()}] [SYNC RELAY] Reconciling ${syncQueue.length} field operations with central station...`,
      ...logs
    ]);

    setTimeout(() => {
      setSyncQueue([]);
      setIsSyncing(false);
      confetti({ particleCount: 70, spread: 80 });
      setConsoleLogs(logs => [
        `[${new Date().toLocaleTimeString()}] [SYNC SUCCESS] All offline logs, SOS beacons and annotations synchronized successfully.`,
        ...logs
      ]);
    }, 1500);
  };

  // Acknowledge an Alert
  const handleAcknowledgeAlert = (alertId: string) => {
    setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, acknowledged: true } : a));
    const alert = alerts.find(a => a.id === alertId);

    if (isOffline) {
      const newOp: SyncOperation = {
        id: `op-${Date.now()}`,
        type: 'ALERT_ACK',
        label: `Offline acknowledgment: ${alert?.title || alertId}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'pending'
      };
      setSyncQueue(prev => [newOp, ...prev]);
    }

    setConsoleLogs(logs => [
      `[${new Date().toLocaleTimeString()}] [ALERT ACK] Operator logged acknowledgment for alert ${alertId}.`,
      ...logs
    ]);
  };

  // Add a Citizen SOS Request (100% Offline Compatible)
  const handleAddSOS = (newSOS: SOSRequest) => {
    setSosRequests(prev => [newSOS, ...prev]);

    if (isOffline) {
      const newOp: SyncOperation = {
        id: `op-${Date.now()}`,
        type: 'SOS_CREATED',
        label: `Offline SOS logged: ${newSOS.citizenName} (${newSOS.peopleCount} people)`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'pending'
      };
      setSyncQueue(prev => [newOp, ...prev]);
    }

    setConsoleLogs(logs => [
      `[${new Date().toLocaleTimeString()}] [SOS DISPATCH BEACON] Placed beacon for "${newSOS.citizenName}" (${newSOS.peopleCount} people). Saved to local storage.`,
      ...logs
    ]);
  };

  // Dispatch SOS Rescue Boat
  const handleDispatchSOS = (sosId: string) => {
    setSosRequests(prev => prev.map(s => s.id === sosId ? { ...s, status: 'DISPATCHED' } : s));
    setConsoleLogs(logs => [
      `[${new Date().toLocaleTimeString()}] [DISPATCH] Rescue boat & relief team dispatched to SOS beacon ${sosId}.`,
      ...logs
    ]);
  };

  // Execute AI scenario from query or preset
  const handleExecuteScenario = (queryText: string) => {
    setIsAnalyzing(true);
    setConsoleLogs(logs => [
      `[${new Date().toLocaleTimeString()}] [QUERY ROUTER] Routing prompt: "${queryText}"`,
      ...logs
    ]);

    setTimeout(() => {
      setIsAnalyzing(false);
      setConsoleLogs(logs => [
        `[${new Date().toLocaleTimeString()}] [INFERENCE] Grounded response generated with calibrated evidence.`,
        ...logs
      ]);
    }, 1200);
  };

  // Handle Terminal Commands from Tactical Footer
  const handleTerminalCommand = (cmd: string) => {
    const lower = cmd.trim().toLowerCase();
    if (lower === 'globe' || lower === '1') setCurrentWorkflow('globe');
    else if (lower === 'map' || lower === '2') setCurrentWorkflow('map');
    else if (lower === 'relief' || lower === 'sos' || lower === '3') setCurrentWorkflow('relief');
    else if (lower === 'compare' || lower === 'swipe' || lower === '4') setCurrentWorkflow('compare');
    else if (lower === 'chat' || lower === 'geochat' || lower === '5') setCurrentWorkflow('chat');
    else if (lower === 'sitrep') setIsSitrepOpen(true);
    else if (lower === 'sync') handleTriggerSync();
    else if (lower === 'offline') handleToggleOffline();
    else if (lower.includes('nepal') || lower.includes('koshi')) {
      const n = watchZones.find(z => z.id === 'zone-nepal');
      if (n) handleSelectZone(n);
    } else if (lower.includes('kerala')) {
      const k = watchZones.find(z => z.id === 'zone-kerala');
      if (k) handleSelectZone(k);
    } else if (lower.includes('assam')) {
      const a = watchZones.find(z => z.id === 'zone-assam');
      if (a) handleSelectZone(a);
    } else if (lower.includes('mumbai')) {
      const m = watchZones.find(z => z.id === 'zone-mumbai');
      if (m) handleSelectZone(m);
    } else {
      handleExecuteScenario(cmd);
    }
  };

  // Drawing mode finish
  const handleFinishDrawingZone = (coords: [number, number][]) => {
    setIsDrawingMode(false);
    setIsCreateZoneModalOpen(true);
  };

  const handleCancelDrawingZone = () => {
    setIsDrawingMode(false);
    setDrawnCoords([]);
  };

  // Select Zone
  const handleSelectZone = (zone: WatchZone) => {
    setSelectedZone(zone);
    const match = SCENARIOS.find(s => s.zoneId === zone.id);
    if (match) {
      setCurrentScenario(match);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#03060c] text-slate-100 font-sans select-none overflow-x-hidden">
      {/* 1. Tactical Industrial Navbar */}
      <TacticalNavbar
        currentWorkflow={currentWorkflow}
        onSelectWorkflow={setCurrentWorkflow}
        isOffline={isOffline}
        onToggleOffline={handleToggleOffline}
        alerts={alerts}
        onOpenAlerts={() => setIsAlertsOpen(true)}
        onOpenOfflineModal={() => setIsOfflineModalOpen(true)}
        onOpenSitrep={() => setIsSitrepOpen(true)}
        activeZoneCount={watchZones.length}
        offlinePackage={offlinePackage}
        pendingSyncCount={syncQueue.length}
        onTriggerSync={handleTriggerSync}
        isSyncing={isSyncing}
        sosRequests={sosRequests}
      />

      {/* 2. Main Offline Feature Hub & Disaster Control Bar */}
      <MainOfflineFeatureHub
        isOffline={isOffline}
        onToggleOffline={handleToggleOffline}
        selectedZone={selectedZone}
        onSelectZone={zone => {
          handleSelectZone(zone);
          setCurrentWorkflow('map');
        }}
        watchZones={watchZones}
        offlinePackage={offlinePackage}
        onOpenOfflineModal={() => setIsOfflineModalOpen(true)}
        pendingSyncCount={syncQueue.length}
        onTriggerSync={handleTriggerSync}
        isSyncing={isSyncing}
        onInstallPWA={handleInstallPWA}
      />

      {/* 3. Emergency Offline Amber Strobe Banner (if offline) */}
      {isOffline && (
        <div className="bg-amber-950/40 border-b-2 border-amber-500/60 px-4 py-1.5 flex items-center justify-between text-xs font-mono text-amber-300">
          <div className="flex items-center space-x-2">
            <WifiOff className="h-4 w-4 text-amber-400 animate-pulse" />
            <span className="font-bold uppercase tracking-wider">OFFLINE EMERGENCY EDGE BUS ARMED:</span>
            <span className="text-slate-300 hidden md:inline">
              Running on local device disk. Georeferenced satellite rasters, offline GeoChat ONNX weights & Citizen SOS beacons are 100% active.
            </span>
          </div>

          <div className="flex items-center space-x-3">
            <span className="text-[11px] text-amber-400 font-semibold">
              {syncQueue.length} Operations Queued on Disk
            </span>
            <button
              onClick={handleToggleOffline}
              className="px-2 py-0.5 rounded bg-amber-500/30 border border-amber-500 hover:bg-amber-500/40 text-amber-200 text-[10px] font-bold"
            >
              Simulate Online Relay
            </button>
          </div>
        </div>
      )}

      {/* 3. Main Multi-Panel Operational Workspace */}
      <main className="flex-1 grid grid-cols-1 xl:grid-cols-12 gap-4 p-4 overflow-hidden">
        {/* Left / Center Viewport Column (xl:col-span-8) */}
        <section className="xl:col-span-8 flex flex-col space-y-4 min-h-[500px]">
          {/* Active Viewport based on selected Workflow */}
          <div className="flex-1 bg-black/40 rounded-2xl border-2 border-slate-800 overflow-hidden shadow-2xl relative">
            {/* 1. World Globe 3D Orbital Animation */}
            {currentWorkflow === 'globe' && (
              <WorldGlobeAnimation
                watchZones={watchZones}
                selectedZone={selectedZone}
                onSelectZone={zone => {
                  handleSelectZone(zone);
                  setCurrentWorkflow('map'); // Clicking zone on globe zooms to GIS map!
                }}
                isOffline={isOffline}
              />
            )}

            {/* 2. GIS Interactive Satellite Map */}
            {currentWorkflow === 'map' && (
              <InteractiveMap
                watchZones={watchZones}
                selectedZone={selectedZone}
                onSelectZone={handleSelectZone}
                poiMarkers={POI_MARKERS}
                sosRequests={sosRequests}
                isOffline={isOffline}
                onStartDrawingZone={() => {
                  setIsDrawingMode(true);
                  setDrawnCoords([]);
                }}
                isDrawingMode={isDrawingMode}
                onFinishDrawingZone={handleFinishDrawingZone}
                onCancelDrawingZone={handleCancelDrawingZone}
                drawnCoords={drawnCoords}
              />
            )}

            {/* 3. Humane Relief & Citizen SOS Base */}
            {currentWorkflow === 'relief' && (
              <HumaneReliefBase
                selectedZone={selectedZone}
                shelters={shelters}
                sosRequests={sosRequests}
                onAddSOS={handleAddSOS}
                onDispatchSOS={handleDispatchSOS}
                isOffline={isOffline}
                onFocusSOSOnMap={sos => {
                  setSelectedZone(watchZones.find(z => z.id === sos.zoneId) || selectedZone);
                  setCurrentWorkflow('map');
                }}
              />
            )}

            {/* 4. Bitemporal Swipe Compare Viewer */}
            {currentWorkflow === 'compare' && (
              <SwipeCompareViewer
                scenario={currentScenario}
                showMask={showMask}
                setShowMask={setShowMask}
                maskOpacity={maskOpacity}
                setMaskOpacity={setMaskOpacity}
                showBboxes={showBboxes}
                setShowBboxes={setShowBboxes}
              />
            )}

            {/* 5. Watch Zone Manager */}
            {currentWorkflow === 'watch' && (
              <WatchZoneManager
                watchZones={watchZones}
                selectedZone={selectedZone}
                onSelectZone={handleSelectZone}
                onCreateZone={newZone => {
                  setWatchZones(prev => [newZone, ...prev]);
                  setSelectedZone(newZone);
                  if (isOffline) {
                    setSyncQueue(prev => [{
                      id: `op-${Date.now()}`,
                      type: 'ZONE_CREATED',
                      label: `Created offline Watch Zone: ${newZone.name}`,
                      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                      status: 'pending'
                    }, ...prev]);
                  }
                }}
                isCreateModalOpen={isCreateZoneModalOpen}
                setIsCreateZoneModalOpen={setIsCreateZoneModalOpen}
                initialCoords={drawnCoords}
                onFocusMap={zone => {
                  handleSelectZone(zone);
                  setCurrentWorkflow('map');
                }}
                onAskAIAboutZone={zone => {
                  handleSelectZone(zone);
                  setCurrentWorkflow('chat');
                }}
              />
            )}

            {/* 6. GeoChat Conversational Assistant */}
            {currentWorkflow === 'chat' && (
              <AskSatQueryChat
                currentScenario={currentScenario}
                selectedZone={selectedZone}
                isOffline={isOffline}
                onExecuteScenario={handleExecuteScenario}
                isAnalyzing={isAnalyzing}
              />
            )}
          </div>

          {/* Bottom Secondary Panel: Earth Analytics Graphs */}
          <div className="h-[280px]">
            <AnalyticsCharts
              selectedZone={selectedZone}
              vaeScenes={VAE_SCENES}
              onSelectHistoricalScene={(scene) => {
                setConsoleLogs(logs => [
                  `[${new Date().toLocaleTimeString()}] [FAISS] Loaded historical analog: "${scene.name}" (${scene.similarityScore}% cosine match).`,
                  ...logs
                ]);
                setCurrentWorkflow('compare');
              }}
            />
          </div>
        </section>

        {/* Right Intelligence & Field Control Column (xl:col-span-4) */}
        <section className="xl:col-span-4 flex flex-col space-y-4 overflow-y-auto">
          {/* Quick Chat or Watch Zone widget */}
          {currentWorkflow !== 'chat' ? (
            <div className="h-[360px]">
              <AskSatQueryChat
                currentScenario={currentScenario}
                selectedZone={selectedZone}
                isOffline={isOffline}
                onExecuteScenario={handleExecuteScenario}
                isAnalyzing={isAnalyzing}
              />
            </div>
          ) : (
            <div className="h-[360px]">
              <HumaneReliefBase
                selectedZone={selectedZone}
                shelters={shelters}
                sosRequests={sosRequests}
                onAddSOS={handleAddSOS}
                onDispatchSOS={handleDispatchSOS}
                isOffline={isOffline}
                onFocusSOSOnMap={sos => {
                  setSelectedZone(watchZones.find(z => z.id === sos.zoneId) || selectedZone);
                  setCurrentWorkflow('map');
                }}
              />
            </div>
          )}

          {/* Humane Life-Safety & Telemetry Card */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs shadow-lg">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-rose-400 font-bold uppercase text-[10px] flex items-center gap-1.5">
                <HeartHandshake className="h-3.5 w-3.5 text-rose-400" />
                Humane Field Safety Telemetry
              </span>
              <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase ${
                selectedZone.status === 'alert' ? 'bg-red-950 text-red-400 border border-red-800' : 'bg-emerald-950 text-emerald-400'
              }`}>
                {selectedZone.latestMetrics.severity}
              </span>
            </div>

            <div className="space-y-1">
              <h4 className="font-bold text-white text-sm font-sans">{selectedZone.name}</h4>
              <p className="text-[11px] text-slate-400 font-sans">{selectedZone.region}</p>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-850">
                <span className="text-slate-500 text-[9px] block">SHELTERED CITIZENS</span>
                <span className="text-emerald-400 font-bold text-base">
                  {selectedZone.latestMetrics.shelteredCount} Persons
                </span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-850">
                <span className="text-slate-500 text-[9px] block">AT-RISK POPULATION</span>
                <span className="text-rose-400 font-bold text-base">
                  ~{selectedZone.latestMetrics.estimatedAffectedCitizens} Persons
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-[11px]">
              <span className="text-slate-400">Flood Inundation: {selectedZone.latestMetrics.inundatedAreaKm2} km²</span>
              <button
                onClick={() => setIsSitrepOpen(true)}
                className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1"
              >
                <span>Export SITREP</span>
                <ChevronRight className="h-3 w-3" />
              </button>
            </div>
          </div>

          {/* Zero-Internet Resilience Status Card */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs shadow-lg">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400 font-bold uppercase text-[10px] flex items-center gap-1.5">
                <Activity className="h-3.5 w-3.5 text-cyan-400" />
                Zero-Internet Resilience
              </span>
              <span className="text-[9px] text-emerald-400 font-bold">100% OPERATIONAL</span>
            </div>

            <div className="space-y-1.5 text-[11px] text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-500">Service Worker:</span>
                <span className="text-emerald-400 font-bold">Active & Caching</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Local Rasters:</span>
                <span className="text-white font-bold">Sentinel-1/2 (02 Sep 2026)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Local Database:</span>
                <span className="text-white font-bold">IndexedDB / SQLite Storage</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Queued Offline Ops:</span>
                <span className="text-amber-400 font-bold">{syncQueue.length} Pending</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* 4. Tactical Operator Mission Footer with Interactive Command Terminal */}
      <TacticalFooter
        onExecuteCommand={handleTerminalCommand}
        isOffline={isOffline}
        queuedOperationsCount={syncQueue.length}
        activeZoneName={selectedZone.name}
      />

      {/* MODALS & DRAWERS */}
      <AlertsDrawer
        isOpen={isAlertsOpen}
        onClose={() => setIsAlertsOpen(false)}
        alerts={alerts}
        onAcknowledgeAlert={handleAcknowledgeAlert}
        onSelectZone={zoneId => {
          const z = watchZones.find(w => w.id === zoneId);
          if (z) {
            handleSelectZone(z);
            setCurrentWorkflow('map');
            setIsAlertsOpen(false);
          }
        }}
        watchZones={watchZones}
      />

      <OfflineEmergencyModal
        isOpen={isOfflineModalOpen}
        onClose={() => setIsOfflineModalOpen(false)}
        isOffline={isOffline}
        onToggleOffline={handleToggleOffline}
        offlinePackage={offlinePackage}
        onDownloadPackage={handleDownloadPackage}
        syncQueue={syncQueue}
        onTriggerSync={handleTriggerSync}
        isSyncing={isSyncing}
        watchZones={watchZones}
      />

      <SitrepReportModal
        isOpen={isSitrepOpen}
        onClose={() => setIsSitrepOpen(false)}
        zone={selectedZone}
        alerts={alerts}
        poiMarkers={POI_MARKERS[selectedZone.id] || []}
        isOffline={isOffline}
      />
    </div>
  );
}
