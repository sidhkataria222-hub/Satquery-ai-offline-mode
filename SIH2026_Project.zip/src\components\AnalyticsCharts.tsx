import React, { useState } from 'react';
import { 
  WatchZone, 
  VAEScene, 
  TimelineDataPoint 
} from '../types';
import { 
  TrendingUp, 
  CloudRain, 
  Layers, 
  Compass, 
  Sparkles, 
  BarChart3, 
  Activity,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

interface AnalyticsChartsProps {
  selectedZone: WatchZone;
  vaeScenes: VAEScene[];
  onSelectHistoricalScene?: (scene: VAEScene) => void;
}

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({
  selectedZone,
  vaeScenes,
  onSelectHistoricalScene
}) => {
  const [activeChartTab, setActiveChartTab] = useState<'temporal' | 'vae' | 'sensor_agreement'>('temporal');
  const [hoveredPoint, setHoveredPoint] = useState<TimelineDataPoint | null>(null);
  const [selectedVaePoint, setSelectedVaePoint] = useState<VAEScene | null>(vaeScenes[0]);

  const timeline = selectedZone.timeline;
  const maxKm2 = Math.max(...timeline.map(t => t.valueKm2)) * 1.25 || 3.0;
  const maxRain = Math.max(...timeline.map(t => t.rainfallMm)) * 1.2 || 200;

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 rounded-xl border border-slate-800 shadow-xl overflow-hidden">
      {/* Top Header & Tabs */}
      <div className="px-4 py-3 bg-slate-900/80 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <BarChart3 className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Earth-Observation Intelligence Analytics
            </h3>
            <p className="text-[10px] text-slate-400 font-mono">
              Zone: {selectedZone.name} ({selectedZone.areaKm2} km²)
            </p>
          </div>
        </div>

        {/* Tab switchers */}
        <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs font-mono">
          <button
            onClick={() => setActiveChartTab('temporal')}
            className={`px-2.5 py-1 rounded-md transition-all ${
              activeChartTab === 'temporal'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Temporal Inundation
          </button>
          <button
            onClick={() => setActiveChartTab('vae')}
            className={`px-2.5 py-1 rounded-md transition-all ${
              activeChartTab === 'vae'
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            VAE Scene Latent Space
          </button>
          <button
            onClick={() => setActiveChartTab('sensor_agreement')}
            className={`px-2.5 py-1 rounded-md transition-all ${
              activeChartTab === 'sensor_agreement'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Sensor Agreement
          </button>
        </div>
      </div>

      {/* Main Graph Content */}
      <div className="p-4 flex-1 flex flex-col min-h-[300px] overflow-y-auto">
        {/* 1. TEMPORAL INUNDATION CURVE */}
        {activeChartTab === 'temporal' && (
          <div className="flex-1 flex flex-col space-y-4">
            <div className="flex justify-between items-center text-xs">
              <div className="flex items-center gap-4 font-mono">
                <div className="flex items-center gap-1.5 text-cyan-400">
                  <span className="h-2.5 w-2.5 rounded-full bg-cyan-400"></span>
                  <span>Inundated Area (km²)</span>
                </div>
                <div className="flex items-center gap-1.5 text-blue-400/80">
                  <span className="h-2.5 w-2.5 rounded bg-blue-500/50"></span>
                  <span>Daily Rainfall (mm)</span>
                </div>
              </div>

              {hoveredPoint && (
                <div className="bg-slate-900 border border-slate-700 px-2.5 py-1 rounded text-xs font-mono text-cyan-300 animate-fadeIn">
                  <span className="font-bold text-white">{hoveredPoint.date}:</span> {hoveredPoint.valueKm2} km² ({hoveredPoint.rainfallMm} mm rain) — {hoveredPoint.label}
                </div>
              )}
            </div>

            {/* SVG Chart Container */}
            <div className="relative flex-1 w-full h-[220px] bg-slate-900/40 rounded-xl p-3 border border-slate-800/80 overflow-hidden">
              <svg className="w-full h-full overflow-visible" viewBox="0 0 500 200" preserveAspectRatio="none">
                <defs>
                  {/* Gradient for Inundation Area */}
                  <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.45" />
                    <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Horizontal grid lines */}
                {[0.25, 0.5, 0.75, 1.0].map((fraction, i) => (
                  <line
                    key={i}
                    x1="40"
                    y1={170 - fraction * 140}
                    x2="480"
                    y2={170 - fraction * 140}
                    stroke="#1e293b"
                    strokeDasharray="4 4"
                  />
                ))}

                {/* Rainfall Bars */}
                {timeline.map((point, index) => {
                  const x = 50 + (index / (timeline.length - 1)) * 410;
                  const barHeight = (point.rainfallMm / maxRain) * 120;
                  const y = 170 - barHeight;
                  return (
                    <rect
                      key={`bar-${index}`}
                      x={x - 8}
                      y={y}
                      width={16}
                      height={barHeight}
                      fill="#3b82f6"
                      opacity={0.3}
                      rx={3}
                    />
                  );
                })}

                {/* Area Fill */}
                {timeline.length > 1 && (
                  <path
                    d={`
                      M 50 170
                      ${timeline.map((point, index) => {
                        const x = 50 + (index / (timeline.length - 1)) * 410;
                        const y = 170 - (point.valueKm2 / maxKm2) * 140;
                        return `L ${x} ${y}`;
                      }).join(' ')}
                      L 460 170 Z
                    `}
                    fill="url(#areaGradient)"
                  />
                )}

                {/* Smooth Inundation Line */}
                {timeline.length > 1 && (
                  <path
                    d={`
                      M 50 ${170 - (timeline[0].valueKm2 / maxKm2) * 140}
                      ${timeline.map((point, index) => {
                        const x = 50 + (index / (timeline.length - 1)) * 410;
                        const y = 170 - (point.valueKm2 / maxKm2) * 140;
                        return `L ${x} ${y}`;
                      }).join(' ')}
                    `}
                    fill="none"
                    stroke="#06b6d4"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                )}

                {/* Interactive Points */}
                {timeline.map((point, index) => {
                  const x = 50 + (index / (timeline.length - 1)) * 410;
                  const y = 170 - (point.valueKm2 / maxKm2) * 140;
                  const isHovered = hoveredPoint?.date === point.date;

                  return (
                    <g key={`pt-${index}`}>
                      <circle
                        cx={x}
                        cy={y}
                        r={isHovered ? 7 : 4}
                        fill="#0891b2"
                        stroke="#ffffff"
                        strokeWidth={isHovered ? 3 : 1.5}
                        className="transition-all cursor-pointer"
                        onMouseEnter={() => setHoveredPoint(point)}
                        onMouseLeave={() => setHoveredPoint(null)}
                      />
                      {/* X-axis Date Labels */}
                      <text
                        x={x}
                        y={190}
                        textAnchor="middle"
                        fontSize="10"
                        fill="#94a3b8"
                        fontFamily="monospace"
                      >
                        {point.date}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>

            {/* Threshold alert summary */}
            <div className="grid grid-cols-3 gap-3 text-xs font-mono">
              <div className="bg-slate-900/70 border border-slate-800 p-2.5 rounded-lg">
                <span className="text-[10px] text-slate-500 uppercase">Baseline (01 Aug)</span>
                <div className="text-base font-bold text-white">{timeline[0]?.valueKm2} km²</div>
              </div>
              <div className="bg-slate-900/70 border border-slate-800 p-2.5 rounded-lg">
                <span className="text-[10px] text-slate-500 uppercase">Peak (29 Aug)</span>
                <div className="text-base font-bold text-red-400">
                  {Math.max(...timeline.map(t => t.valueKm2))} km²
                </div>
              </div>
              <div className="bg-slate-900/70 border border-slate-800 p-2.5 rounded-lg">
                <span className="text-[10px] text-slate-500 uppercase">Current Surge</span>
                <div className="text-base font-bold text-emerald-400">
                  +{selectedZone.latestMetrics.deltaPercent}%
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 2. VAE LATENT CLUSTER GRAPH */}
        {activeChartTab === 'vae' && (
          <div className="flex-1 flex flex-col space-y-4">
            <div className="flex justify-between items-center text-xs">
              <p className="text-slate-400">
                Variational Autoencoder (VAE) 2D Latent Projection of Disaster Scenes. Click any cluster point to inspect similar historical events:
              </p>
              <span className="text-[10px] bg-purple-950 text-purple-300 border border-purple-800 px-2 py-0.5 rounded font-mono">
                FAISS Vector Cosine Distance
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
              {/* 2D Scatter Stage */}
              <div className="lg:col-span-8 bg-slate-900/50 rounded-xl border border-slate-800 p-3 relative h-[220px]">
                <svg className="w-full h-full" viewBox="-10 -10 20 20">
                  {/* Grid Lines */}
                  <line x1="-10" y1="0" x2="10" y2="0" stroke="#1e293b" strokeWidth="0.2" />
                  <line x1="0" y1="-10" x2="0" y2="10" stroke="#1e293b" strokeWidth="0.2" />

                  {/* Scatter Points */}
                  {vaeScenes.map(scene => {
                    const isSelected = selectedVaePoint?.id === scene.id;
                    const color = 
                      scene.cluster === 'Flooded Wetland' ? '#06b6d4' :
                      scene.cluster === 'Dense Urban' ? '#c084fc' :
                      scene.cluster === 'Agricultural' ? '#10b981' :
                      scene.cluster === 'Coastal' ? '#38bdf8' : '#f59e0b';

                    return (
                      <g key={scene.id} className="cursor-pointer" onClick={() => setSelectedVaePoint(scene)}>
                        <circle
                          cx={scene.coords[0]}
                          cy={-scene.coords[1]}
                          r={isSelected ? 0.9 : 0.6}
                          fill={color}
                          opacity={isSelected ? 1 : 0.75}
                          stroke="#ffffff"
                          strokeWidth={isSelected ? 0.3 : 0.1}
                        />
                        {isSelected && (
                          <circle
                            cx={scene.coords[0]}
                            cy={-scene.coords[1]}
                            r={1.8}
                            fill="none"
                            stroke={color}
                            strokeWidth="0.2"
                            strokeDasharray="0.3 0.3"
                            className="animate-spin"
                          />
                        )}
                      </g>
                    );
                  })}
                </svg>

                <div className="absolute bottom-2 left-3 flex items-center space-x-3 text-[9px] font-mono text-slate-400">
                  <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-cyan-400"></span> Flooded</span>
                  <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-purple-400"></span> Urban</span>
                  <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-400"></span> Agricultural</span>
                  <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-amber-400"></span> Forest</span>
                </div>
              </div>

              {/* Selected Scene Card */}
              <div className="lg:col-span-4 bg-slate-900/80 border border-purple-500/30 rounded-xl p-3 flex flex-col justify-between text-xs font-mono">
                {selectedVaePoint ? (
                  <div className="space-y-2">
                    <div className="flex justify-between items-center border-b border-slate-800 pb-1.5">
                      <span className="text-[10px] text-purple-400 uppercase font-bold">Similar Scene Match</span>
                      <span className="text-emerald-400 font-bold bg-emerald-950/70 px-1.5 py-0.5 rounded border border-emerald-800">
                        {selectedVaePoint.similarityScore}% Match
                      </span>
                    </div>
                    <div className="font-bold text-white">{selectedVaePoint.name}</div>
                    <div className="text-slate-400 text-[11px]">{selectedVaePoint.region} • {selectedVaePoint.date}</div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800 text-[11px] text-slate-300">
                      Inundation Scale: <span className="text-cyan-400 font-bold">{selectedVaePoint.inundationLevel}</span>
                    </div>
                  </div>
                ) : (
                  <div className="text-slate-500 text-center py-6">Select a point in latent space</div>
                )}

                <button 
                  onClick={() => selectedVaePoint && onSelectHistoricalScene?.(selectedVaePoint)}
                  className="w-full mt-3 py-1.5 bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/50 text-purple-200 rounded-lg text-xs font-bold transition-colors"
                >
                  Inspect Historical Imagery
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 3. SENSOR AGREEMENT RADAR / MATRIX */}
        {activeChartTab === 'sensor_agreement' && (
          <div className="flex-1 flex flex-col space-y-4">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Cross-modal Sensor Confidence Calibration (Optical vs SAR vs Temporal)</span>
              <span className="text-emerald-400 font-bold font-mono bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                Joint Agreement: 92.4%
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3 space-y-2">
                <div className="flex justify-between items-center text-slate-400">
                  <span>Optical Spectral Delineation</span>
                  <span className="text-cyan-400 font-bold">89.5%</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-cyan-500 h-full rounded-full" style={{ width: '89.5%' }}></div>
                </div>
                <p className="text-[10px] text-slate-500 leading-tight">
                  NDWI water absorption curve identifies specular ponding, partially hindered by cloud cover.
                </p>
              </div>

              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3 space-y-2">
                <div className="flex justify-between items-center text-slate-400">
                  <span>SAR Backscatter Specular Drop</span>
                  <span className="text-amber-400 font-bold">96.1%</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-amber-500 h-full rounded-full" style={{ width: '96.1%' }}></div>
                </div>
                <p className="text-[10px] text-slate-500 leading-tight">
                  C-band VV polarization radar dropped by -11.4 dB across water surfaces; 100% cloud penetration.
                </p>
              </div>

              <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3 space-y-2">
                <div className="flex justify-between items-center text-slate-400">
                  <span>Temporal Difference Consistency</span>
                  <span className="text-emerald-400 font-bold">91.4%</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: '91.4%' }}></div>
                </div>
                <p className="text-[10px] text-slate-500 leading-tight">
                  Siamese ResNet-50 cosine distance matches water expansion geometry with 0.88 Dice coefficient.
                </p>
              </div>
            </div>

            <div className="bg-slate-900/40 border border-slate-800 rounded-lg p-3 text-xs text-slate-300 leading-relaxed font-sans">
              <span className="font-bold text-white font-mono">Calibrated Evidence Insight: </span>
              Because both optical infrared absorption and synthetic aperture radar specular bounce independently confirm the boundaries of the flood polders, the resulting alert is rated as 
              <span className="text-emerald-400 font-semibold font-mono"> CRITICAL (91.4% Grounded Reliability)</span> with false-positive probability &lt; 0.06.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
