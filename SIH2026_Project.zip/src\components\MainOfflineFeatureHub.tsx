import React from 'react';
import { 
  Wifi, 
  WifiOff, 
  HardDriveDownload, 
  ShieldAlert, 
  Database, 
  Cpu, 
  Radio, 
  CheckCircle2, 
  ArrowRight, 
  Sparkles, 
  MapPin, 
  RefreshCw, 
  FileJson 
} from 'lucide-react';
import { WatchZone, OfflinePackageState } from '../types';

interface MainOfflineFeatureHubProps {
  isOffline: boolean;
  onToggleOffline: () => void;
  selectedZone: WatchZone;
  onSelectZone: (zone: WatchZone) => void;
  watchZones: WatchZone[];
  offlinePackage: OfflinePackageState;
  onOpenOfflineModal: () => void;
  pendingSyncCount: number;
  onTriggerSync: () => void;
  isSyncing: boolean;
  onInstallPWA?: () => void;
}

export const MainOfflineFeatureHub: React.FC<MainOfflineFeatureHubProps> = ({
  isOffline,
  onToggleOffline,
  selectedZone,
  onSelectZone,
  watchZones,
  offlinePackage,
  onOpenOfflineModal,
  pendingSyncCount,
  onTriggerSync,
  isSyncing,
  onInstallPWA
}) => {
  const nepalZone = watchZones.find(z => z.id === 'zone-nepal') || watchZones[0];
  const isNepalSelected = selectedZone.id === 'zone-nepal';

  return (
    <div className="bg-gradient-to-r from-slate-950 via-[#07111e] to-slate-950 border-b border-cyan-500/30 px-4 py-2 text-xs font-mono select-none shadow-xl">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Left: Offline Mode Status & Capabilities */}
        <div className="flex items-center space-x-3 flex-wrap gap-y-1">
          <div className="flex items-center space-x-2">
            <div className={`p-1.5 rounded-lg border ${
              isOffline
                ? 'bg-amber-500/20 border-amber-500 text-amber-300 animate-pulse'
                : 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400'
            }`}>
              {isOffline ? <WifiOff className="h-4 w-4" /> : <Wifi className="h-4 w-4" />}
            </div>
            <div>
              <div className="flex items-center gap-1.5 font-bold">
                <span className="text-white text-xs uppercase tracking-wide">
                  {isOffline ? 'OFFLINE EMERGENCY MODE (EDGE BUS)' : 'OFFLINE EMERGENCY MODE:'}
                </span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded uppercase font-bold border ${
                  isOffline
                    ? 'bg-amber-950/80 text-amber-300 border-amber-500/60'
                    : 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
                }`}>
                  {isOffline ? 'ACTIVE ON LOCAL DISK' : 'ARMED FOR ZERO INTERNET'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-sans hidden sm:block">
                {isOffline
                  ? 'Running on cached Sentinel GeoTIFFs, local Edge AI, and local sync queue without cellular or wifi.'
                  : 'Engineered for telecom blackouts (e.g. Nepal deluge). Cached satellite rasters, offline GIS & SOS beacons ready.'}
              </p>
            </div>
          </div>
        </div>

        {/* Center: Nepal Flood Disaster Quick Action */}
        <div className="flex items-center space-x-2 bg-slate-900/80 border border-slate-800 rounded-lg p-1.5 backdrop-blur-md">
          <div className="flex items-center space-x-1.5 px-2 py-0.5 rounded bg-red-950/70 text-red-300 border border-red-800 text-[10px] font-bold">
            <ShieldAlert className="h-3 w-3 text-red-400 animate-pulse" />
            <span>DISASTER ACTIVE: NEPAL FLOOD</span>
          </div>

          <button
            onClick={() => onSelectZone(nepalZone)}
            className={`px-2.5 py-1 rounded text-[11px] font-bold transition-all flex items-center gap-1 shadow ${
              isNepalSelected
                ? 'bg-cyan-600 text-white shadow-cyan-950/50'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white'
            }`}
          >
            <MapPin className="h-3 w-3 text-cyan-300" />
            <span>{isNepalSelected ? 'Viewing Nepal Basin (4.85 km²)' : 'Focus Nepal Basin'}</span>
            <ArrowRight className="h-3 w-3" />
          </button>
        </div>

        {/* Right: Quick Toggle & Actions */}
        <div className="flex items-center space-x-2">
          <button
            onClick={onToggleOffline}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-1.5 shadow-md ${
              isOffline
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                : 'bg-amber-600 hover:bg-amber-500 text-white'
            }`}
            title="Simulate zero-internet field disconnect or reconnect to satellite relay"
          >
            {isOffline ? (
              <>
                <Wifi className="h-3.5 w-3.5" />
                <span>Simulate Online Link</span>
              </>
            ) : (
              <>
                <WifiOff className="h-3.5 w-3.5" />
                <span>Test Offline Mode</span>
              </>
            )}
          </button>

          {onInstallPWA && (
            <button
              onClick={onInstallPWA}
              className="px-2.5 py-1.5 rounded-lg bg-emerald-950/80 border border-emerald-500/50 hover:bg-emerald-900/80 text-emerald-300 text-xs font-bold transition-colors flex items-center space-x-1 shadow"
              title="Install SatQuery AI as a standalone offline desktop or mobile PWA"
            >
              <HardDriveDownload className="h-3.5 w-3.5 text-emerald-400" />
              <span className="hidden xl:inline">Install Offline App</span>
            </button>
          )}

          <button
            onClick={onOpenOfflineModal}
            className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 hover:border-cyan-500 text-slate-200 text-xs font-bold transition-colors flex items-center space-x-1"
            title="Inspect Emergency Mission Package and local sync queue"
          >
            <Database className="h-3.5 w-3.5 text-cyan-400" />
            <span className="hidden lg:inline">Offline Hub</span>
            {pendingSyncCount > 0 && (
              <span className="bg-amber-500 text-slate-950 font-black text-[9px] px-1 rounded-full">
                {pendingSyncCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
